#!/usr/bin/env bash
# Installs Django the first time, prepares the database, then starts the server.
cd "$(dirname "$0")"
python3 -c "import django" 2>/dev/null || python3 -m pip install -r requirements.txt
python3 manage.py migrate --noinput
echo "Open http://127.0.0.1:8000 in Chrome or Edge. Press Ctrl+C to stop."
python3 manage.py runserver 127.0.0.1:8000
