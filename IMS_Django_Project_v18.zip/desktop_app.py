"""IMS desktop application: the same program, in its own window (no browser to open).

It starts the built-in server on this computer, opens the application in a window, and
keeps the data in the user's application-data folder (%APPDATA%\\IMS on Windows).
Run it with:  python desktop_app.py     (or build it with build_desktop.bat)
"""
import base64
import os
import socket
import threading
from pathlib import Path
from socketserver import ThreadingMixIn
from wsgiref.simple_server import WSGIRequestHandler, WSGIServer, make_server

APP_NAME = "IMS"
PREFERRED_PORT = 8765


class _QuietHandler(WSGIRequestHandler):
    def log_message(self, *args):
        pass


class _ThreadedServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True


def data_dir():
    """The folder for this user's data and browser files (created if missing)."""
    base = os.environ.get("APPDATA") or str(Path.home() / ".local" / "share")
    folder = Path(base) / APP_NAME
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def prepare_database():
    """Points the program at the data file in the data folder, and creates its tables."""
    folder = data_dir()
    os.environ.setdefault("IMS_DB", str(folder / "ims.sqlite3"))
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ims.settings")
    import django
    django.setup()
    from django.core.management import call_command
    call_command("migrate", interactive=False, verbosity=0)


def free_port(preferred):
    for port in range(preferred, preferred + 20):
        with socket.socket() as probe:
            try:
                probe.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("No free port was found for the built-in server.")


def start_server(port):
    """Runs the application server in the background, on this computer only."""
    from django.core.wsgi import get_wsgi_application
    application = get_wsgi_application()
    httpd = make_server("127.0.0.1", port, application, server_class=_ThreadedServer, handler_class=_QuietHandler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd


class DesktopApi:
    """Functions the page can call when it runs in the desktop window (backup, reports)."""

    def save_file(self, filename, data_base64):
        import webview
        window = webview.windows[0]
        chosen = window.create_file_dialog(webview.SAVE_DIALOG, save_filename=filename)
        if not chosen:
            return False
        target = chosen[0] if isinstance(chosen, (list, tuple)) else chosen
        Path(target).write_bytes(base64.b64decode(data_base64))
        return True


def main():
    prepare_database()
    port = free_port(PREFERRED_PORT)
    httpd = start_server(port)
    url = f"http://127.0.0.1:{port}/"
    if os.environ.get("IMS_DESKTOP_HEADLESS") == "1":
        # used for testing: run the server without a window
        print(f"IMS server running at {url}", flush=True)
        threading.Event().wait()
        return
    import webview
    webview.create_window("Inventory & Sales Management System", url, width=1280, height=820,
                          min_size=(900, 600), js_api=DesktopApi())
    # the page keeps its local copy in this folder, so it opens the same way next time
    webview.start(storage_path=str(data_dir() / "browser"))
    httpd.shutdown()


if __name__ == "__main__":
    main()
