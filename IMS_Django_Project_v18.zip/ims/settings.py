"""Settings for the Inventory & Sales Management System (Django project)."""
import configparser
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# The application's own sign-in is checked in the browser (as in the standalone file).
# This secret key is only used by Django internally; change it if you put this online.
SECRET_KEY = "ims-local-only-change-me"
DEBUG = False

INSTALLED_APPS = [
    "django.contrib.contenttypes",
    "store",
]

MIDDLEWARE = [
    "ims.middleware.ApiCorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
]

ROOT_URLCONF = "ims.urls"
TEMPLATES = []
WSGI_APPLICATION = "ims.wsgi.application"

# ---- Database -------------------------------------------------------------------------
# Choose SQLite (default, file db.sqlite3) or MySQL in database.ini. Environment variables
# (IMS_DB_ENGINE, IMS_MYSQL_NAME, IMS_MYSQL_USER, IMS_MYSQL_PASSWORD, IMS_MYSQL_HOST,
# IMS_MYSQL_PORT, IMS_DB) override the file.
_ini = configparser.ConfigParser()
_ini.read(BASE_DIR / "database.ini", encoding="utf-8")
_cfg = _ini["database"] if _ini.has_section("database") else {}


def _setting(env, key, default):
    return os.environ.get(env) or _cfg.get(key, default)


ENGINE = _setting("IMS_DB_ENGINE", "engine", "sqlite").strip().lower()

# Addresses this server answers to. By default only this computer; for the office network add the
# server computer's address, e.g. database.ini [server] allowed_hosts = 127.0.0.1,localhost,192.168.1.20
_server = _ini["server"] if _ini.has_section("server") else {}
ALLOWED_HOSTS = [h.strip() for h in (os.environ.get("IMS_ALLOWED_HOSTS") or _server.get("allowed_hosts", "127.0.0.1,localhost")).split(",") if h.strip()]

if ENGINE == "mysql":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.mysql",
            "NAME": _setting("IMS_MYSQL_NAME", "name", "ims"),
            "USER": _setting("IMS_MYSQL_USER", "user", "ims_user"),
            "PASSWORD": _setting("IMS_MYSQL_PASSWORD", "password", ""),
            "HOST": _setting("IMS_MYSQL_HOST", "host", "127.0.0.1"),
            "PORT": _setting("IMS_MYSQL_PORT", "port", "3306"),
            "OPTIONS": {"charset": "utf8mb4"},
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": os.environ.get("IMS_DB") or str(BASE_DIR / "db.sqlite3"),
        }
    }

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Karachi"
USE_I18N = True
USE_TZ = True

IMS_WEB_DIR = BASE_DIR / "web"                    # the application pages

# ---- Local AI (Ollama) -------------------------------------------------------------
# Where Ollama runs (its default is this computer, port 11434) and the default model.
# Set them in database.ini under [ai], or with the environment variables below.
_ai = _ini["ai"] if _ini.has_section("ai") else {}
OLLAMA_URL = os.environ.get("OLLAMA_URL") or _ai.get("ollama_url", "http://127.0.0.1:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL") or _ai.get("ollama_model", "qwen2.5:7b")
