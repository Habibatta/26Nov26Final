# MySQL support: if PyMySQL is installed, let Django's MySQL backend use it (no compiler needed on Windows).
try:
    import pymysql

    pymysql.install_as_MySQLdb()
except ImportError:
    pass
