from django.urls import path, re_path

from store import views

urlpatterns = [
    path("favicon.ico", views.favicon),
    path("", views.index),
    path("api/version", views.api_version),
    path("api/kv", views.api_all),
    path("api/kv/bulk", views.api_bulk),
    path("api/ai/ollama", views.api_ollama),
    path("api/login", views.api_login),
    path("api/logout", views.api_logout),
    path("api/session", views.api_session),
    re_path(r"^api/kv/(?P<key>.+)$", views.api_record),
    re_path(r"^(?P<filename>.+)$", views.web_file),
]
