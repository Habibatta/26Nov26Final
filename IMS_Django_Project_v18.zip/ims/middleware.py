from django.http import HttpResponse


class ApiCorsMiddleware:
    """Lets the standalone file (opened from disk) and other computers call the data API.
    The API is protected by a sign-in token, not by cookies, so allowing any origin is safe."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not request.path.startswith("/api/"):
            return self.get_response(request)
        response = HttpResponse(status=204) if request.method == "OPTIONS" else self.get_response(request)
        response["Access-Control-Allow-Origin"] = "*"
        response["Access-Control-Allow-Headers"] = "Authorization, Content-Type, X-Base-Rev"
        response["Access-Control-Allow-Methods"] = "GET, PUT, POST, DELETE, OPTIONS"
        return response
