"""Views: the application pages, the data API used for sync, sign-in, and the Ollama proxy.

Works with SQLite and MySQL/MariaDB: all database work uses Django's queries.
"""
import hashlib
import json
import re
import secrets
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

from django.conf import settings
from django.db import transaction
from django.db.models import F
from django.http import (FileResponse, Http404, HttpResponse, HttpResponseBadRequest,
                         JsonResponse)
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_http_methods

from .models import Record, Revision, Token

KEY_RE = re.compile(r"^[A-Za-z0-9_.\-]+(/[A-Za-z0-9_.\-]+)*$")
_write_lock = threading.Lock()   # saves run one at a time, on every database
TOKEN_DAYS = 30
NO_OVERWRITE_LOG = ("hist/", "presence/")   # these change often and are not "work" to log

# Explicit content types: some Windows computers map .js to text/plain, which browsers refuse to run.
CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".txt": "text/plain; charset=utf-8",
}


def _web_dir():
    return Path(settings.IMS_WEB_DIR).resolve()


def _version():
    return Revision.objects.filter(id=1).values_list("number", flat=True).first() or 0


def _valid_key(key):
    return len(key) <= 200 and ".." not in key and bool(KEY_RE.match(key))


def _bump_version():
    Revision.objects.get_or_create(id=1)
    Revision.objects.filter(id=1).update(number=F("number") + 1)
    return Revision.objects.get(id=1).number


# ---- sign-in -------------------------------------------------------------------------
def _token_hash(raw):
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _signed_in_as(request):
    """The username of the person who signed in with this request's token, or ""."""
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return ""
    token = Token.objects.filter(key=_token_hash(header[7:].strip())).first()
    if token is None or token.expires < datetime.now(timezone.utc):
        return ""
    return token.username


def _setup_mode():
    """No account exists on the server yet: the first person to sign in becomes the owner."""
    return not Record.objects.filter(key__startswith="users/").exists()


def _may_use_api(request):
    return bool(_signed_in_as(request)) or _setup_mode()


def _not_signed_in():
    return JsonResponse({"error": "Sign in to the server first."}, status=401)


@csrf_exempt
@require_http_methods(["POST"])
def api_login(request):
    """Checks the password (the same hash the application uses) and returns a token for the sync."""
    try:
        body = json.loads(request.body.decode("utf-8"))
    except ValueError:
        return HttpResponseBadRequest("The request is not valid JSON.")
    username = str(body.get("username", "")).strip()
    pw = str(body.get("pw", ""))
    if not username or not pw:
        return JsonResponse({"error": "Enter the username and password."}, status=400)
    record = Record.objects.filter(key=f"users/{username}").first()
    if record is None:
        if not _setup_mode():
            return JsonResponse({"error": "Wrong username or password."}, status=401)
        # first account on the server: it becomes the owner (super user)
        with _write_lock, transaction.atomic():
            Record.objects.create(key=f"users/{username}", rev=1, value=json.dumps(
                {"pw": pw, "su": True, "pages": [], "add": True, "edit": True, "del": True, "active": True}))
            _bump_version()
    else:
        stored = json.loads(record.value)
        if stored.get("pw") != pw:
            return JsonResponse({"error": "Wrong username or password."}, status=401)
        if stored.get("active") is False:
            return JsonResponse({"error": "This account is switched off."}, status=403)
    raw = secrets.token_urlsafe(32)
    Token.objects.create(key=_token_hash(raw), username=username,
                         expires=datetime.now(timezone.utc) + timedelta(days=TOKEN_DAYS))
    return JsonResponse({"token": raw, "user": username})


@csrf_exempt
@require_http_methods(["POST"])
def api_logout(request):
    header = request.headers.get("Authorization", "")
    if header.startswith("Bearer "):
        Token.objects.filter(key=_token_hash(header[7:].strip())).delete()
    return JsonResponse({"ok": True})


@require_GET
def api_session(request):
    user = _signed_in_as(request)
    if not user:
        return _not_signed_in()
    return JsonResponse({"user": user})


# ---- pages ---------------------------------------------------------------------------
def favicon(request):
    return HttpResponse(status=204)


@require_GET
def index(request):
    return _serve(_web_dir() / "index.html")


@require_GET
def web_file(request, filename):
    base = _web_dir()
    target = (base / filename).resolve()
    if base not in target.parents or not target.is_file():
        raise Http404("No such page or file.")
    return _serve(target)


def _serve(path):
    ctype = CONTENT_TYPES.get(path.suffix.lower(), "application/octet-stream")
    return FileResponse(open(path, "rb"), content_type=ctype)



@require_GET
def api_version(request):
    if not _may_use_api(request):
        return _not_signed_in()
    return JsonResponse({"version": _version()})


@require_GET
def api_all(request):
    """Every saved item with its revision: {"version": n, "items": {key: value}, "revs": {key: rev}}."""
    if not _may_use_api(request):
        return _not_signed_in()
    version = _version()
    rows = list(Record.objects.order_by("key").values_list("key", "value", "rev"))
    items = ",".join(json.dumps(k) + ":" + v for k, v, _ in rows)
    revs = ",".join(json.dumps(k) + ":" + str(r) for k, _, r in rows)
    body = '{"version":%d,"items":{%s},"revs":{%s}}' % (version, items, revs)
    return HttpResponse(body, content_type="application/json")


def _upsert(key, raw, rev):
    Record.objects.update_or_create(key=key, defaults={"value": raw, "rev": rev})


def _log_overwrite(key, user, previous, newer):
    """The latest change won. The replaced version is noted in History, so nothing vanishes silently."""
    now = time.time_ns() // 1000
    entry = {"id": now, "at": datetime.now(timezone.utc).isoformat(), "user": user,
             "a": "Overwritten", "p": key.split("/")[0],
             "d": f"{key}: a change made on another computer was replaced by a newer change"}
    Record.objects.create(key=f"hist/{now}", value=json.dumps(entry, ensure_ascii=False), rev=1)


@csrf_exempt
@require_http_methods(["PUT", "DELETE"])
def api_record(request, key):
    if not _valid_key(key):
        return HttpResponseBadRequest("Invalid record key.")
    user = _signed_in_as(request)
    if not user and not _setup_mode():
        return _not_signed_in()
    with _write_lock, transaction.atomic():
        current = Record.objects.filter(key=key).first()
        current_rev = current.rev if current else 0
        if request.method == "PUT":
            raw = request.body.decode("utf-8")
            try:
                json.loads(raw)
            except ValueError:
                return HttpResponseBadRequest("The body is not valid JSON.")
            base = request.headers.get("X-Base-Rev")
            if (current is not None and base is not None and str(current_rev) != base
                    and current.value != raw and not key.startswith(NO_OVERWRITE_LOG)):
                _log_overwrite(key, user, current.value, raw)
            new_rev = current_rev + 1
            _upsert(key, raw, new_rev)
        else:
            if current is not None:
                current.delete()
            new_rev = 0
        version = _bump_version()
    return JsonResponse({"version": version, "rev": new_rev})


@csrf_exempt
@require_http_methods(["POST"])
def api_bulk(request):
    """Restore a backup: every item in the body is saved (items with the same key are replaced)."""
    if not _may_use_api(request):
        return _not_signed_in()
    try:
        data = json.loads(request.body.decode("utf-8"))
    except ValueError:
        return HttpResponseBadRequest("The backup is not valid JSON.")
    if not isinstance(data, dict):
        return HttpResponseBadRequest("The backup must be an object.")
    if not all(_valid_key(k) for k in data):
        return HttpResponseBadRequest("The backup contains an invalid key.")
    with _write_lock, transaction.atomic():
        for key, value in data.items():
            current = Record.objects.filter(key=key).first()
            _upsert(key, json.dumps(value, ensure_ascii=False), (current.rev if current else 0) + 1)
        version = _bump_version()
    return JsonResponse({"version": version, "saved": len(data)})


@csrf_exempt
@require_http_methods(["POST"])
def api_ollama(request):
    """Passes an AI chat request to the Ollama server on this computer.

    The browser never talks to Ollama directly. Only people who are signed in may use it.
    """
    if not _may_use_api(request):
        return _not_signed_in()
    try:
        body = json.loads(request.body.decode("utf-8"))
    except ValueError:
        return HttpResponseBadRequest("The request is not valid JSON.")
    payload = {"model": body.get("model") or settings.OLLAMA_MODEL,
               "messages": body.get("messages") or [],
               "stream": False}
    if body.get("tools"):
        payload["tools"] = body["tools"]
    req = urllib.request.Request(settings.OLLAMA_URL.rstrip("/") + "/api/chat",
                                 data=json.dumps(payload).encode("utf-8"),
                                 headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            return HttpResponse(resp.read(), content_type="application/json")
    except urllib.error.HTTPError as err:
        # Ollama explains the problem itself, e.g. "model not found" or "does not support tools"
        return HttpResponse(err.read() or b'{"error": "Ollama returned an error."}',
                            status=502, content_type="application/json")
    except TimeoutError:
        return JsonResponse({"error": "Ollama took too long to answer. Try again or use a smaller model."}, status=504)
    except (urllib.error.URLError, OSError):
        return JsonResponse({"error": f"Ollama is not reachable at {settings.OLLAMA_URL}. "
                                      "Start Ollama, or check ollama_url in database.ini."}, status=502)

