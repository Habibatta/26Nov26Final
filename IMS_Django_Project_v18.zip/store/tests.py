"""Tests for the data API, sign-in and the sync rules. Run:  python manage.py test store"""
import io
import json
import urllib.error
from unittest import mock

from django.test import TestCase

from .models import Record

PW = "9f2c4d6e8a0b1c3d5e7f9a1b3c5d7e9f"    # stands for the hash the application sends (SHA-256 of ims-v1:+password)


class DataApiTests(TestCase):
    """The first sign-in on an empty server makes that person the owner; everything else needs a token."""

    def setUp(self):
        r = self.client.post("/api/login", data=json.dumps({"username": "admin", "pw": PW}),
                             content_type="application/json")
        self.auth = {"HTTP_AUTHORIZATION": "Bearer " + r.json()["token"]}

    def items(self):
        return json.loads(self.client.get("/api/kv", **self.auth).content)

    def put(self, key, value, base=None):
        headers = dict(self.auth)
        if base is not None:
            headers["HTTP_X_BASE_REV"] = str(base)
        return self.client.put(f"/api/kv/{key}", data=json.dumps(value, ensure_ascii=False),
                               content_type="application/json", **headers)

    def test_pages_and_files_are_served(self):
        for url in ["/", "/css/ims.css", "/js/offline-runtime.js", "/assets/logo.png"]:
            self.assertEqual(self.client.get(url).status_code, 200, url)
        self.assertEqual(self.client.get("/js/offline-runtime.js")["Content-Type"],
                         "application/javascript; charset=utf-8")

    def test_missing_and_outside_files_are_not_found(self):
        self.assertEqual(self.client.get("/no-such-file.js").status_code, 404)
        self.assertEqual(self.client.get("/../manage.py").status_code, 404)

    def test_data_needs_a_sign_in(self):
        self.assertEqual(self.client.get("/api/kv").status_code, 401)
        self.assertEqual(self.client.put("/api/kv/bank/1", data="{}", content_type="application/json").status_code, 401)

    def test_wrong_password_is_refused(self):
        r = self.client.post("/api/login", data=json.dumps({"username": "admin", "pw": "wrong"}),
                             content_type="application/json")
        self.assertEqual(r.status_code, 401)

    def test_session_and_logout(self):
        self.assertEqual(self.client.get("/api/session", **self.auth).json()["user"], "admin")
        self.client.post("/api/logout", **self.auth)
        self.assertEqual(self.client.get("/api/session", **self.auth).status_code, 401)

    def test_save_read_and_delete_a_record(self):
        self.assertEqual(self.put("bank/1", {"id": 1, "bank": "HBL"}).status_code, 200)
        self.assertEqual(self.items()["items"]["bank/1"], {"id": 1, "bank": "HBL"})
        self.client.delete("/api/kv/bank/1", **self.auth)
        self.assertNotIn("bank/1", self.items()["items"])

    def test_every_change_moves_the_version_on(self):
        v1 = self.client.get("/api/version", **self.auth).json()["version"]
        self.put("cat/7", {"id": 7, "name": "Fuel"})
        self.assertGreater(self.client.get("/api/version", **self.auth).json()["version"], v1)

    def test_each_record_counts_its_changes(self):
        self.assertEqual(self.put("cat/9", {"n": 1}).json()["rev"], 1)
        self.assertEqual(self.put("cat/9", {"n": 2}, base=1).json()["rev"], 2)
        self.assertEqual(self.items()["revs"]["cat/9"], 2)

    def test_latest_change_wins_and_the_replaced_one_is_noted_in_history(self):
        self.put("emp/5", {"first": "Ali"})                       # rev 1
        self.put("emp/5", {"first": "Ahmed"}, base=1)            # computer A (rev 2)
        r = self.put("emp/5", {"first": "Usman"}, base=1)        # computer B was based on rev 1: it is newer, it wins
        self.assertEqual(r.json()["rev"], 3)
        self.assertEqual(self.items()["items"]["emp/5"], {"first": "Usman"})
        notes = [v for k, v in self.items()["items"].items() if k.startswith("hist/")]
        self.assertTrue(any(n["a"] == "Overwritten" and "emp/5" in n["d"] for n in notes))

    def test_no_history_note_when_the_content_is_the_same(self):
        self.put("cat/3", {"name": "Fuel"})
        self.put("cat/3", {"name": "Fuel"}, base=0)               # same content, stale base: nothing to note
        self.assertFalse(any(k.startswith("hist/") for k in self.items()["items"]))

    def test_unusual_text_survives(self):
        value = {"desc": "Cheque — Rs 12,500.50 \u2192 \"done\""}
        self.put("led/9", value)
        self.assertEqual(self.items()["items"]["led/9"], value)

    def test_backup_restore_saves_every_record(self):
        backup = {"users/clerk": {"pw": "x", "pages": ["exp"]}, "emp/2": {"id": 2, "first": "Ali"}}
        r = self.client.post("/api/kv/bulk", data=json.dumps(backup), content_type="application/json", **self.auth)
        self.assertEqual(r.json()["saved"], 2)
        items = self.items()["items"]
        self.assertEqual(items["emp/2"]["first"], "Ali")
        self.assertEqual(items["users/clerk"]["pages"], ["exp"])

    def test_bad_keys_and_bad_json_are_refused(self):
        self.assertEqual(self.put("a/..%2Fsecret", {}).status_code, 400)
        self.assertEqual(self.client.put("/api/kv/bank/1", data="not json", content_type="application/json",
                                         **self.auth).status_code, 400)
        self.assertEqual(self.client.post("/api/kv/bulk", data="[1,2]", content_type="application/json",
                                          **self.auth).status_code, 400)


class OllamaProxyTests(TestCase):
    """The browser asks this server; this server asks Ollama (faked here: no model is needed)."""

    def post(self, body):
        return self.client.post("/api/ai/ollama", data=json.dumps(body), content_type="application/json")

    def test_request_is_passed_to_ollama_without_streaming(self):
        reply = b'{"message":{"role":"assistant","content":"hi"},"done":true}'
        fake = mock.MagicMock()
        fake.__enter__.return_value.read.return_value = reply
        with mock.patch("store.views.urllib.request.urlopen", return_value=fake) as up:
            r = self.post({"model": "qwen2.5:7b", "messages": [{"role": "user", "content": "x"}],
                           "tools": [{"type": "function", "function": {"name": "summary"}}]})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.content, reply)
        sent = up.call_args[0][0]
        self.assertEqual(sent.full_url, "http://127.0.0.1:11434/api/chat")
        body = json.loads(sent.data)
        self.assertEqual(body["model"], "qwen2.5:7b")
        self.assertFalse(body["stream"])
        self.assertEqual(body["tools"][0]["function"]["name"], "summary")

    def test_unreachable_ollama_gives_a_clear_message(self):
        with mock.patch("store.views.urllib.request.urlopen", side_effect=urllib.error.URLError("refused")):
            r = self.post({"messages": []})
        self.assertEqual(r.status_code, 502)
        self.assertIn("not reachable", r.json()["error"])

    def test_ollama_error_text_is_passed_on(self):
        err = urllib.error.HTTPError("u", 404, "Not Found", {}, io.BytesIO(b'{"error":"model not found"}'))
        with mock.patch("store.views.urllib.request.urlopen", side_effect=err):
            r = self.post({"model": "missing", "messages": []})
        self.assertEqual(r.status_code, 502)
        self.assertEqual(r.json()["error"], "model not found")
