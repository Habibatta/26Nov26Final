from django.db import models


class Record(models.Model):
    """One saved item of the application, e.g. key "emp/3" or "users/ali". value is its JSON text.
    rev counts this item's changes (used to detect two computers changing the same item)."""
    key = models.CharField(max_length=200, primary_key=True)
    value = models.TextField()
    rev = models.IntegerField(default=0)

    class Meta:
        ordering = ["key"]

    def __str__(self):
        return self.key


class Revision(models.Model):
    """Counts every change, so open windows know when to reload. There is one row (id 1)."""
    id = models.IntegerField(primary_key=True, default=1)
    number = models.BigIntegerField(default=0)


class Token(models.Model):
    """A sign-in for the sync. Only a hash of the token is stored."""
    key = models.CharField(max_length=64, primary_key=True)
    username = models.CharField(max_length=200)
    created = models.DateTimeField(auto_now_add=True)
    expires = models.DateTimeField()
