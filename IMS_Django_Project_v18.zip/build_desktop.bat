@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt -r requirements-desktop.txt pyinstaller
python -m PyInstaller --noconfirm --windowed --name IMS --add-data "web;web" --add-data "database.ini;." --collect-submodules store --collect-submodules ims --collect-all webview desktop_app.py
echo.
echo Done. Copy the whole folder dist\IMS to any Windows computer and double-click IMS.exe inside it.
pause
