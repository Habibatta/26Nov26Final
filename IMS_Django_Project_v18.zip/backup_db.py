"""Copies the SQLite database to a backup folder (for example another drive).

It is safe while the server is running: it uses SQLite's own backup, checks the copy,
and only then keeps it. Old copies beyond the number to keep are removed.

Usage:
  python backup_db.py        (folder: the one chosen in setup_backup_task.bat, else database.ini [backup])
  python backup_db.py --folder E:\\IMS_Backups --keep 30
  python backup_db.py --database "C:\\Users\\me\\AppData\\Roaming\\IMS\\ims.sqlite3"   (desktop data)
"""
import argparse
import configparser
import datetime
import os
import sqlite3
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent


def chosen_folder():
    """The folder picked in setup_backup_task.bat (saved in backup_folder.txt), or ''."""
    try:
        return (BASE / "backup_folder.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def read_settings():
    ini = configparser.ConfigParser()
    ini.read(BASE / "database.ini", encoding="utf-8")
    return ini["backup"] if ini.has_section("backup") else {}


def database_path(override):
    if override:
        return Path(override)
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ims.settings")
    import django
    django.setup()
    from django.conf import settings
    db = settings.DATABASES["default"]
    if not db["ENGINE"].endswith("sqlite3"):
        fail("The database is not SQLite (" + db["ENGINE"] + "). For MySQL use mysqldump instead.")
    return Path(db["NAME"])


def log(folder, text):
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(Path(folder) / "backup.log", "a", encoding="utf-8") as f:
            f.write(f"{stamp}  {text}\n")
    except OSError:
        pass
    print(f"{stamp}  {text}")


def fail(text, folder=None):
    if folder:
        log(folder, "FAILED: " + text)
    else:
        print("FAILED: " + text, file=sys.stderr)
    sys.exit(1)


def keep_only(folder, keep):
    copies = sorted(Path(folder).glob("ims-*.sqlite3"))   # names carry the date and time, so they sort in order
    removed = 0
    for old in copies[:-keep] if keep > 0 else []:
        old.unlink()
        removed += 1
    return removed


def main():
    parser = argparse.ArgumentParser(description="Back up the IMS database.")
    parser.add_argument("--folder", help="where the copies go, for example E:\\IMS_Backups")
    parser.add_argument("--keep", type=int, help="how many copies to keep (default 30)")
    parser.add_argument("--database", help="the database file to back up (default: the server's database)")
    args = parser.parse_args()
    settings_ini = read_settings()
    folder = (args.folder or chosen_folder() or settings_ini.get("folder", "")).strip()
    keep = args.keep if args.keep is not None else int(settings_ini.get("keep", "30") or 30)
    if not folder:
        fail("No backup folder. Set folder under [backup] in database.ini, or use --folder.")
    source = database_path(args.database)
    if not source.is_file():
        fail(f"Database not found: {source}", folder)
    try:
        Path(folder).mkdir(parents=True, exist_ok=True)
    except OSError as err:
        fail(f"Cannot use the backup folder {folder} ({err}). Is the drive connected?")
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    temp = Path(folder) / f".ims-{stamp}.tmp"
    final = Path(folder) / f"ims-{stamp}.sqlite3"
    try:
        src = sqlite3.connect(str(source), timeout=60)
        dst = sqlite3.connect(str(temp))
        try:
            src.backup(dst)
            checked = dst.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            dst.close()
            src.close()
    except sqlite3.Error as err:
        temp.unlink(missing_ok=True)
        fail(f"Copy failed: {err}", folder)
    if checked != "ok":
        temp.unlink(missing_ok=True)
        fail("The copy failed the check and was not kept.", folder)
    os.replace(temp, final)
    removed = keep_only(folder, keep)
    log(folder, f"OK {final.name} ({final.stat().st_size} bytes). Copies kept: {keep}. Old copies removed: {removed}.")


if __name__ == "__main__":
    main()
