/* ===== Expenses: several items per expense, same layout as Enter Sales / Enter Purchases =====
   One expense = one record in db.exp. Each item has its own expense category, expense type, unit,
   quantity, unit price and discount. The record keeps cat/etype from its first item, and rec.total = sum of
   the item totals, so the Balance Sheet, reports, cheque balances and the AI agent keep reading the same fields.
   Approval: a user who is not an approver saves the expense as "Pending" (sent for approval). It counts only
   after an approver approves it. The entries list is hidden until you search or press "Show all entries". */

const EXP_UNITS = [["days", "Days"], ["pcs", "Pcs"], ["feet", "Feet"], ["other", "Others"]];

function expUI(root) {
  const f = n => root.querySelector(`[name=${n}]`);
  const box = () => root.querySelector(".sp-items");
  const cards = () => [...box().querySelectorAll(".sp-item")];
  let selId = null, armed = false, q = "", showAll = false;

  const opt = (list, sel, blank = "---------") =>
    [["", blank]].concat(list).map(([v, t]) => `<option value="${spEsc(v)}" ${String(v) === String(sel ?? "") ? "selected" : ""}>${spEsc(t)}</option>`).join("");
  const unitOpt = sel => EXP_UNITS.map(([v, t]) => `<option value="${v}" ${v === (sel || "pcs") ? "selected" : ""}>${t}</option>`).join("");
  const nameOf2 = (list, id) => { const x = list.find(v => v.id == id) || goneIn(list, id); return x ? x.name : "" };
  /* the Expense Types linked to a category (all types if the category has none, so older data still works) */
  /* Expense Types are offered only for the chosen Expense Category: exactly the types linked to it on the Expense Type page */
  const etypesFor = cat => (cat ? db.etype.filter(t => t.cat == cat) : []);
  const typeOptions = (cat, keep) => {
    if (!cat) return `<option value="">Choose the Expense Category first</option>`;
    const L = etypesFor(cat);
    if (!L.length) return `<option value="">No expense types are linked to this category</option>`;
    return opt(L.map(c => [c.id, c.name]), keep);
  };
  function refreshEtype(card) {
    const et = card.querySelector("[name=etype]"), cat = card.querySelector("[name=cat]").value, keep = et.value;
    et.innerHTML = typeOptions(cat, keep);
    et.disabled = !cat || !etypesFor(cat).length;
    const still = [...et.options].some(o => o.value === String(keep));   // keep the type only if it belongs to this category
    et.value = still ? String(keep) : "";
  }
  const chequesFor = acct => db.led.filter(l => l.mode === "cheque" && l.cr > 0 && l.acct == acct);
  const chequeLeft = (l, exceptId) => l.cr - used(l, exceptId);

  root.classList.add("sp-page");
  root.innerHTML = `<h1>Enter Expenses</h1><div class="m"></div>
    <div class="grp sp-hdr"><div class="g">
      <div><label>Date</label><input class="inp" type="date" name="date"></div>
      <div><label>Receipt No (auto)</label><input class="inp" name="rno" readonly></div>
      <div><label>Payment</label><select class="inp" name="mode" data-plain="1"><option value="cash">Cash</option><option value="bank">Bank (cheque)</option></select></div>
      <div><label>From bank account</label><select class="inp" name="acct" disabled data-plain="1"></select></div>
      <div><label>Cheque</label><select class="inp" name="cheque" disabled data-plain="1"></select></div>
      <div><label>Project *</label><select class="inp" name="proj" data-plain="1"></select></div>
      <div><label>Vendor (optional)</label><select class="inp" name="vend" data-plain="1"></select></div>
      <div><label>Receipt (optional: PDF, JPG, PNG)</label><input class="inp" type="file" name="rfile" accept=".pdf,.jpg,.jpeg,.png"></div>
      <div><label>Comments</label><input class="inp" name="comments"></div>
    </div></div>
    <div class="sp-cheque-note"></div>
    <div class="sp-itemsbar"><span class="sp-count">Items: <b name="cnt">0</b></span></div>
    <div class="sp-items"></div>
    <div class="sp-totals">
      <button type="button" class="btn sp-add" data-b="add">Add item</button>
      <span>Subtotal Rs <b name="sub">0.00</b></span><span>Discount Rs <b name="dsc">0.00</b></span>
      <span class="sp-net">Total Rs <b name="net">0.00</b></span>
    </div>
    <div class="btns"><button type="button" class="btn" data-b="new">New</button>
      <button type="button" class="btn p" data-b="save">Save</button>
      <button type="button" class="btn d" data-b="del">Delete</button>
      <button type="button" class="btn" data-b="pop">Open data in separate window</button></div>
    <div class="sp-find">
      <input class="inp" type="search" name="find" placeholder="Find expense by receipt no, category, expense type or project">
      <button type="button" class="btn" data-b="all">Show all entries</button></div>
    <div class="tw sp-listwrap" hidden><table class="dt sp-list"><thead><tr>
      <th>Date</th><th>Receipt No</th><th>Category</th><th>Expense type</th><th>Project</th>
      <th class="num">Qty</th><th>Unit</th><th class="num">Unit price</th><th class="num">Discount</th><th class="num">Item total</th>
      <th>Status</th><th>Entered by</th></tr></thead><tbody></tbody><tfoot></tfoot></table></div>`;

  const msg = (t, k) => { root.querySelector(".m").innerHTML = t ? `<div class="msg ${k}">${spEsc(t)}</div>` : "" };

  function fillHeader(rec) {
    f("date").value = rec ? rec.date : T;
    f("rno").value = rec ? rec.rno : nextRno();
    f("mode").value = rec ? (rec.mode || "cash") : "cash";
    f("proj").innerHTML = opt(db.proj.map(c => [c.id, c.name]), rec ? rec.proj : "");
    f("vend").innerHTML = opt(db.vend.map(c => [c.id, c.name]), rec ? rec.vend : "");
    f("acct").innerHTML = opt(db.bank.map(b => [b.id, `${b.bank} - ${b.title}`]), rec ? rec.acct : "");
    f("comments").value = rec ? (rec.comments || "") : "";
    f("rfile").value = "";
    syncPayment(rec ? rec.cheque : "");
  }
  function syncPayment(keepCheque) {
    const bank = f("mode").value === "bank";
    f("acct").disabled = !bank;
    if (!bank) f("acct").value = "";
    const acct = f("acct").value;
    const list = bank && acct ? chequesFor(acct) : [];
    f("cheque").disabled = !(bank && acct);
    f("cheque").innerHTML = opt(list.map(l => [l.id, `Chq ${l.cno} | ${l.cbank} | Rs ${fm(l.cr)} | remaining ${fm(chequeLeft(l, selId))}`]), keepCheque || "");
    if (!bank) f("cheque").value = "";
    chequeNote();
  }
  function chequeNote() {
    const note = root.querySelector(".sp-cheque-note");
    const l = db.led.find(x => x.id == f("cheque").value);
    const total = cards().reduce((t, c) => t + spR2(spNum(c.querySelector("[name=qty]").value) * spNum(c.querySelector("[name=price]").value) - spNum(c.querySelector("[name=disc]").value)), 0);
    if (f("mode").value !== "bank" || !l) { note.innerHTML = ""; return }
    const left = chequeLeft(l, selId), after = spR2(left - total);
    note.innerHTML = `<div class="msg ${after < 0 ? "bad" : "ok"}">Cheque Rs ${fm(l.cr)} | remaining ${fm(left)} | ${after < 0 ? `this expense is Rs ${fm(-after)} over the cheque` : `after this expense Rs ${fm(after)} remains`}</div>`;
  }

  function itemHtml(l, n) {
    const qty = l.qty == null ? "" : l.qty, price = l.price == null ? "" : l.price, disc = l.disc == null ? "" : l.disc;
    const total = spR2(spNum(qty) * spNum(price) - spNum(disc));
    return `<div class="sp-item sp-exp-grid sp-c${(n - 1) % 6}">
      <span class="sp-no">${n}</span>
      <select class="inp" name="cat" data-plain="1">${opt(db.cat.map(c => [c.id, c.name]), l.cat)}</select>
      <select class="inp" name="etype" data-plain="1" ${l.cat && etypesFor(l.cat).length ? "" : "disabled"}>${typeOptions(l.cat, l.etype)}</select>
      <select class="inp" name="unit" data-plain="1">${unitOpt(l.unit)}</select>
      <input class="inp" type="number" name="qty" min="1" step="1" value="${qty}" placeholder="qty">
      <input class="inp" type="number" name="price" min="0" step="0.01" value="${price}" placeholder="unit price">
      <input class="inp" type="number" name="disc" min="0" step="0.01" value="${disc}" placeholder="discount">
      <span class="lt num">${fm(total)}</span>
      <button type="button" class="btn sp-rm" data-rm>&times;</button></div>`;
  }
  function drawItems(lines) {
    const list = lines && lines.length ? lines : [{}];
    box().innerHTML = `<div class="sp-exp-grid sp-colhead"><span>#</span><span>Expense category *</span><span>Expense type</span><span>Unit</span><span>Qty (whole)</span><span>Unit price</span><span>Discount</span><span class="num">Total</span><span></span></div>` +
      list.map((l, i) => itemHtml(l, i + 1)).join("");
    recalc();
  }
  function renumber() { cards().forEach((c, i) => { c.querySelector(".sp-no").textContent = String(i + 1) }) }
  function recalc() {
    const n = cards().length;
    root.querySelector("[name=cnt]").textContent = n;
    let sub = 0, dsc = 0;
    cards().forEach(c => {
      const qty = spNum(c.querySelector("[name=qty]").value), price = spNum(c.querySelector("[name=price]").value), disc = spNum(c.querySelector("[name=disc]").value);
      const t = spR2(qty * price - disc);
      sub += spR2(qty * price); dsc += disc;
      c.querySelector(".lt").textContent = fm(t);
    });
    root.querySelector("[name=sub]").textContent = fm(sub);
    root.querySelector("[name=dsc]").textContent = fm(dsc);
    root.querySelector("[name=net]").textContent = fm(sub - dsc);
    chequeNote();
  }
  function readLines() {
    return cards().map(c => {
      const g = k => c.querySelector(`[name=${k}]`).value;
      return { cat: g("cat"), etype: g("etype"), unit: g("unit") || "pcs", qty: g("qty"), price: g("price"), disc: g("disc") || "0" };
    }).filter(l => l.cat || l.qty !== "" || l.price !== "");
  }

  function check(L) {
    if (!f("proj").value) return "Project is required - choose the project this expense belongs to.";
    if (!L.length) return "Add at least one item.";
    for (const l of L) {
      const q = +l.qty, p = +l.price, d = +l.disc || 0;
      if (!l.cat) return "Choose the expense category on every item.";
      if (l.etype) {
        const ty = db.etype.find(x => x.id == l.etype);
        if (ty && ty.cat && ty.cat != l.cat) return `Expense Type "${ty.name}" belongs to the category ${catName(ty.cat)}. Choose that category, or another type.`;
      }
      if (!(Number.isInteger(q) && q > 0)) return "Quantity must be a whole number (1, 2, 3...) on every item.";
      if (l.price === "" || !(p >= 0)) return "Enter a valid unit price on every item.";
      if (d < 0) return "Discount cannot be negative.";
      if (d > q * p + 1e-9) return `Discount cannot be more than quantity x unit price (Rs ${fm(q * p)}) on an item.`;
    }
    if (f("mode").value === "bank") {
      if (!f("acct").value) return "Choose the bank account.";
      if (!f("cheque").value) return "Choose the cheque this expense is paid from.";
      const l = db.led.find(x => x.id == f("cheque").value);
      const total = L.reduce((t, x) => t + spR2(spNum(x.qty) * spNum(x.price) - spNum(x.disc)), 0);
      if (!l) return "The cheque was not found.";
      if (total > chequeLeft(l, selId) + 0.001) return `This expense is Rs ${fm(total - chequeLeft(l, selId))} more than the cheque balance.`;
    }
    return "";
  }

  /* Entries list: one row per item, with Qty, Unit, Unit price, Discount and Item total, and totals. */
  function list() {
    const text = q.trim().toLowerCase();
    const wrap = root.querySelector(".sp-listwrap");
    const visible = !!text || showAll;
    wrap.hidden = !visible;
    root.querySelector("[data-b=all]").textContent = showAll ? "Hide entries" : "Show all entries";
    if (!visible) return;
    const rows = [];
    db.exp.slice().reverse().forEach(r => expLines(r).forEach(l => {
      const hay = [r.rno, nameOf2(db.proj, r.proj), nameOf2(db.cat, l.cat), nameOf2(db.etype, l.etype)].join(" ").toLowerCase();
      if (!text || hay.includes(text)) rows.push({ r, l });
    }));
    let tDisc = 0, tTot = 0;
    rows.forEach(({ r, l }) => { tDisc += +l.disc || 0; tTot += l.total != null ? +l.total : expLineTotal(l) });
    const body = rows.slice(0, 200).map(({ r, l }) => {
      const itemTot = l.total != null ? +l.total : expLineTotal(l);
      return `<tr class="${r.id == selId ? "sel" : ""}" data-id="${r.id}">
        <td>${r.date}</td><td>${spEsc(r.rno || "")}</td><td>${spEsc(nameOf2(db.cat, l.cat))}</td>
        <td>${spEsc(nameOf2(db.etype, l.etype))}</td><td>${spEsc(nameOf2(db.proj, r.proj))}</td>
        <td class="num">${spEsc(l.qty)}</td><td>${spEsc(EXP_UNIT_NAME[l.unit] || l.unit || "")}</td>
        <td class="num">${fm(l.price)}</td><td class="num">${fm(l.disc || 0)}</td><td class="num">${fm(itemTot)}</td>
        <td>${spEsc(stTxt(r))}</td><td>${spEsc(spBy(r.by))}</td></tr>`;
    }).join("");
    root.querySelector(".sp-list tbody").innerHTML = rows.length ? body : `<tr><td colspan="12" style="color:var(--muted)">No expenses found.</td></tr>`;
    root.querySelector(".sp-list tfoot").innerHTML = rows.length
      ? `<tr class="st-tot"><td colspan="8">Total (${rows.length} item${rows.length === 1 ? "" : "s"})</td><td class="num">${fm(tDisc)}</td><td class="num">${fm(tTot)}</td><td colspan="2"></td></tr>`
      : "";
  }

  function load(rec) {
    armed = false;
    root.querySelector('[data-b=del]').textContent = "Delete";
    selId = rec ? rec.id : null;
    fillHeader(rec);
    drawItems(rec ? expLines(rec).map(l => ({ ...l, cat: l.cat ?? rec.cat, etype: l.etype ?? rec.etype })) : []);
    list();
  }

  async function save() {
    if (!canAdd() && !selId) return msg("You do not have permission to add expenses.", "bad");
    if (selId && !canEdit()) return msg("You do not have permission to edit expenses.", "bad");
    const L = readLines();
    const err = check(L);
    if (err) return msg(err, "bad");
    const fl = f("rfile").files[0] || null;
    if (fl && !okFile(fl)) return msg("Only PDF, JPG/JPEG and PNG files can be uploaded.", "bad");
    if (fl && fl.size > 10 * 1024 * 1024) return msg("The file is larger than 10 MB.", "bad");
    const lines = L.map(l => ({ cat: +l.cat, etype: l.etype ? +l.etype : "", unit: l.unit || "pcs", qty: +l.qty, price: +l.price, disc: +l.disc || 0, total: spR2(+l.qty * +l.price - (+l.disc || 0)) }));
    const total = spR2(lines.reduce((t, l) => t + l.total, 0));
    const approver = isApprover();
    const rnoNow = selId ? (db.exp.find(x => x.id == selId) || {}).rno : nextRno();
    const ok = await askSave(`${selId ? "Update" : "Save"} expense ${rnoNow} (${lines.length} item${lines.length > 1 ? "s" : ""}, total Rs ${fm(total)})?` +
      (approver ? "" : " It will be sent for approval and will not count until an approver approves it."));
    if (!ok) return;
    const bank = f("mode").value === "bank";
    let rfile = null;
    if (fl) rfile = await uploadFile(fl);
    else if (selId) rfile = db.exp.find(x => x.id == selId).rfile || null;
    const rec = {
      date: f("date").value || T, rno: f("rno").value || nextRno(), mode: bank ? "bank" : "cash",
      acct: bank ? f("acct").value : "", cheque: bank ? f("cheque").value : "",
      cat: lines[0].cat, etype: lines[0].etype, proj: +f("proj").value,
      vend: f("vend").value ? +f("vend").value : "", comments: f("comments").value.trim(), lines, total, rfile
    };
    let saved;
    if (selId) {
      saved = db.exp.find(x => x.id == selId);
      Object.assign(saved, rec, expStatus());          // a non-approver's change goes back to Pending
      saved.upBy = me; saved.upAt = new Date().toISOString();
      persist("exp", saved); logH("Updated", "Expenses", rec.rno);
    } else {
      saved = { id: nid(), by: me, ...rec, ...expStatus() };
      db.exp.push(saved); persist("exp", saved); logH("Added", "Expenses", rec.rno);
    }
    load(saved);                                       // keep the saved expense on screen, items included
    msg(approver
      ? `Expense ${saved.rno} saved and approved. Qty, unit, unit price and discount are shown below.`
      : `Expense ${saved.rno} saved and sent for approval. It counts only after an approver approves it.`, "ok");
  }

  function del() {
    if (!canDel()) return msg("You do not have permission to delete expenses.", "bad");
    if (!selId) return;
    if (!armed) {
      armed = true;
      root.querySelector('[data-b=del]').textContent = "Confirm delete";
      return msg("Click Delete again to confirm.", "bad");
    }
    armed = false;
    const r = db.exp.find(x => x.id == selId);
    db.exp.splice(db.exp.indexOf(r), 1); unpersist("exp", r); logH("Deleted", "Expenses", r.rno || "");
    load(null); msg("Expense deleted.", "ok");
  }

  root.oninput = e => {
    const t = e.target;
    if (t.name === "find") { q = t.value; list(); return }
    if (t.closest(".sp-items")) recalc();
  };
  root.onchange = e => {
    const t = e.target;
    if (t.name === "mode") syncPayment("");
    if (t.name === "acct") syncPayment("");
    if (t.name === "cheque") chequeNote();
    if (t.name === "etype" && t.closest(".sp-item")) {
      // a chosen Expense Type sets its Expense Category, exactly as set on the Expense Type page
      const card = t.closest(".sp-item"), ty = db.etype.find(x => x.id == t.value), catSel = card.querySelector("[name=cat]");
      if (ty && ty.cat && catSel.value != ty.cat) { catSel.value = ty.cat; catSel.dispatchEvent(new Event("change", { bubbles: true })) }
    }
    if (t.name === "cat" && t.closest(".sp-item")) refreshEtype(t.closest(".sp-item"));
    if (t.closest(".sp-items")) recalc();
  };
  root.onclick = e => {
    const rm = e.target.closest("[data-rm]");
    if (rm && !rm.disabled) { rm.closest(".sp-item").remove(); renumber(); recalc(); return }
    const row = e.target.closest("tr[data-id]");
    if (row) { const r = db.exp.find(x => x.id == row.dataset.id); if (r) { load(r); msg("") } return }
    const b = e.target.closest("[data-b]")?.dataset.b;
    if (!b) return;
    if (b === "add") { box().insertAdjacentHTML("beforeend", itemHtml({}, cards().length + 1)); renumber(); recalc(); return }
    if (b === "all") { showAll = !showAll; list(); return }
    if (b === "new") { load(null); msg(""); return }
    if (b === "save") return save();
    if (b === "del") return del();
    if (b === "pop") return openW("data:exp");
  };
  load(null);
}
