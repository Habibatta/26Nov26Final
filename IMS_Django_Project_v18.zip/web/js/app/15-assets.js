/* ===== Assets Registration: fixed assets the business buys =====
   Each asset: purchase date (chosen), Asset No (automatic, e.g. AST-2026-00001), vendor (optional),
   asset name (required), unit, qty and price (whole numbers), and total = qty x price (automatic).
   The Balance Sheet's "Fixed assets" is the total of the assets bought on or before the as-at date. */
const ASSET_UNITS = [["Pcs", "Pcs"], ["KG", "KG"], ["Mtr", "Mtr"], ["Gz", "Gz"], ["Pack", "Pack"], ["Others", "Others"]];

/* the next number for the year of the purchase date: AST-2026-00001, AST-2026-00002 ... */
function assetNoFor(dateStr, exceptId) {
  const prefix = "AST-" + String(dateStr || T).slice(0, 4) + "-";
  const used = db.asset.filter(a => a.id != exceptId && String(a.no || "").startsWith(prefix))
    .map(a => parseInt(String(a.no).slice(prefix.length), 10) || 0);
  return prefix + String(Math.max(0, ...used) + 1).padStart(5, "0");
}

/* the total of the assets bought on or before the as-at date (used by the Balance Sheet) */
function assetsTotal(asAt) {
  return Math.round(db.asset.filter(a => (a.date || "") <= asAt).reduce((s, a) => s + (+a.total || 0), 0) * 100) / 100;
}

CF.asset = {
  t: "Assets Registration",
  f: [
    ["date", "Purchase date", "date"],
    ["proj", "Project (optional)", "sel", () => []],
    ["no", "Asset No (automatic)", "ro"],
    ["vend", "Vendor (optional)", "sel", () => []],
    ["name", "Asset name", "text"],
    ["unit", "Unit", "sel", () => ASSET_UNITS],
    ["qty", "Qty (whole number)", "int"],
    ["price", "Price, Rs (whole number)", "int"],
    ["total", "Total, Rs (automatic)", "ro"],
  ],
  cols: [
    ["Purchase date", r => r.date],
    ["Project", r => (db.proj.find(x => x.id == r.proj) || {}).name || ""],
    ["Asset No", r => r.no],
    ["Asset name", r => r.name],
    ["Vendor", r => (db.vend.find(x => x.id == r.vend) || {}).name || ""],
    ["Unit", r => r.unit],
    ["Qty", r => r.qty, 1],
    ["Price", r => fm(r.price), 1],
    ["Total", r => fm(r.total), 1, "sum"],
    ["Entered by", r => r.by || ""],
    ["Updated by", r => r.upBy || ""],
  ],
  list: () => db.asset,
  build: v => {
    if (!v.date) return "Choose the purchase date.";
    if (!String(v.name || "").trim()) return "Asset name is required.";
    const qty = Number(v.qty), price = Number(v.price);
    if (!Number.isInteger(qty) || qty < 1) return "Qty must be a whole number (1 or more).";
    if (!Number.isInteger(price) || price < 0) return "Price must be a whole number (0 or more).";
    return { date: v.date, no: v.no || assetNoFor(v.date), proj: v.proj ? +v.proj : "", vend: v.vend ? +v.vend : "",
             name: String(v.name).trim(), unit: v.unit || "Pcs", qty, price, total: qty * price };
  },
};

/* the form's automatic fields: the vendor list, the Asset No for a new asset, and the total */
CF.asset.wire = (g, $f, getSel) => {
  const d = $f("date"), q = $f("qty"), p = $f("price"), t = $f("total"), n = $f("no"), vs = $f("vend"), ps = $f("proj");
  const fillOne = (el, rows, none) => {
    const cur = el.value;
    el.innerHTML = [["", none]].concat(rows.map(x => [x.id, x.name]))
      .map(([v, label]) => `<option value="${v}">${label}</option>`).join("");
    el.value = cur;
  };
  const fillVendors = () => { fillOne(vs, db.vend, "No vendor"); fillOne(ps, db.proj, "No project") };
  const upd = () => {
    const qty = Number(q.value) || 0, price = Number(p.value) || 0;
    t.value = String(qty * price);
    if (!getSel()) n.value = assetNoFor(d.value || T);
    fillVendors();
  };
  [d, q, p].forEach(e => e.addEventListener("input", upd));
  d.addEventListener("change", upd);
  vs.addEventListener("mousedown", fillVendors);
  ps.addEventListener("mousedown", fillVendors);
  g._s = upd;
  upd();
};
