/* ===== Searchable dropdowns: every drop-down in the application (mouse, keyboard and touch) =====
   Each <select> keeps its value and still fires 'input' and 'change', so every existing handler works.
   It is shown as a box. Tapping or clicking the box (or Enter / Space / ArrowDown on it) opens a list with a
   "Type to search..." field. Typing filters the list; choosing writes the value back to the select.
   Dropdowns that appear later (new windows, new rows, new screens) are picked up automatically.
   Keys: type to filter, ArrowUp / ArrowDown move, Enter chooses, Escape closes. */
(function () {
  if (window.__searchableSelect) return;
  window.__searchableSelect = true;

  var pop = null, cur = null, curTrig = null, list = [], hi = 0;

  function labelOf(sel) { var o = sel.options[sel.selectedIndex]; return o ? o.text : "" }

  function sync(sel) {
    var t = sel._ssT; if (!t) return;
    var txt = labelOf(sel) || "---------", v = t.querySelector(".ssel-v");
    if (v.textContent !== txt) v.textContent = txt;
    v.classList.toggle("ph", !sel.value);
    t.classList.toggle("dis", !!sel.disabled);
    t.tabIndex = sel.disabled ? -1 : 0;
    t.setAttribute("aria-disabled", sel.disabled ? "true" : "false");
  }

  function wrap(sel) {
    if (sel.dataset.ssel || !sel.parentNode) return;
    sel.dataset.ssel = "1";
    var w = document.createElement("div"); w.className = "ssel-w";
    var t = document.createElement("div");
    t.className = "inp ssel-t"; t.setAttribute("role", "combobox"); t.setAttribute("aria-haspopup", "listbox");
    t.innerHTML = '<span class="ssel-v"></span><span class="ssel-c" aria-hidden="true">&#9662;</span>';
    sel.parentNode.insertBefore(w, sel);
    w.appendChild(t); w.appendChild(sel);
    sel.style.display = "none"; sel.setAttribute("aria-hidden", "true"); sel.tabIndex = -1;
    sel._ssT = t; t._sel = sel;
    sync(sel);
  }

  function scan(node) {
    if (!node || node.nodeType !== 1) return;
    if (node.tagName === "SELECT") wrap(node);
    else if (node.querySelectorAll) node.querySelectorAll("select").forEach(wrap);
  }

  function close() {
    if (pop) pop.remove();
    pop = null; cur = null; curTrig = null; list = []; hi = 0;
  }

  function position() {
    if (!pop || !curTrig) return;
    var r = curTrig.getBoundingClientRect(), narrow = window.innerWidth < 760;
    var w = Math.max(r.width, 220);
    pop.style.width = narrow ? "calc(100vw - 16px)" : w + "px";
    pop.style.left = narrow ? "8px" : Math.max(4, Math.min(r.left, window.innerWidth - w - 4)) + "px";
    var h = Math.min(pop.offsetHeight || 300, Math.round(window.innerHeight * 0.6));
    var below = window.innerHeight - r.bottom - 8;
    var top = below >= h || below >= r.top ? r.bottom + 2 : r.top - h - 2;
    pop.style.top = Math.max(4, top) + "px";
  }

  function paint() {
    var box = pop.querySelector(".ssel-list");
    box.innerHTML = "";
    if (!list.length) {
      var none = document.createElement("div");
      none.className = "ssel-none";
      none.textContent = cur.options.length ? "No match" : "No choices";
      box.appendChild(none);
      return;
    }
    list.forEach(function (o, k) {
      var d = document.createElement("div");
      d.className = "ssel-o" + (k === hi ? " hi" : "") + (o.idx === cur.selectedIndex ? " sel" : "") + (o.disabled ? " dis" : "");
      d.dataset.k = String(k);
      d.textContent = o.text || "\u00a0";
      box.appendChild(d);
    });
    var active = box.querySelector(".ssel-o.hi");
    if (active && active.scrollIntoView) active.scrollIntoView({ block: "nearest" });
  }

  function filter(text) {
    var s = (text || "").trim().toLowerCase();
    list = [];
    Array.prototype.forEach.call(cur.options, function (o, i) {
      if (!s || o.text.toLowerCase().indexOf(s) !== -1) list.push({ text: o.text, value: o.value, disabled: o.disabled, idx: i });
    });
    hi = 0;
    paint();
  }

  function choose(k) {
    var o = list[k];
    if (!o || o.disabled || !cur) return;
    var sel = cur, t = curTrig;
    close();
    sel.selectedIndex = o.idx;
    sync(sel);
    sel.dispatchEvent(new Event("input", { bubbles: true }));
    sel.dispatchEvent(new Event("change", { bubbles: true }));
    if (t) t.focus();
  }

  function open(sel) {
    if (!sel || sel.disabled) return;
    close();
    cur = sel; curTrig = sel._ssT;
    pop = document.createElement("div");
    pop.className = "ssel-pop";
    pop.innerHTML = '<input class="inp ssel-q" type="search" placeholder="Type to search..." autocomplete="off" autocapitalize="off" spellcheck="false"><div class="ssel-list" role="listbox"></div>';
    document.body.appendChild(pop);
    var q = pop.querySelector(".ssel-q");
    pop.addEventListener("click", function (e) {
      var it = e.target.closest && e.target.closest(".ssel-o");
      if (it) choose(+it.dataset.k);
    });
    q.addEventListener("input", function () { filter(q.value) });
    q.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown") { hi = Math.min(hi + 1, list.length - 1); paint(); e.preventDefault(); }
      else if (e.key === "ArrowUp") { hi = Math.max(hi - 1, 0); paint(); e.preventDefault(); }
      else if (e.key === "Enter") { e.preventDefault(); choose(hi); }
      else if (e.key === "Escape") { e.preventDefault(); var t = curTrig; close(); if (t) t.focus(); }
      else if (e.key === "Tab") { close(); }
    });
    filter("");
    position();
    q.focus();
  }

  // Tap or click on a dropdown box opens it (works with a mouse, a finger or a pen).
  document.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest(".ssel-t");
    if (t && t._sel) {
      e.preventDefault();
      if (pop && cur === t._sel) { close(); return; }
      open(t._sel);
      return;
    }
    if (pop && !(e.target.closest && e.target.closest(".ssel-pop"))) close();
  }, true);

  // Keyboard on a focused dropdown box.
  document.addEventListener("keydown", function (e) {
    var t = e.target;
    if (!pop && t && t.classList && t.classList.contains("ssel-t") && t._sel &&
        (e.key === "Enter" || e.key === " " || e.key === "ArrowDown")) {
      e.preventDefault();
      open(t._sel);
    }
  }, true);

  // Keep the list next to its box while the page or a window scrolls; close it if the box scrolls away.
  document.addEventListener("scroll", function (e) {
    if (!pop) return;
    if (e.target && e.target.nodeType === 1 && pop.contains(e.target)) return;
    if (curTrig && curTrig.isConnected) {
      var r = curTrig.getBoundingClientRect();
      if (r.bottom < 0 || r.top > window.innerHeight) close(); else position();
    } else close();
  }, true);
  window.addEventListener("resize", function () { if (pop) position() });

  // Dropdowns added later are wrapped as soon as they appear; selects whose disabled state or options
  // change through code are re-read on a short timer.
  new MutationObserver(function (ms) { ms.forEach(function (m) { m.addedNodes.forEach(scan) }) })
    .observe(document.documentElement, { childList: true, subtree: true });
  setInterval(function () {
    document.querySelectorAll("select[data-ssel]").forEach(sync);
    if (pop && (!cur || !cur.isConnected)) close();
  }, 250);

  scan(document.body);
})();
