/* Storage/runtime hooks, reports (Excel/PDF) */
/* ===== runtime capabilities & persistence ===== */
let STORE=null,ASSETS=null,DL=null,SAMPLE=null,CAN_WRITE=true;
const COLS=["cat","proj","vend","etype","purch","sales","bank","led","exp","emp","sal","att","paid","appr","presence","hist","rooms","msgs","hol","memo","asset"];
function noteDefault(){const n=$("#note");n.style.color="";n.textContent=window.IMS_LOCAL&&IMS_LOCAL.noStore?"Warning: the data server is not reachable, so changes cannot be saved. Start the server with python app.py.":window.IMS_LOCAL?"Saved on this computer by the Python server (data/ims.db). Use File → Backup data regularly, and keep the backup file safe.":STORE?"Saved automatically in this page’s shared database. Everyone with Contributor access sees the same data.":"Demo mode: data is not saved. Open this page signed in to claude.ai to keep your data."}
function toast(t){const n=$("#note");n.style.color="var(--bad)";n.textContent=t;clearTimeout(toast._t);toast._t=setTimeout(noteDefault,7000)}
const clean=o=>JSON.parse(JSON.stringify(o));
function persist(col,rec){if(!STORE||!CAN_WRITE)return;STORE.collection(col).doc(String(rec.id)).set(clean(rec)).catch(e=>toast("Could not save: "+(e&&(e.message||e.code)||e)))}
function unpersist(col,rec){if(STORE)STORE.collection(col).doc(String(rec.id)).delete().catch(()=>{})}
function persistUser(n){if(STORE)STORE.collection("users").doc(n).set(clean(db.users[n])).catch(e=>toast("Could not save user: "+(e&&(e.message||e.code)||e)))}
function unpersistUser(n){if(STORE)STORE.collection("users").doc(n).delete().catch(()=>{})}
async function H(p){if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode("ims-v1:"+p));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}return window.__sha256("ims-v1:"+p)}
let PD=false;document.addEventListener("pointerdown",()=>{PD=true},true);document.addEventListener("pointerup",()=>{setTimeout(()=>{PD=false},60)},true);document.addEventListener("pointercancel",()=>{PD=false},true);
let tickT=null;const tick=()=>{clearTimeout(tickT);tickT=setTimeout(()=>{if(PD){tick();return}Object.values(wins).forEach(w=>{const b=w.el.querySelector(".wb");try{b&&b._tick&&b._tick()}catch(e){}});notifyChanges();badge()},150)};
function sub(col){return new Promise(res=>{let first=true;STORE.collection(col).onSnapshot(s=>{
 if(col==="users"){const u={};s.docs.forEach(d=>u[d.id]=d.data());db.users=u}else{const rows=s.docs.map(d=>d.data());if(col==="hist")rows.forEach(h=>h.at=new Date(h.at));rows.sort((a,b)=>a.id-b.id);db[col]=withTrash(col,rows)}
 if(first){first=false;res()}else (col==="presence"?tickChat():tick())},()=>{if(first){first=false;res()}})})}
async function init0(){
 try{if(window.claude&&claude.use){[STORE,ASSETS,DL,SAMPLE]=await Promise.all(["db","assets","downloads","sample"].map(n=>Promise.resolve(claude.use(n)).catch(()=>null)));
  const us=await Promise.resolve(claude.use("user")).catch(()=>null);if(us&&us.can){const w=us.can("data.write");if(w===false)CAN_WRITE=false}}}catch(e){}
 if(STORE)await Promise.race([Promise.all(["users",...COLS].map(sub)),new Promise(r=>setTimeout(r,8000))]);
 const def=await H("admin123");let msg;
 if(!Object.keys(db.users).length){if(STORE&&!CAN_WRITE)msg="This system has not been set up yet. Ask the owner to open it once."; else{db.users.admin={pw:def,su:true};persistUser("admin")}}
 msg=msg||(db.users.admin&&db.users.admin.pw===def?"First time? Sign in as <b>admin / admin123</b>, then change the password in Users &amp; Rights.":"Sign in with your account.");
 $("#lh").innerHTML=msg;$("#lb2").disabled=!Object.keys(db.users).length;noteDefault()}
async function init(){try{await Promise.race([init0(),new Promise((_,rej)=>setTimeout(()=>rej(new Error("start-up timed out")),15000))])}catch(e){if(!Object.keys(db.users).length)db.users.admin={pw:await H("admin123"),su:true};$("#lh").innerHTML="Started in safe mode ("+String(e&&e.message||e).replace(/</g,"&lt;")+"). Sign in as <b>admin / admin123</b>. Data may not be saved.";$("#lb2").disabled=false;try{noteDefault()}catch(x){}}}
async function uploadFile(f){if(ASSETS){try{const r=await ASSETS.upload(f);return{u:r.url,n:f.name}}catch(e){toast("Upload failed ("+(e&&(e.code||e.message)||e)+"); the file is kept for this session only.")}}else toast("Uploads are not available at your access level; the file is kept for this session only.");return{u:URL.createObjectURL(f),n:f.name}}
/* ===== reports ===== */
function repData(k,f,t,q){q=(q||"").toLowerCase();let h,rows,tot=null,title;
 if(k==="history"){title="History";h=["Date","Time","User","Action","Page","Details"];rows=db.hist.map(x=>[x.at.toISOString().slice(0,10),x.at.toTimeString().slice(0,8),x.user,x.a,x.p,String(x.d)]).filter(r=>(!f||r[0]>=f)&&(!t||r[0]<=t)&&(!q||r.join(" ").toLowerCase().includes(q)))}
 else{const c=CF[k];title=c.t;const cc=c.cols.filter(x=>!["Cheque Copy","Receipt","Picture"].includes(x[0]));h=cc.map(x=>x[0]);rows=(c.rows||c.list)().filter(r=>(!f||r.date>=f)&&(!t||r.date<=t)).map(r=>cc.map(x=>String(x[1](r)??""))).filter(r=>!q||r.join(" ").toLowerCase().includes(q));
  const SUMC={exp:["Item Total"],led:["Dr","Cr"],paid:["Gross","Deduction","Net Salary"],sal:["Gross"],purch:["Amount"],sales:["Amount"]}[k];if(SUMC){const ix=SUMC.map(n=>h.indexOf(n));tot=h.map((x,i)=>ix.includes(i)?fm(rows.filter(r=>k!=="exp"||String(r[h.indexOf("Status")]).startsWith("Approved")).reduce((a,r)=>a+(parseFloat(String(r[i]).replace(/,/g,""))||0),0)):i===0?"TOTAL":"")}}
 return{title,h,rows,tot}}
async function saveReport(k,fmt,f,t,q){if(!DL){toast("Downloads are not available in this view.");return}
 const d=repData(k,f,t,q),name=d.title.replace(/[^\w]+/g,"_")+"_"+new Date().toISOString().slice(0,10);
 const num=v=>/^-?[\d,]+\.\d\d$/.test(v)?parseFloat(v.replace(/,/g,"")):v;
 try{
  if(fmt==="xlsx"){if(!window.XLSX){await DL.save({filename:name+".csv",data:[d.h,...d.rows].map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(",")).join("\r\n")})}
   else{const ws=XLSX.utils.aoa_to_sheet([d.h,...d.rows.map(r=>r.map(num)),...(d.tot?[d.tot.map(num)]:[])]);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,d.title.slice(0,30));await DL.save({filename:name+".xlsx",data:XLSX.write(wb,{type:"array",bookType:"xlsx"})})}}
  else{if(!window.jspdf){toast("The PDF library could not load. Try Excel instead.");return}
   const doc=new window.jspdf.jsPDF({orientation:"landscape",unit:"mm",format:"a4"});doc.setFontSize(14);doc.text(d.title,10,12);doc.setFontSize(8);
   doc.text(`Period: ${f||"start"} to ${t||"today"}   |   Generated ${new Date().toLocaleString()} by ${me}   |   ${d.rows.length} records`,10,17);
   doc.autoTable({head:[d.h],body:[...d.rows,...(d.tot?[d.tot]:[])],startY:20,styles:{fontSize:7,cellPadding:1.2},headStyles:{fillColor:[10,36,106]},margin:{left:10,right:10}});
   await DL.save({filename:name+".pdf",data:doc.output("arraybuffer")})}
  logH("Report "+fmt.toUpperCase(),d.title,`${f||"start"} to ${t||"today"}`)
 }catch(e){if(!e||e.code!=="declined")toast("Download failed: "+(e&&(e.message||e.code)||e))}}
function reportsUI(root){const list=[...["cat","proj","bank","emp","led","exp","sal","paid","purch","sales","stock","asset"].filter(can).map(k=>[k,CF[k].t]),...(can("history")?[["history","History"]]:[])];
 root.innerHTML=`<h1>Reports</h1><div class="grp"><div class="g"><div><label>Report</label><select class="inp" id="rr">${list.map(x=>`<option value="${x[0]}">${x[1]}</option>`).join("")}</select></div><div><label>From date</label><input class="inp" type="date" id="rf"></div><div><label>To date</label><input class="inp" type="date" id="rt"></div><div><label>Search (optional)</label><input class="inp" id="rq"></div></div><div class="btns"><button class="btn" id="rp">Preview</button><button class="btn p" id="rx">Download Excel</button><button class="btn p" id="rd">Download PDF</button></div><div style="color:var(--muted);margin-top:6px">Leave dates empty for all records. Downloads are recorded in History.</div></div><div id="rm" style="color:var(--muted);margin-bottom:4px"></div><div class="tw" style="max-height:48vh"><table class="dt" id="rtb"></table></div>`;
 const args=()=>[$("#rr",root).value,$("#rf",root).value,$("#rt",root).value,$("#rq",root).value];
 $("#rx",root).onclick=()=>saveReport(...args().slice(0,1),"xlsx",...args().slice(1));$("#rd",root).onclick=()=>saveReport(args()[0],"pdf",...args().slice(1));
 $("#rp",root).onclick=()=>{const[k,f,t,q]=args(),d=repData(k,f,t,q);$("#rm",root).textContent=`Period: ${f||"start"} to ${t||"today"}  |  ${d.rows.length} records`;
  $("#rtb",root).innerHTML=`<thead><tr>${d.h.map(x=>`<th>${x}</th>`).join("")}</tr></thead><tbody>${d.rows.map(r=>`<tr style="cursor:default">${r.map(x=>`<td>${String(x).replace(/</g,"&lt;")}</td>`).join("")}</tr>`).join("")||`<tr><td colspan="${d.h.length}" style="color:var(--muted)">No records for these filters.</td></tr>`}${d.tot?`<tr style="cursor:default;font-weight:700">${d.tot.map(x=>`<td>${x}</td>`).join("")}</tr>`:""}</tbody>`}}
