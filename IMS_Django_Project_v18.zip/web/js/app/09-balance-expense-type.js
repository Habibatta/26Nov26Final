/* ===== Expense Type (editable list) and Balance Sheet (simple format, screen + PDF/Excel) ===== */

/* ---- Balance sheet calculations (same rules as the Django version) ---- */
/* Figures calculated from Enter Purchases and Enter Sales (same rules as the Django balance sheet). */
function bsCalc(asAt, start) {
  const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
  const inRange = d => (d || "") <= asAt && (!start || (d || "") >= start);
  let stock = 0, cogs = 0;
  (db.purch || []).filter(p => (p.date || "") <= asAt).forEach(p => (p.lines || []).forEach(l => {
    const soldUpTo = (db.sales || []).filter(s => (s.date || "") <= asAt)
      .reduce((t, s) => t + (s.lines || []).filter(x => x.batch === l.batch).reduce((u, x) => u + (+x.qty || 0), 0), 0);
    stock += ((+l.qty || 0) - soldUpTo) * (+l.price || 0);
    const soldInPeriod = (db.sales || []).filter(s => inRange(s.date))
      .reduce((t, s) => t + (s.lines || []).filter(x => x.batch === l.batch).reduce((u, x) => u + (+x.qty || 0), 0), 0);
    cogs += soldInPeriod * (+l.price || 0);
  }));
  const net = r => (r.lines || []).reduce((t, l) => t + (+l.qty || 0) * (+l.price || 0), 0) - (+r.disc || 0);
  let receivables = 0, salesIncome = 0, payables = 0, cashIn = 0, cashOut = 0;
  const paidUpTo = r => {
    const initial = (r.date || "") <= asAt ? (+r.paid || 0) : 0;
    return initial + (r.payments || []).filter(x => (x.date || "") <= asAt).reduce((t, x) => t + (+x.amount || 0), 0);
  };
  (db.sales || []).filter(s => (s.date || "") <= asAt).forEach(s => {
    const n = net(s), got = paidUpTo(s);
    receivables += Math.max(n - got, 0);
    if (inRange(s.date)) salesIncome += n;
    cashIn += got;
  });
  (db.purch || []).filter(p => (p.date || "") <= asAt).forEach(p => {
    const got = paidUpTo(p);
    payables += Math.max(net(p) - got, 0);
    cashOut += got;
  });
  return { stock: r2(stock), receivables: r2(receivables), payables: r2(payables),
           salesIncome: r2(salesIncome), cogs: r2(cogs), cashNet: r2(cashIn - cashOut) };
}

function bsBuild(inp) {
  const asAt = inp.asAt, start = inp.start || "";
  const cr = (acct) => db.led.filter(l => l.acct == acct.id && (l.date || "") <= asAt).reduce((s, l) => s + (+l.dr || 0) - (+l.cr || 0), 0);
  const bankLines = db.bank.slice().sort((a, b) => (a.bank + a.title).localeCompare(b.bank + b.title))
    .map(a => [`   ${a.bank} - ${a.title} (${a.no})`, cr(a), "line"]);
  const bankTotal = bankLines.reduce((s, l) => s + l[1], 0);
  const expenses = postedExp().filter(e => (e.date || "") <= asAt && (!start || (e.date || "") >= start)).reduce((s, e) => s + (+e.total || 0), 0);
  const v = inp.v;
  const c = bsCalc(asAt, start);
  const totalAssets = bankTotal + c.cashNet + v.cash + c.receivables + c.stock + v.fixed;
  const totalLiab = c.payables + v.payables_other + v.loans;
  const totalEquity = v.capital + v.income + c.salesIncome - c.cogs - expenses;
  const totalLE = totalLiab + totalEquity;
  const rows = [
    ["ASSETS", null, "head"],
    ["Bank balances (from Bank Account ledger)", bankTotal, "sub"], ...bankLines,
    ["Cash from sales less purchases paid (Enter Sales / Enter Purchases)", c.cashNet, "line"],
    ["Cash in hand", v.cash, "line"], ["Receivables from sales (not yet received)", c.receivables, "line"],
    ["Stock / inventory (calculated from purchases and sales)", c.stock, "line"], ["Fixed assets (from Assets Registration)", v.fixed, "line"],
    ["TOTAL ASSETS", totalAssets, "total"], ["", null, "blank"],
    ["LIABILITIES", null, "head"], ["Payables for purchases (not yet paid)", c.payables, "line"], ["Other payables", v.payables_other, "line"], ["Loans and borrowings", v.loans, "line"],
    ["TOTAL LIABILITIES", totalLiab, "total"], ["", null, "blank"],
    ["OWNER'S EQUITY", null, "head"], ["Owner's capital", v.capital, "line"],
    ["Other income for the period", v.income, "line"],
    ["Sales income for the period (net)", c.salesIncome, "line"], ["Less: cost of goods sold (purchase price of items sold)", -c.cogs, "line"],
    ["Less: expenses for the period", -expenses, "line"],
    ["TOTAL OWNER'S EQUITY", totalEquity, "total"], ["", null, "blank"],
    ["TOTAL LIABILITIES AND OWNER'S EQUITY", totalLE, "total"],
    ["Difference (should be 0.00)", totalAssets - totalLE, "check"],
  ];
  const diff = Math.round((totalAssets - totalLE) * 100) / 100;
  const period = start ? `From ${start} to ${asAt}` : `As at ${asAt}`;
  const notes = [
    "Items with no entry are shown as 0.00.",
    "Expenses reduce owner's equity. A cash expense is not in the bank ledger, so enter the real cash in hand to balance.",
    "Bank balances are the Bank Account ledger totals (deposits minus withdrawals) up to the as-at date.",
  ];
  return { period, rows, notes, diff, balanced: Math.abs(diff) < 0.005, assets: totalAssets, liab: totalLiab, equity: totalEquity };
}

const BS_MANUAL = [
  ["cash", "Cash in hand"],
  ["payables_other", "Other payables (e.g. salaries due but not paid)"], ["loans", "Loans and borrowings"],
  ["capital", "Owner's capital (as at the start date)"], ["income", "Other income for the period"],
];

function bsParse(raw) {
  const errs = [];
  const num = (k, label) => {
    const t = String(raw[k] || "").trim().replace(/,/g, "");
    if (!t) return 0;
    const x = Number(t);
    if (!isFinite(x)) { errs.push(`${label} must be a number.`); return 0 }
    if (x < 0) { errs.push(`${label} cannot be negative.`); return 0 }
    return Math.round(x * 100) / 100;
  };
  const asAt = raw.asAt || T, start = raw.start || "";
  if (start && start > asAt) errs.push("The start date is after the as-at date.");
  const v = {};
  BS_MANUAL.forEach(([k, label]) => v[k] = num(k, label));
  v.fixed = assetsTotal(asAt);            // from Assets Registration: bought on or before the as-at date
  return { inp: { asAt, start, v }, errs };
}

/* ---- Balance sheet window ---- */
function balanceUI(root) {
  const fields = BS_MANUAL.map(([k, l]) => `<div><label>${l}</label><input class="inp" name="${k}" inputmode="decimal" placeholder="0.00"></div>`).join("");
  root.innerHTML = `<h1>Balance Sheet</h1>
   <div class="grp"><div class="g" data-grid="4" style="grid-template-columns:repeat(4,minmax(0,1fr))">
     <div><label>As-at date *</label><input class="inp" type="date" name="asAt" value="${T}"></div>
     <div><label>Start date (optional, expenses from this date)</label><input class="inp" type="date" name="start"></div>
     <div title="Total of the assets bought on or before the as-at date"><label>Fixed assets (from Assets Registration)</label><input class="inp" name="fixedAuto" readonly></div>
     ${fields}
   </div><div class="btns">
     <button type="button" class="btn p" data-b="show">Show balance sheet</button>
     <button type="button" class="btn" data-b="xlsx">Download Excel</button>
     <button type="button" class="btn p" data-b="pdf">Download PDF</button>
     <button type="button" class="btn" data-b="print">Print</button>
   </div></div>
   <div class="m"></div>
   <div class="bs-out" style="margin-top:10px"></div>`;
  const refreshFixed = () => { $("[name=fixedAuto]", root).value = fm(assetsTotal($("[name=asAt]", root).value || T)) };
  refreshFixed();
  $("[name=asAt]", root).addEventListener("change", refreshFixed);
  root._tick = refreshFixed;
  const get = () => {
    const raw = { asAt: $("[name=asAt]", root).value, start: $("[name=start]", root).value };
    BS_MANUAL.forEach(([k]) => raw[k] = $(`[name=${k}]`, root).value);
    return raw;
  };
  const show = () => {
    const out = $(".bs-out", root);
    try {
      const { inp, errs } = bsParse(get());
      $(".m", root).innerHTML = errs.map(e => `<div class="msg bad">${e}</div>`).join("");
      if (errs.length) { out.innerHTML = ""; return null }
      const s = bsBuild(inp);
      const ok = s.balanced;
      const statusText = ok ? "The balance sheet balances." : (s.diff < 0
        ? `Liabilities and equity are Rs ${fm(-s.diff)} more than assets. Check the owner's capital and the bank balances, or enter the missing assets (cash in hand, stock, fixed assets).`
        : `Assets are Rs ${fm(s.diff)} more than liabilities and equity. Check the owner's capital, loans or payables, or remove the extra assets.`);
      const rowHtml = s.rows.map(([l, a, st]) => {
        if (st === "blank") return `<tr><td colspan="2" style="height:8px"></td></tr>`;
        const bold = (st === "head" || st === "total") ? "font-weight:700;" : (st === "sub" ? "font-weight:600;" : "");
        const pad = st === "line" ? "padding-left:18px;" : "";
        const top = st === "total" ? "border-top:1px solid #111;" : "";
        const ital = st === "check" ? "color:#666;font-style:italic;" : "";
        return `<tr><td style="${bold}${pad}${top}${ital}padding:4px 8px;border-bottom:1px solid #ddd;">${l}</td><td style="${bold}${top}${ital}text-align:right;width:180px;padding:4px 8px;border-bottom:1px solid #ddd;">${a == null ? "" : fm(a)}</td></tr>`;
      }).join("");
      out.innerHTML = `
       <div style="background:#fff;color:#111;border:1px solid #bbb;border-radius:6px;padding:14px 18px;max-width:820px">
        <div style="font-size:18px;font-weight:700;text-align:center;color:#111">Balance Sheet</div>
        <div style="text-align:center;color:#555;margin-bottom:8px">${s.period}</div>
        <div style="margin:8px 0;padding:6px 10px;border-radius:4px;background:${ok ? "#e6f4ea" : "#fdecea"};color:${ok ? "#1e6b34" : "#a4262c"}">${statusText}</div>
        <table style="width:100%;border-collapse:collapse;background:#fff;color:#111">
          <thead><tr><th style="background:#0b2565;color:#fff;text-align:left;padding:6px 8px">Particulars</th><th style="background:#0b2565;color:#fff;text-align:right;padding:6px 8px;width:180px">Rs</th></tr></thead>
          <tbody>${rowHtml}</tbody>
        </table>
        <ul style="color:#555;font-size:12px;margin-top:8px">${s.notes.map(n => `<li>${n}</li>`).join("")}</ul>
       </div>`;
      return { inp, s };
    } catch (err) {
      out.innerHTML = `<div class="msg bad">The balance sheet could not be built: ${String((err && err.message) || err)}</div>`;
      return null;
    }
  };
  root.querySelectorAll("button[data-b]").forEach(b => b.addEventListener("click", () => {
    const k = b.dataset.b;
    if (k === "show") { show(); return }
    if (k === "print") { if (show()) window.print(); return }
    const r = show();
    if (!r) return;
    saveBalance(r.s, k, `balance-sheet-${r.inp.asAt}`);
  }));
  show();
}

async function saveBalance(s, fmt, name) {
  try {
    if (fmt === "xlsx") {
      if (!window.XLSX) return toast("The Excel library could not load. Try PDF instead.");
      const data = [["Balance Sheet"], [s.period], [], ["Particulars", "Rs"], ...s.rows.filter(r => r[2] !== "blank").map(([l, a]) => [l, a == null ? "" : a]), [], ...s.notes.map(n => [n])];
      const ws = XLSX.utils.aoa_to_sheet(data), wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Balance Sheet");
      await DL.save({ filename: name + ".xlsx", data: XLSX.write(wb, { type: "array", bookType: "xlsx" }) });
    } else {
      if (!window.jspdf) return toast("The PDF library could not load. Try Excel instead.");
      const doc = new window.jspdf.jsPDF({ unit: "mm", format: "a4" });
      doc.setFontSize(16); doc.text("Balance Sheet", 14, 16);
      doc.setFontSize(10); doc.text(s.period, 14, 23);
      doc.autoTable({ startY: 28, head: [["Particulars", "Rs"]], margin: { left: 14, right: 14 },
        body: s.rows.filter(r => r[2] !== "blank").map(([l, a]) => [l, a == null ? "" : fm(a)]),
        styles: { fontSize: 9 }, columnStyles: { 1: { halign: "right" } } });
      let y = doc.lastAutoTable.finalY + 8;
      doc.setFontSize(8); s.notes.forEach(n => { doc.text("- " + n, 14, y); y += 5 });
      await DL.save({ filename: name + ".pdf", data: doc.output("arraybuffer") });
    }
  } catch (e) { toast("Could not download the file: " + (e && (e.message || e))) }
}

