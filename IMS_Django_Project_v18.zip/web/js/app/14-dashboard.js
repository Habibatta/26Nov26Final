/* ===== Dashboard: sales, expenses, stock, cash and unpaid, salary and attendance =====
   Every figure is worked out from the records on this computer, and it updates when a record changes.
   A section appears only if the user may open the page it summarises (the super user sees everything). */
function dashUI(root) {
  let range = "month", from = "", to = "";
  const RANGES = [["month", "This month"], ["30", "Last 30 days"], ["year", "This year"], ["all", "All time"], ["custom", "Custom dates"]];
  const ymd = d => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  const bounds = () => {
    if (range === "month") return [T.slice(0, 7) + "-01", T];
    if (range === "30") { const d = new Date(); d.setDate(d.getDate() - 29); return [ymd(d), T] }
    if (range === "year") return [T.slice(0, 4) + "-01-01", T];
    if (range === "custom") return [from || "0000-00-00", to || "9999-12-31"];
    return ["0000-00-00", "9999-12-31"];
  };
  const inR = (d, b) => (d || "") >= b[0] && (d || "") <= b[1];
  const money = v => "Rs " + fm(v);
  const sumOf = (L, fn) => L.reduce((s, x) => s + (fn(x) || 0), 0);
  const card = (label, value, sub, tone) => `<div class="dcard ${tone || ""}"><div class="dl">${label}</div><div class="dv">${value}</div>${sub ? `<div class="ds">${sub}</div>` : ""}</div>`;
  const sec = (title, cards) => `<div class="dash-sec"><h3>${title}</h3><div class="dash-cards">${cards}</div></div>`;
  const show = k => U().su || can(k);
  const cn = id => (db.cat.find(c => c.id == id) || {}).name || "(no category)";

  root.innerHTML = `<h1>Dashboard <span style="font-weight:400;color:var(--muted);font-size:12px">– live figures from this computer</span></h1>
    <div class="grp dash-bar"><div class="g">
      <div><label>Period</label><select class="inp" name="range">${RANGES.map(([v, t]) => `<option value="${v}">${t}</option>`).join("")}</select></div>
      <div class="dcust" hidden><label>From</label><input class="inp" type="date" name="from"></div>
      <div class="dcust" hidden><label>To</label><input class="inp" type="date" name="to"></div>
    </div><div class="dash-label" style="color:var(--muted);margin-top:6px"></div></div>
    <div class="dash-body"></div>`;
  root.querySelector("[name=range]").value = range;
  const syncCust = () => root.querySelectorAll(".dcust").forEach(x => x.hidden = range !== "custom");

  const draw = () => {
    const B = bounds(), endM = B[1].slice(0, 7);
    root.querySelector(".dash-label").textContent = range === "all" ? "Period: all records" : `Period: ${B[0]} to ${B[1]}`;
    let html = "";

    // Sales and purchases (period)
    const S = spList("sales").filter(r => inR(r.date, B)), P = spList("purch").filter(r => inR(r.date, B));
    if (show("sales")) {
      const net = sumOf(S, spNet), paid = sumOf(S, spTotalPaid), unpaid = sumOf(S, r => Math.max(spNet(r) - spTotalPaid(r), 0));
      html += sec("Sales", card("Sales (net)", money(net), `${S.length} invoice${S.length === 1 ? "" : "s"}`) +
        card("Received", money(paid), "cash received from customers", "good") +
        card("Unpaid by customers", money(unpaid), "still to be received", unpaid > 0 ? "bad" : ""));
    }
    if (show("purch")) {
      const net = sumOf(P, spNet), paid = sumOf(P, spTotalPaid), unpaid = sumOf(P, r => Math.max(spNet(r) - spTotalPaid(r), 0));
      html += sec("Purchases", card("Purchases (net)", money(net), `${P.length} invoice${P.length === 1 ? "" : "s"}`) +
        card("Paid to vendors", money(paid), "") +
        card("Unpaid to vendors", money(unpaid), "still to be paid", unpaid > 0 ? "bad" : ""));
    }

    // Expenses (period): approved ones count; the rest wait for approval
    const E = postedExp().filter(e => inR(e.date, B));
    const pend = db.exp.filter(e => (e.status || "Approved") === "Pending" && inR(e.date, B));
    if (show("exp")) {
      const tot = sumOf(E, e => e.total);
      const cats = new Map();
      E.forEach(e => expLines(e).forEach(l => cats.set(cn(l.cat), (cats.get(cn(l.cat)) || 0) + (l.total != null ? +l.total : expLineTotal(l)))));
      const top = [...cats].sort((a, b) => b[1] - a[1]).slice(0, 5), mx = top.length ? top[0][1] : 0;
      html += sec("Expenses", card("Expenses (approved)", money(tot), `${E.length} expense${E.length === 1 ? "" : "s"}`) +
        card("Waiting for approval", money(sumOf(pend, e => e.total)), `${pend.length} expense${pend.length === 1 ? "" : "s"}`, pend.length ? "bad" : ""));
      html += `<div class="dash-sec"><h3>Top expense categories</h3>${top.length ? top.map(([k, v]) => `<div class="dbar-row"><span class="dbar-l">${spEsc(k)}</span><span class="dbar"><i style="width:${mx ? Math.round(v / mx * 100) : 0}%"></i></span><span class="dbar-v">${money(v)}</span></div>`).join("") : `<div style="color:var(--muted)">No approved expenses in this period.</div>`}</div>`;
    }

    // Sales and expenses by month (last six months up to the end of the period)
    if (show("sales") || show("exp")) {
      const [y, m] = endM.split("-").map(Number), months = [];
      for (let i = 5; i >= 0; i--) { const d = new Date(y, m - 1 - i, 1); months.push(d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0")) }
      const sv = months.map(mo => show("sales") ? sumOf(spList("sales").filter(r => (r.date || "").startsWith(mo)), spNet) : 0);
      const ev = months.map(mo => show("exp") ? sumOf(postedExp().filter(e => (e.date || "").startsWith(mo)), e => e.total) : 0);
      const mx = Math.max(1, ...sv, ...ev);
      html += `<div class="dash-sec"><h3>Last six months</h3><div class="dchart">${months.map((mo, i) => `<div class="dcol"><div class="dbars">
        ${show("sales") ? `<div class="db s" style="height:${Math.round(sv[i] / mx * 100)}%" title="Sales ${money(sv[i])}"></div>` : ""}
        ${show("exp") ? `<div class="db e" style="height:${Math.round(ev[i] / mx * 100)}%" title="Expenses ${money(ev[i])}"></div>` : ""}</div><div class="dm">${monthName(mo).split(" ")[0].slice(0, 3)} ${mo.slice(2, 4)}</div></div>`).join("")}</div>
        <div class="dlegend">${show("sales") ? `<span><i class="sw s"></i>Sales</span>` : ""}${show("exp") ? `<span><i class="sw e"></i>Expenses</span>` : ""}</div></div>`;
    }

    // Stock (today, all batches)
    if (show("stock")) {
      const inStock = stockDetail().filter(r => r.balance > 0);
      const qty = sumOf(inStock, r => r.balance), value = sumOf(inStock, r => r.balance * r.purchPrice);
      const low = inStock.filter(r => r.balance <= 5).sort((a, b) => a.balance - b.balance).slice(0, 6);
      html += sec("Stock (today)", card("Batches in stock", String(inStock.length), `${fm(qty)} units in total`) +
        card("Stock value", money(value), "at purchase price") +
        card("Running low", String(low.length), "5 units or fewer", low.length ? "bad" : ""));
      if (low.length) html += `<div class="dash-sec"><h3>Low stock</h3>${low.map(r => `<div class="dbar-row"><span class="dbar-l">${spEsc(r.batch)} · ${spEsc(r.item)}</span><span class="dbar-v">${r.balance} ${spEsc(r.unit)} left</span></div>`).join("")}</div>`;
    }

    // Cash and unpaid (today, all accounts)
    if (show("led") || show("sales") || show("purch")) {
      const accs = db.bank.map(b => ({ b, v: db.led.filter(l => l.acct == b.id).reduce((s, l) => s + l.dr - l.cr, 0) }));
      const cash = sumOf(accs, x => x.v);
      const chq = sumOf(db.led.filter(l => l.mode === "cheque" && l.cr > 0), l => l.cr - used(l));
      const owedUs = sumOf(spList("sales"), r => Math.max(spNet(r) - spTotalPaid(r), 0));
      const owedBy = sumOf(spList("purch"), r => Math.max(spNet(r) - spTotalPaid(r), 0));
      html += sec("Cash and unpaid (today)", (show("led") ? card("Cash and bank balance", money(cash), `${accs.length} account${accs.length === 1 ? "" : "s"}`, cash < 0 ? "bad" : "good") +
        card("Cheque money not yet spent", money(chq), "issued cheques") : "") +
        (show("sales") ? card("Customers owe us", money(owedUs), "unpaid sales", owedUs > 0 ? "bad" : "") : "") +
        (show("purch") ? card("We owe vendors", money(owedBy), "unpaid purchases", owedBy > 0 ? "bad" : "") : ""));
    }

    // Salary and attendance (the month of the period's end date)
    if (show("sal") || show("paid") || show("att")) {
      const paid = db.paid.filter(p => p.month === endM);
      const waiting = db.appr.filter(a => a.type === "payroll" && a.status === "Pending").length;
      const emps = db.emp.filter(e => employedInMonth(e, endM));
      const lines = emps.map(e => payLine(e, db.sal.find(x => x.emp == e.id), endM, db.att.find(a => a.emp == e.id && a.month === endM)));
      const leaveDays = sumOf(lines, l => l.leaves);
      let att = "";
      if (show("att")) {
        const tM = T.slice(0, 7), tD = +T.slice(8, 10), working = !nonWork(tM, tD);
        const onDay = db.emp.filter(e => !outsideDay(e, tM, tD));
        const leave = onDay.filter(e => { const a = db.att.find(x => x.emp == e.id && x.month === tM); return a && a.leaves.includes(tD) }).length;
        att = card("Staff employed today", String(onDay.length), working ? "working day" : "weekend or holiday") +
          card("On leave today", String(working ? leave : 0), working ? "" : "not a working day") +
          card("Present today", String(working ? onDay.length - leave : 0), working ? "" : "");
      }
      html += sec(`Salary and attendance (${monthName(endM)})`,
        (show("paid") || show("sal") ? card("Salaries paid", money(sumOf(paid, p => p.net)), `${paid.length} employee${paid.length === 1 ? "" : "s"}`, "good") +
          card("Payroll waiting for approval", String(waiting), "requests", waiting ? "bad" : "") : "") +
        card("Employees this month", String(emps.length), `${workDaysIn(endM)} working days`) +
        card("Leave days this month", String(leaveDays), "working days only") + att);
      const hol = (db.hol || []).filter(h => h.date >= T).sort((a, b) => a.date < b.date ? -1 : 1).slice(0, 4);
      if (show("att")) html += `<div class="dash-sec"><h3>Next holidays</h3>${hol.length ? hol.map(h => `<div class="dbar-row"><span class="dbar-l">${h.date}</span><span class="dbar-v">${spEsc(h.name)}</span></div>`).join("") : `<div style="color:var(--muted)">None set. Add them on the Holidays setup page.</div>`}</div>`;
    }

    root.querySelector(".dash-body").innerHTML = html || `<div style="color:var(--muted)">You do not have access to the pages this dashboard summarises.</div>`;
  };

  root.onchange = e => {
    const n = e.target.name;
    if (n === "range") { range = e.target.value; syncCust() }
    else if (n === "from") from = e.target.value;
    else if (n === "to") to = e.target.value;
    else return;
    draw();
  };
  root._tick = draw;
  syncCust();
  draw();
}
