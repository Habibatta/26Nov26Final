/* ===== Purchase, Sales and Stock =====
   Purchase: one invoice, many items; each item gets a batch number (BT-000001...).
     A batch that has been sold is locked: its item, unit, qty and price cannot be changed and the line cannot be removed.
   Sales: one invoice, many items; the batch is a searchable picker (only batches with stock left).
     On an existing sale the batch of each line is fixed. Sales never show the purchase price.
     Saving a sale opens its invoice as a PDF in a separate window.
   Entries are hidden until you search (by batch no, item, invoice or party) or press "Show all entries".
   Stock: batches with purchase price and amounts, and sales from stock with amounts. Every page has a separate data window. */

const SP_UNITS = [["pcs", "Pcs"], ["kg", "Kg"], ["ltr", "Litre"], ["box", "Box"], ["days", "Days"], ["other", "Others"]];

const spR2 = n => Math.round((Number(n) || 0) * 100) / 100;
const spNum = v => Number(v) || 0;
const spList = k => db[k] || [];
const spEsc = s => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const spVendName = id => { const v = spList("vend").find(x => x.id == id); return v ? v.name : "" };
const spBy = u => u ? nameOf(u) : "-";
const spUnitOptions = sel => SP_UNITS.map(([v, t]) => `<option value="${v}" ${v === (sel || "pcs") ? "selected" : ""}>${t}</option>`).join("");
const spVendorOptions = sel => [["", "---------"]].concat(spList("vend").map(v => [v.id, v.name]))
  .map(([v, t]) => `<option value="${v}" ${String(v) === String(sel || "") ? "selected" : ""}>${spEsc(t)}</option>`).join("");

function spNextNo(k, prefix) {
  const nums = spList(k).map(r => +(String(r.no || "").split("-")[1]) || 0);
  return prefix + "-" + String(Math.max(0, ...nums) + 1).padStart(6, "0");
}
function spMaxBatch() {
  let m = 0;
  spList("purch").forEach(p => (p.lines || []).forEach(l => { const n = +(String(l.batch || "").split("-")[1]) || 0; if (n > m) m = n }));
  return m;
}
function spBought(batch) {
  let t = 0;
  spList("purch").forEach(p => (p.lines || []).forEach(l => { if (l.batch === batch) t += spNum(l.qty) }));
  return t;
}
function spSold(batch, exceptId) {
  let t = 0;
  spList("sales").forEach(s => {
    if (s.id == exceptId) return;
    (s.lines || []).forEach(l => { if (l.batch === batch) t += spNum(l.qty) });
  });
  return spR2(t);
}
function spLeft(batch, exceptId) { return spR2(spBought(batch) - spSold(batch, exceptId)) }
function spPurchLine(batch) {
  for (const p of spList("purch")) {
    const l = (p.lines || []).find(x => x.batch === batch);
    if (l) return { p, l };
  }
  return null;
}
/* Batches with stock left (plus the batch already on this line). Labels never show the purchase price. */
function spBatchPick(exceptId, text, current) {
  const t = (text || "").trim().toLowerCase(), out = [];
  spList("purch").forEach(p => (p.lines || []).forEach(l => {
    const left = spLeft(l.batch, exceptId), isCur = l.batch === current;
    if (!(left > 0) && !isCur) return;                       // only batches with stock available (plus this line's own batch)
    const hay = (l.batch + " " + l.item + " " + (p.no || "") + " " + spVendName(p.vend)).toLowerCase();
    if (t && !hay.includes(t) && !isCur) return;
    out.push(`<div class="bl-o" data-v="${spEsc(l.batch)}">${spEsc(`${l.batch} · ${l.item} · ${left} ${l.unit || ""} available`)}</div>`);
  }));
  return out.slice(0, 60).join("") || `<div class="bl-o none">No batch with stock available matches</div>`;
}
/* Cash payments are stored on the invoice record (rec.payments). */
function spPayments(rec) { return (rec && rec.payments) || [] }
function spTotalPaid(rec) {
  return spR2(spNum(rec.paid) + spPayments(rec).reduce((t, p) => t + spNum(p.amount), 0));
}
function spPaidAsOf(rec, asAt) {
  const initial = (rec.date || "") <= asAt ? spNum(rec.paid) : 0;
  return spR2(initial + spPayments(rec).filter(p => (p.date || "") <= asAt).reduce((t, p) => t + spNum(p.amount), 0));
}
function spNet(rec) {
  const sub = (rec.lines || []).reduce((s, l) => s + spR2(spNum(l.qty) * spNum(l.price)), 0);
  return spR2(sub - spNum(rec.disc));
}
/* Sum an invoice-level figure once per invoice (a multi-item invoice has one row per batch). */
function spOncePerInvoice(rows, key) {
  const seen = new Map();
  rows.forEach(r => { if (!seen.has(r.invId)) seen.set(r.invId, r[key]) });
  return spR2([...seen.values()].reduce((t, v) => t + (v || 0), 0));
}
function stockDetail() {
  return spList("purch").flatMap(p => (p.lines || []).map(l => {
    const bought = spNum(l.qty), sold = spSold(l.batch);
    return { batch: l.batch, item: l.item, unit: l.unit || "", no: p.no || "", vendor: spVendName(p.vend), date: p.date,
      purchPrice: spNum(l.price), bought, sold, balance: spR2(bought - sold), by: p.by, upBy: p.upBy,
      invId: p.id, invNet: spNet(p), invPaid: spTotalPaid(p), invUnpaid: spR2(Math.max(spNet(p) - spTotalPaid(p), 0)) };
  })).sort((a, b) => a.batch < b.batch ? -1 : a.batch > b.batch ? 1 : 0);
}
function salesDetail() {
  return spList("sales").slice().reverse().flatMap(r => (r.lines || []).map(l => ({
    id: r.id, batch: l.batch, item: l.item, unit: l.unit || "", no: r.no || "", party: spVendName(r.vend),
    date: r.date, qty: spNum(l.qty), price: spNum(l.price), amount: spR2(spNum(l.qty) * spNum(l.price)), by: r.by, upBy: r.upBy,
    invId: r.id, invNet: spNet(r), invPaid: spTotalPaid(r), invUnpaid: spR2(Math.max(spNet(r) - spTotalPaid(r), 0)) })));
}
function spFlat(kind) {
  if (kind === "stock") return stockDetail();
  if (kind === "sales") return salesDetail();
  return spList(kind).slice().reverse().flatMap(r => (r.lines || []).map((l, i) => ({
    id: r.id, line: i, date: r.date, no: r.no || "", party: spVendName(r.vend), batch: l.batch, item: l.item,
    unit: l.unit || "", qty: spNum(l.qty), price: spNum(l.price), amount: spR2(spNum(l.qty) * spNum(l.price)),
    by: r.by, upBy: r.upBy })));
}

/* ----- one item card (colour changes by item number) ----- */
function spItemHtml(kind, l, editing, n) {
  const cls = `sp-item sp-c${(n - 1) % 6}`;
  const qty = l.qty == null || l.qty === "" ? "" : l.qty;
  const price = l.price == null || l.price === "" ? "" : l.price;
  const info = l.batch ? spPurchLine(l.batch) : null;
  const soldQty = kind === "purch" && editing && l.batch ? spSold(l.batch) : 0;
  const lockAll = soldQty > 0;                       // purchase line whose batch has been sold
  const lockBatch = kind === "sales" && editing && !!l.batch; // existing sale line: batch is fixed
  const badge = lockAll ? `<span class="sp-lock">Sold: locked</span>` : lockBatch ? `<span class="sp-lock">Batch fixed</span>` : "";
  const total = spR2(spNum(l.qty) * spNum(l.price));
  const head = `<div class="sp-ihead"><b class="sp-no">Item ${n}</b><span class="sp-batch">${spEsc(l.batch || "new")}</span>${badge}
    <span class="sp-lt">Total <b class="lt">${fm(total)}</b></span>
    <button type="button" class="btn sp-rm" data-rm ${lockAll ? 'disabled title="Sold items cannot be removed"' : ""}>Remove</button></div>`;
  if (kind === "purch") {
    const ro = lockAll ? "readonly" : "";
    return `<div class="${cls}${lockAll ? " sp-locked" : ""}" data-batch="${spEsc(l.batch || "")}">${head}
      <div class="f2"><label>Item name *</label><input class="inp" name="item" value="${spEsc(l.item || "")}" ${ro} placeholder="e.g. Cement"></div>
      <div><label>Unit</label><select class="inp" name="unit" data-plain="1" ${lockAll ? "disabled" : ""}>${spUnitOptions(l.unit)}</select></div>
      <div><label>Qty *</label><input class="inp" type="number" name="qty" min="0" step="0.01" value="${qty}" ${ro}></div>
      <div><label>Unit price *</label><input class="inp" type="number" name="price" min="0" step="0.01" value="${price}" ${ro}></div></div>`;
  }
  const item = info ? info.l.item : (l.item || ""), unit = info ? (info.l.unit || "") : (l.unit || "");
  return `<div class="${cls}${lockBatch ? " sp-locked" : ""}" data-batch="${spEsc(l.batch || "")}">${head}
    <div class="f2 bq-wrap"><label>Batch No (type to search) *</label>
      <input class="inp" name="bq" value="${spEsc(l.batch || "")}" ${lockBatch ? "readonly" : ""} placeholder="Type batch no or item" autocomplete="off">
      <input type="hidden" name="batch" value="${spEsc(l.batch || "")}">
      <div class="bl" hidden></div></div>
    <div class="f2"><label>Item</label><div class="ro itm">${spEsc(item)}</div></div>
    <div><label>Unit</label><div class="ro unt">${spEsc(unit)}</div></div>
    <div><label>Qty (whole) *</label><input class="inp" type="number" name="qty" min="1" step="1" value="${qty}"></div>
    <div><label>Sale price *</label><input class="inp" type="number" name="price" min="0" step="0.01" value="${price}" placeholder="your sale price"></div></div>`;
}

/* ----- sales invoice PDF ----- */
function spSalesPdf(r) {
  const J = window.jspdf;
  if (!J || !J.jsPDF) return null;
  const doc = new J.jsPDF({ unit: "mm", format: "a4" });
  doc.setFontSize(16); doc.text("SALES INVOICE", 14, 16);
  doc.setFontSize(10);
  doc.text(`Sales No: ${r.no || ""}`, 14, 24);
  doc.text(`Date: ${r.date || ""}`, 14, 30);
  doc.text(`Customer: ${spVendName(r.vend)}`, 14, 36);
  const body = (r.lines || []).map(l => [l.batch, l.item, l.unit || "", String(spNum(l.qty)), fm(l.price),
    fm(spR2(spNum(l.qty) * spNum(l.price)))]);
  doc.autoTable({ startY: 42, head: [["Batch No", "Item", "Unit", "Qty", "Sale Price", "Amount"]], body,
    margin: { left: 14, right: 14 }, styles: { fontSize: 9 },
    columnStyles: { 3: { halign: "right" }, 4: { halign: "right" }, 5: { halign: "right" } } });
  let y = doc.lastAutoTable.finalY + 8;
  const sub = (r.lines || []).reduce((s, l) => s + spR2(spNum(l.qty) * spNum(l.price)), 0);
  doc.text(`Subtotal: Rs ${fm(sub)}`, 196, y, { align: "right" }); y += 6;
  doc.text(`Discount: Rs ${fm(r.disc || 0)}`, 196, y, { align: "right" }); y += 6;
  doc.setFont(undefined, "bold");
  doc.text(`Net total: Rs ${fm(spNet(r))}`, 196, y, { align: "right" }); y += 6;
  doc.setFont(undefined, "normal");
  doc.text(`Received so far: Rs ${fm(r.paid || 0)}`, 196, y, { align: "right" }); y += 6;
  doc.setFont(undefined, "bold");
  doc.text(`Balance due: Rs ${fm(Math.max(spNet(r) - spNum(r.paid), 0))}`, 196, y, { align: "right" }); y += 10;
  doc.setFont(undefined, "normal"); doc.setFontSize(8);
  doc.text(`Entered by: ${spBy(r.by)}`, 14, y);
  return doc;
}
function spOpenPdf(doc, name) {
  const w = window.open(doc.output("bloburl"), "_blank");
  if (!w) doc.save(name); // a blocked pop-up falls back to a download
}

/* ----- Purchase and Sales window ----- */
function spUI(root, kind) {
  const isSale = kind === "sales", title = isSale ? "Sales" : "Purchase";
  const pageTitle = isSale ? "Enter Sales" : "Enter Purchases";
  const f = n => root.querySelector(`[name=${n}]`);
  const box = () => root.querySelector(".sp-items");
  const cards = () => [...box().querySelectorAll(".sp-item")];
  let selId = null, armed = false, q = "", showAll = false;

  const dl = "sp-vendlist-" + kind + "-" + Math.random().toString(36).slice(2, 8);
  root.classList.add("sp-page", "sp-page-" + kind);
  root.innerHTML = `<h1>${pageTitle}</h1><div class="m"></div>
    <div class="grp sp-hdr"><div class="g">
      <div><label>Date</label><input class="inp" type="date" name="date"></div>
      <div><label>${isSale ? "Sales No (auto)" : "Invoice No (type it)"}</label><input class="inp" name="no" ${isSale ? "readonly" : ""}></div>
      <div><label>${isSale ? "Customer (from Vendor Registration)" : "Vendor (from Vendor Registration)"} *</label>
        <select class="inp" name="vend" data-plain="1">${spVendorOptions("")}</select></div>
      <div><label>Discount (Rs, optional)</label><input class="inp" type="number" name="disc" min="0" step="0.01"></div>
      <div><label>${isSale ? "Received now (Rs)" : "Paid now (Rs)"}</label><input class="inp" type="number" name="paid" min="0" step="0.01" placeholder="enter part amount"></div>
      <div class="sp-fp"><label class="sp-chk"><input type="checkbox" name="fullpaid" checked> ${isSale ? "Fully received" : "Fully paid"} (untick for part payment)</label></div>
      <div><label>Comments</label><input class="inp" name="comments"></div>
    </div></div>
    <div class="sp-itemsbar"><span class="sp-count">Items: <b name="cnt">0</b></span></div>
    <div class="sp-items"></div>
    <div class="sp-totals">
      <button type="button" class="btn sp-add" data-b="add">Add item</button>
      <span>Subtotal Rs <b name="sub">0.00</b></span><span>Discount Rs <b name="dsc">0.00</b></span>
      <span class="sp-net">Net total Rs <b name="net">0.00</b></span>
    </div>
    <div class="btns">      <button type="button" class="btn" data-b="new">New</button>
      <button type="button" class="btn p" data-b="save">Save</button>
      <button type="button" class="btn d" data-b="del">Delete</button>
      ${isSale ? '<button type="button" class="btn" data-b="pdf">Invoice PDF</button>' : ""}
      <button type="button" class="btn" data-b="pop">Open data in separate window</button>
      </div>
    <div class="sp-find">
      <input class="inp" type="search" name="find" placeholder="${isSale ? "Find sale by sales no, e.g. SL-000001" : "Find purchase by batch no, e.g. BT-000001"}">
      <button type="button" class="btn" data-b="all">Show all entries</button></div>
    <div class="sp-sum" hidden></div>
    <div class="tw sp-listwrap" hidden><table class="dt sp-list"><thead><tr>
      <th>Date</th><th>${isSale ? "Sales No" : "Invoice No"}</th><th>${isSale ? "Customer" : "Vendor"}</th>
      <th>Batch No</th><th>Items</th><th class="num">Qty</th><th class="num">Net Amount</th>
      <th>Entered by</th><th>Updated by</th></tr></thead><tbody></tbody><tfoot></tfoot></table></div>`;

  const msg = (t, k) => { root.querySelector(".m").innerHTML = t ? `<div class="msg ${k}">${spEsc(t)}</div>` : "" };

  function renumber() {
    cards().forEach((c, i) => {
      c.querySelector(".sp-no").textContent = String(i + 1);
      c.className = c.className.replace(/\bsp-c\d\b/g, "").replace(/\s+/g, " ").trim() + " sp-c" + (i % 6);
    });
  }
  function syncPaid(sub, disc) {
    const full = f("fullpaid"), paid = f("paid");
    if (full.checked) { paid.value = spR2(sub - disc); paid.disabled = true; }
    else { paid.disabled = false; }
  }
  function recalc() {
    const n = cards().length;
    const cnt = root.querySelector("[name=cnt]");
    if (cnt) cnt.textContent = n;
    let sub = 0;
    cards().forEach(c => {
      const t = spR2(spNum(c.querySelector("[name=qty]")?.value) * spNum(c.querySelector("[name=price]")?.value));
      sub += t;
      c.querySelector(".lt").textContent = fm(t);
    });
    const disc = spNum(f("disc").value);
    root.querySelector("[name=sub]").textContent = fm(sub);
    root.querySelector("[name=dsc]").textContent = fm(disc);
    root.querySelector("[name=net]").textContent = fm(sub - disc);
    syncPaid(sub, disc);
  }
  function drawItems(arr) {
    const list = arr && arr.length ? arr : [{}];
    box().innerHTML = (kind === "sales" ? SALE_HEAD : PURCH_HEAD) + list.map((l, i) => spRow(kind, l, !!selId, i + 1)).join("");
    renumber(); recalc();
  }
  function readItems() {
    return cards().map(c => {
      const g = n => { const e = c.querySelector(`[name=${n}]`); return e ? e.value : "" };
      if (kind === "purch") return { batch: c.dataset.batch || "", item: g("item").trim(), unit: g("unit") || "pcs", qty: g("qty"), price: g("price") };
      const batch = g("batch");
      const info = batch ? spPurchLine(batch) : null;
      return { batch, item: info ? info.l.item : "", unit: info ? (info.l.unit || "") : "", qty: g("qty"), price: g("price") };
    }).filter(l => l.batch || l.item || l.qty !== "" || l.price !== "");
  }
  function hideLists() { root.querySelectorAll(".bl").forEach(b => { b.hidden = true }) }
  function showPick(card) {
    const L = card.querySelector(".bl"), inp = card.querySelector("[name=bq]");
    L.innerHTML = spBatchPick(selId, inp.value, card.querySelector("[name=batch]").value);
    L.hidden = false;
    const r = inp.getBoundingClientRect(), h = Math.min(L.scrollHeight || 220, 220), below = innerHeight - r.bottom - 8;
    L.style.position = "fixed"; L.style.zIndex = "5000";
    L.style.width = Math.min(Math.max(r.width, 260), innerWidth - 8) + "px";
    L.style.left = Math.max(4, Math.min(r.left, innerWidth - 8 - Math.max(r.width, 260))) + "px";
    L.style.top = (below >= h || below >= r.top ? r.bottom + 2 : Math.max(4, r.top - h - 2)) + "px";
  }
  function chooseBatch(card, v) {
    card.querySelector("[name=batch]").value = v;
    card.querySelector("[name=bq]").value = v;
    fillBatch(card);
    hideLists();
  }
  function fillBatch(card) {
    const info = spPurchLine(card.querySelector("[name=batch]").value);
    card.dataset.batch = info ? info.l.batch : "";
    const bt = card.querySelector(".sp-batch"); if (bt) bt.textContent = info ? info.l.batch : "new";
    card.querySelector(".itm").textContent = info ? info.l.item : "";
    card.querySelector(".unt").textContent = info ? (info.l.unit || "") : "";
    recalc();
  }
  function check(L, exceptId) {
    if (!f("vend").value) return `Choose the ${isSale ? "customer" : "vendor"} from Vendor Registration.`;
    if (!L.length) return "Add at least one item.";
    const need = {};
    for (const l of L) {
      const qty = spNum(l.qty);
      if (isSale) {
        if (l.qty === "" || !Number.isInteger(qty) || qty <= 0) return "Quantity must be a whole number above zero on every item.";
        if (l.price === "" || spNum(l.price) < 0) return "Enter the sale price on every item.";
        if (!l.batch) return "Choose the batch on every item.";
        if (!spPurchLine(l.batch)) return `Batch ${l.batch} is not in purchases.`;
        need[l.batch] = (need[l.batch] || 0) + qty;
        if (need[l.batch] > spLeft(l.batch, exceptId)) return `Only ${spLeft(l.batch, exceptId)} left in batch ${l.batch}.`;
      } else {
        if (!(qty > 0)) return "Quantity must be more than zero on every item.";
        if (l.price === "" || spNum(l.price) < 0) return "Enter a valid unit price on every item.";
        if (!l.item) return "Item name is required on every item.";
      }
    }
    const disc = spNum(f("disc").value);
    const sub = L.reduce((s, l) => s + spR2(spNum(l.qty) * spNum(l.price)), 0);
    const paid = spNum(f("paid").value);
    if (paid < 0) return "Paid amount cannot be negative.";
    if (!f("fullpaid").checked && paid > sub - disc + 0.001) return `Paid amount cannot be more than the net total (Rs ${fm(sub - disc)}).`;
    if (disc < 0) return "Discount cannot be negative.";
    if (disc > sub) return `Discount cannot be more than the subtotal (Rs ${fm(sub)}).`;
    if (!isSale) {
      const inv = f("no").value.trim();
      if (inv && spList("purch").some(p => p.id != exceptId && p.no === inv && String(p.vend) === String(f("vend").value)))
        return "This invoice number is already entered for this vendor.";
      if (exceptId) {
        const old = spList("purch").find(x => x.id == exceptId);
        for (const ol of old.lines || []) {
          const sold = spSold(ol.batch);
          if (sold === 0) continue;
          const nl = L.find(x => x.batch === ol.batch);
          if (!nl) return `Batch ${ol.batch} has been sold, so this item cannot be removed.`;
          if (nl.item !== ol.item || (nl.unit || "pcs") !== (ol.unit || "pcs") || spNum(nl.qty) !== spNum(ol.qty) || spNum(nl.price) !== spNum(ol.price))
            return `Batch ${ol.batch} has been sold, so its item, unit, qty and price are locked.`;
        }
      }
    }
    return "";
  }
  function openInvoice(r) {
    const doc = spSalesPdf(r);
    if (!doc) return msg("The PDF library could not load.", "bad");
    spOpenPdf(doc, `${r.no || "sales"}.pdf`);
  }
  function table() {
    const text = q.trim().toLowerCase();
    const wrap = root.querySelector(".sp-listwrap");
    const visible = !!text || showAll;
    wrap.hidden = !visible;
    root.querySelector("[data-b=all]").textContent = showAll ? "Hide entries" : "Show all entries";
    if (!visible) return;
    const matches = (r) => {
      if (!text) return true;
      if (isSale) return String(r.no || "").toLowerCase().includes(text);   // Sales: sales no only
      return (r.lines || []).some(l => String(l.batch || "").toLowerCase().includes(text)); // Purchase: batch no only
    };
    const all = spList(kind).slice().reverse().filter(matches);
    const rows = all.slice(0, 60);
    const sum = root.querySelector(".sp-sum");
    if (sum) {
      sum.hidden = !visible || !rows.length;
      let tn = 0, tp = 0, tu = 0;
      const body = rows.map(r => {
        const net = spNet(r), paid = spTotalPaid(r), unpaid = spR2(Math.max(net - paid, 0));
        tn += net; tp += paid; tu += unpaid;
        return `<tr><td>${spEsc(r.no || "-")}</td><td>${r.date}</td><td>${spEsc(spVendName(r.vend))}</td><td class="num">${fm(net)}</td><td class="num">${fm(paid)}</td><td class="num" style="${unpaid > 0 ? "color:var(--bad);font-weight:700" : ""}">${fm(unpaid)}</td></tr>`;
      }).join("");
      sum.innerHTML = rows.length ? `<table class="dt sp-sumtab"><thead><tr><th>${isSale ? "Sales No" : "Invoice No"}</th><th>Date</th><th>${isSale ? "Customer" : "Vendor"}</th><th class="num">Net total</th><th class="num">Paid</th><th class="num">Unpaid</th></tr></thead><tbody>${body}</tbody><tfoot><tr class="st-tot"><td colspan="3">Total (${rows.length} invoice${rows.length === 1 ? "" : "s"})</td><td class="num">${fm(tn)}</td><td class="num">${fm(tp)}</td><td class="num">${fm(tu)}</td></tr></tfoot></table>` : "";
    }
    root.querySelector(".sp-list tbody").innerHTML = rows.length ? rows.map(r => {
      const lines = r.lines || [];
      const qty = lines.reduce((s, l) => s + spNum(l.qty), 0);
      return `<tr class="${r.id == selId ? "sel" : ""}" data-id="${r.id}">
        <td>${r.date}</td><td>${spEsc(r.no || "")}</td><td>${spEsc(spVendName(r.vend))}</td>
        <td>${spEsc(lines.map(l => l.batch).join(", "))}</td><td>${spEsc(lines.map(l => l.item).join(", "))}</td>
        <td class="num">${qty}</td><td class="num">${fm(spNet(r))}</td>
        <td>${spEsc(spBy(r.by))}</td><td>${spEsc(r.upBy ? spBy(r.upBy) : "-")}</td></tr>`;
    }).join("") : `<tr><td colspan="9" style="color:var(--muted)">No entries found.</td></tr>`;
    const tq = all.reduce((s, r) => s + (r.lines || []).reduce((a, l) => a + spNum(l.qty), 0), 0), tn = all.reduce((s, r) => s + spNet(r), 0);
    root.querySelector(".sp-list tfoot").innerHTML = all.length ? `<tr class="st-tot"><td colspan="5">Total (${all.length} invoice${all.length === 1 ? "" : "s"})</td><td class="num">${tq}</td><td class="num">${fm(tn)}</td><td colspan="2"></td></tr>` : "";
  }
  function load(rec) {
    armed = false;
    root.querySelector('[data-b=del]').textContent = "Delete";
    selId = rec ? rec.id : null;
    f("date").value = rec ? rec.date : T;
    f("no").value = rec ? rec.no || "" : (isSale ? spNextNo("sales", "SL") : "");
    f("vend").innerHTML = spVendorOptions(rec ? rec.vend : "");

    f("disc").value = rec ? (rec.disc || "") : "";
    const recNet = rec ? spNet(rec) : 0;
    f("fullpaid").checked = rec ? Math.abs(spNum(rec.paid) - recNet) < 0.005 : true;
    f("paid").value = rec ? (rec.paid || "") : "";
    f("comments").value = rec ? (rec.comments || "") : "";
    drawItems(rec ? rec.lines : [{}]);
    hideLists();
    table();
  }
  async function save() {
    if (!canAdd() && !selId) return msg("You do not have permission to add records.", "bad");
    if (selId && !canEdit()) return msg("You do not have permission to edit records.", "bad");
    const L = readItems();
    const err = check(L, selId);
    if (err) return msg(err, "bad");
    const netNow = L.reduce((t, l) => t + spR2(spNum(l.qty) * spNum(l.price)), 0) - spNum(f("disc").value);
    if (!(await askSave(`${selId ? "Update" : "Save"} ${title} ${f("no").value || ""} (${L.length} item${L.length > 1 ? "s" : ""}, net Rs ${fm(netNow)})?`))) return;
    const sub0 = () => L.reduce((t, l) => t + spR2(spNum(l.qty) * spNum(l.price)), 0);
    let n = spMaxBatch();
    const lines = L.map(l => {
      if (isSale) return { batch: l.batch, item: l.item, unit: l.unit, qty: spNum(l.qty), price: spNum(l.price) };
      const batch = l.batch || ("BT-" + String(++n).padStart(6, "0"));
      return { batch, item: l.item, unit: l.unit || "pcs", qty: spNum(l.qty), price: spNum(l.price) };
    });
    const no = isSale ? (selId ? f("no").value : spNextNo("sales", "SL")) : f("no").value.trim();
    const rec = { date: f("date").value || T, no, vend: +f("vend").value, disc: spNum(f("disc").value), paid: f("fullpaid").checked ? spR2(sub0() - spNum(f("disc").value)) : spR2(spNum(f("paid").value)), lines, comments: f("comments").value.trim() };
    let saved;
    if (selId) {
      saved = spList(kind).find(x => x.id == selId);
      Object.assign(saved, rec);
      saved.upBy = me; saved.upAt = new Date().toISOString();
      persist(kind, saved); logH("Updated", title, no);
    } else {
      saved = { id: nid(), by: me, ...rec };
      if (!db[kind]) db[kind] = [];
      db[kind].push(saved); persist(kind, saved); logH("Added", title, no);
    }
    if (typeof OUTBOX !== "undefined") { OUTBOX.add(kind, saved); OUTBOX.flush(); }
    load(null);
    msg("Record saved." + (typeof OUTBOX !== "undefined" && OUTBOX.pending() ? " Waiting to send to the server (" + OUTBOX.pending() + " pending)." : ""), "ok");
    // The invoice is not opened automatically; use the Invoice PDF button.
  }
  function del() {
    if (!canDel()) return msg("You do not have permission to delete records.", "bad");
    if (!selId) return;
    const r = spList(kind).find(x => x.id == selId);
    if (!isSale && (r.lines || []).some(l => spSold(l.batch) > 0)) return msg("Cannot delete: items from this invoice were already sold.", "bad");
    if (!armed) {
      armed = true;
      root.querySelector('[data-b=del]').textContent = "Confirm delete";
      return msg("Click Delete again to confirm.", "bad");
    }
    armed = false;
    const L = db[kind];
    L.splice(L.indexOf(r), 1); unpersist(kind, r); logH("Deleted", title, r.no || "");
    load(null); msg("Record deleted.", "ok");
  }

  root.oninput = e => {
    const t = e.target;

    if (t.name === "bq") { if (!t.readOnly) showPick(t.closest(".sp-item")); return }
    if (t.name === "find") { q = t.value; table(); return }
    if (t.closest(".sp-items") || t.name === "disc") recalc();
  };
  root.addEventListener("focusin", e => {
    if (e.target.name === "bq" && !e.target.readOnly) showPick(e.target.closest(".sp-item"));
  });
  root.onchange = e => {
    const t = e.target;
    if (t.name === "bq") {
      const exact = spList("purch").some(p => (p.lines || []).some(l => l.batch === t.value.trim()));
      if (exact) t.closest(".sp-item").querySelector("[name=batch]").value = t.value.trim();
      fillBatch(t.closest(".sp-item"));
    }
    if (t.name === "fullpaid") recalc();
    if (t.closest(".sp-items")) recalc();
  };
  root.onclick = e => {
    const opt = e.target.closest(".bl-o[data-v]");
    if (opt) { chooseBatch(opt.closest(".sp-item"), opt.dataset.v); return }
    if (!e.target.closest(".bq-wrap")) hideLists();
    const rm = e.target.closest("[data-rm]");
    if (rm && !rm.disabled) { rm.closest(".sp-item").remove(); renumber(); recalc(); return }
    const row = e.target.closest("tr[data-id]");
    if (row) {
      const r = spList(kind).find(x => x.id == row.dataset.id);
      if (r) { load(r); msg("") }
      return;
    }
    const b = e.target.closest("[data-b]")?.dataset.b;
    if (!b) return;
    if (b === "add") {
      box().insertAdjacentHTML("beforeend", spRow(kind, {}, !!selId, cards().length + 1));
      renumber(); recalc(); return;
    }
    if (b === "all") { showAll = !showAll; table(); return }
    if (b === "pop") return openW("data:" + kind);
    if (b === "new") { load(null); msg(""); return }
    if (b === "save") return save();
    if (b === "del") return del();
    if (b === "pdf") {
      const r = selId && spList(kind).find(x => x.id == selId);
      if (!r) return msg("Choose a sale from the list first.", "bad");
      return openInvoice(r);
    }
  };
  root.addEventListener("scroll", hideLists, true);
  load(null);
}

/* ----- Stock window: purchases by batch (with purchase price and amount) and sales from stock (with amount) ----- */
const PURCH_HEAD = `<div class="sp-sale-grid sp-colhead"><span>#</span><span>Batch No</span><span>Item</span><span>Unit</span><span>Qty</span><span>Unit price</span><span class="num">Total</span><span></span></div>`;
const SALE_HEAD = `<div class="sp-sale-grid sp-colhead"><span>#</span><span>Batch No (type to search)</span><span>Item</span><span>Unit</span><span>Qty (whole)</span><span>Sale price</span><span class="num">Total</span><span></span></div>`;

function spSaleRowHtml(l, editing, n) {
  const qty = l.qty == null || l.qty === "" ? "" : l.qty;
  const price = l.price == null || l.price === "" ? "" : l.price;
  const info = l.batch ? spPurchLine(l.batch) : null;
  const item = info ? info.l.item : (l.item || ""), unit = info ? (info.l.unit || "") : (l.unit || "");
  const total = spR2(spNum(l.qty) * spNum(l.price));
  const lock = editing && !!l.batch;
  return `<div class="sp-item sp-sale-grid sp-c${(n - 1) % 6}" data-batch="${spEsc(l.batch || "")}" data-item="${spEsc(item)}" data-unit="${spEsc(unit)}">
    <span class="sp-no">${n}</span>
    <div class="bq-wrap"><input class="inp" name="bq" value="${spEsc(l.batch || "")}" ${lock ? "readonly" : ""} placeholder="batch or item" autocomplete="off"><input type="hidden" name="batch" value="${spEsc(l.batch || "")}"><div class="bl" hidden></div></div>
    <div class="ro itm">${spEsc(item)}</div>
    <div class="ro unt">${spEsc(unit)}</div>
    <input class="inp" type="number" name="qty" min="1" step="1" value="${qty}">
    <input class="inp" type="number" name="price" min="0" step="0.01" value="${price}" placeholder="sale price">
    <span class="lt num">${fm(total)}</span>
    <button type="button" class="btn sp-rm" data-rm>&times;</button>
  </div>`;
}

function spPurchRowHtml(l, editing, n) {
  const qty = l.qty == null || l.qty === "" ? "" : l.qty;
  const price = l.price == null || l.price === "" ? "" : l.price;
  const total = spR2(spNum(l.qty) * spNum(l.price));
  const lockAll = !!(editing && l.batch && spSold(l.batch) > 0);
  return `<div class="sp-item sp-sale-grid sp-c${(n - 1) % 6}${lockAll ? " sp-locked" : ""}" data-batch="${spEsc(l.batch || "")}">
    <span class="sp-no">${n}</span>
    <div class="ro">${spEsc(l.batch || "auto")}</div>
    <input class="inp" name="item" value="${spEsc(l.item || "")}" ${lockAll ? "readonly" : ""} placeholder="item name">
    <select class="inp" name="unit" data-plain="1" ${lockAll ? "disabled" : ""}>${spUnitOptions(l.unit)}</select>
    <input class="inp" type="number" name="qty" min="0" step="0.01" value="${qty}" ${lockAll ? "readonly" : ""}>
    <input class="inp" type="number" name="price" min="0" step="0.01" value="${price}" ${lockAll ? "readonly" : ""} placeholder="unit price">
    <span class="lt num">${fm(total)}</span>
    <button type="button" class="btn sp-rm" data-rm ${lockAll ? "disabled" : ""}>&times;</button>
  </div>`;
}

function spRow(kind, l, editing, n) {
  return kind === "sales" ? spSaleRowHtml(l, editing, n) : spPurchRowHtml(l, editing, n);
}

/* invoice paid / remaining cells: filled on the first batch row of each invoice only */
function invCells(r, seen) {
  const first = !seen.has(r.invId);
  seen.add(r.invId);
  if (!first) return "<td></td><td></td>";
  const bad = r.invUnpaid > 0 ? "color:var(--bad);font-weight:700" : "";
  return `<td class="num">${fm(r.invPaid)}</td><td class="num" style="${bad}">${fm(r.invUnpaid)}</td>`;
}

function stockUI(root) {
  let q = "";
  const draw = () => {
    const text = q.trim().toLowerCase();
    const hit = (...a) => !text || a.join(" ").toLowerCase().includes(text);
    const pur = stockDetail().filter(r => hit(r.batch, r.item, r.no, r.vendor));
    const sal = salesDetail().filter(r => hit(r.batch, r.item, r.no, r.party));
    const pQty = pur.reduce((s, r) => s + r.bought, 0);
    const pSold = pur.reduce((s, r) => s + r.sold, 0);
    const pBal = pur.reduce((s, r) => s + r.balance, 0);
    const pAmt = pur.reduce((s, r) => s + spR2(r.bought * r.purchPrice), 0);
    const sQty = sal.reduce((s, r) => s + r.qty, 0);
    const sAmt = sal.reduce((s, r) => s + r.amount, 0);
    const neg = v => v < 0 ? "color:var(--bad);font-weight:700" : "";
    const seenPur = new Set(), seenSal = new Set();
    root.classList.add("sp-stock");
    root.innerHTML = `<h1>Stock</h1>
      <div class="btns" style="margin:0 0 6px"><input class="inp" style="max-width:300px" type="search" placeholder="Search batch, item, invoice..." value="${spEsc(q)}">
        <button type="button" class="btn" data-b="pop">Open data in separate window</button>
        <span style="color:var(--muted);align-self:center">Balance = purchased - sold, for each batch.</span></div>
      <h2 class="st-h">Purchases by batch</h2>
      <div class="tw"><table class="dt st-table st-pur"><thead><tr>
        <th>Batch No</th><th>Item</th><th>Invoice No</th><th>Vendor</th><th>Date</th>
        <th class="num">Purchase Price</th><th class="num">Purchased</th><th class="num">Purchase Amount</th><th class="num">Invoice Paid</th><th class="num">Invoice Unpaid</th>
        <th class="num">Sold</th><th class="num">Balance</th><th>Entered by</th><th>Updated by</th></tr></thead><tbody>
        ${pur.length ? pur.map(r => `<tr style="cursor:default"><td>${spEsc(r.batch)}</td><td>${spEsc(r.item)} <span class="st-u">${spEsc(r.unit)}</span></td>
          <td>${spEsc(r.no)}</td><td>${spEsc(r.vendor)}</td><td>${r.date}</td><td class="num">${fm(r.purchPrice)}</td>
          <td class="num">${r.bought}</td><td class="num">${fm(spR2(r.bought * r.purchPrice))}</td>${invCells(r, seenPur)}<td class="num">${r.sold}</td>
          <td class="num" style="${neg(r.balance)}">${r.balance}</td><td>${spEsc(spBy(r.by))}</td><td>${spEsc(r.upBy ? spBy(r.upBy) : "-")}</td></tr>`).join("")
          : `<tr><td colspan="14" style="color:var(--muted)">No purchases yet.</td></tr>`}</tbody>
        ${pur.length ? `<tfoot><tr class="st-tot"><td colspan="6">Total</td><td class="num">${pQty}</td><td class="num">${fm(pAmt)}</td><td class="num">${fm(spOncePerInvoice(pur, "invPaid"))}</td><td class="num">${fm(spOncePerInvoice(pur, "invUnpaid"))}</td><td class="num">${pSold}</td><td class="num" style="${neg(pBal)}">${pBal}</td><td colspan="2"></td></tr></tfoot>` : ""}</table></div>
      <h2 class="st-h">Sales from stock</h2>
      <div class="tw"><table class="dt st-table st-sal"><thead><tr>
        <th>Batch No</th><th>Item</th><th>Sales No</th><th>Customer</th><th>Date</th>
        <th class="num">Qty</th><th class="num">Sale Price</th><th class="num">Sale Amount</th><th class="num">Invoice Received</th><th class="num">Invoice Unpaid</th><th>Entered by</th><th>Updated by</th></tr></thead><tbody>
        ${sal.length ? sal.map(r => `<tr style="cursor:default"><td>${spEsc(r.batch)}</td><td>${spEsc(r.item)} <span class="st-u">${spEsc(r.unit)}</span></td>
          <td>${spEsc(r.no)}</td><td>${spEsc(r.party)}</td><td>${r.date}</td><td class="num">${r.qty}</td>
          <td class="num">${fm(r.price)}</td><td class="num">${fm(r.amount)}</td>${invCells(r, seenSal)}<td>${spEsc(spBy(r.by))}</td><td>${spEsc(r.upBy ? spBy(r.upBy) : "-")}</td></tr>`).join("")
          : `<tr><td colspan="12" style="color:var(--muted)">No sales yet.</td></tr>`}</tbody>
        ${sal.length ? `<tfoot><tr class="st-tot"><td colspan="5">Total</td><td class="num">${sQty}</td><td></td><td class="num">${fm(sAmt)}</td><td class="num">${fm(spOncePerInvoice(sal, "invPaid"))}</td><td class="num">${fm(spOncePerInvoice(sal, "invUnpaid"))}</td><td colspan="2"></td></tr></tfoot>` : ""}</table></div>`;
    const srch = root.querySelector("input[type=search]");
    srch.oninput = e => {
      q = e.target.value; draw();
      const again = root.querySelector("input[type=search]");
      again.focus(); again.setSelectionRange(q.length, q.length);
    };
    root.querySelector("[data-b=pop]").onclick = () => openW("data:stock");
  };
  draw();
  root._tick = () => {
    if (!(document.activeElement && root.contains(document.activeElement) && document.activeElement.tagName === "INPUT")) draw();
  };
}

/* ----- columns for the separate data windows ----- */
CF.purch = { t: "Purchase", cols: [["Date", r => r.date], ["Invoice No", r => r.no], ["Vendor", r => r.party],
  ["Batch No", r => r.batch], ["Item", r => r.item], ["Unit", r => r.unit], ["Qty", r => r.qty, 1, "sum"],
  ["Unit Price", r => fm(r.price), 1], ["Amount", r => fm(r.amount), 1, "sum"], ["Entered by", r => spBy(r.by)], ["Updated by", r => spBy(r.upBy)]],
  list: () => spFlat("purch") };
CF.sales = { t: "Sales", cols: [["Date", r => r.date], ["Sales No", r => r.no], ["Customer", r => r.party],
  ["Batch No", r => r.batch], ["Item", r => r.item], ["Unit", r => r.unit], ["Qty", r => r.qty, 1, "sum"],
  ["Sale Price", r => fm(r.price), 1], ["Amount", r => fm(r.amount), 1, "sum"], ["Entered by", r => spBy(r.by)], ["Updated by", r => spBy(r.upBy)]],
  list: () => spFlat("sales") };
CF.stock = { t: "Stock", cols: [["Batch No", r => r.batch], ["Item", r => r.item], ["Invoice No", r => r.no],
  ["Vendor", r => r.vendor], ["Date", r => r.date], ["Purchase Price", r => fm(r.purchPrice), 1],
  ["Purchased", r => r.bought, 1, "sum"], ["Sold", r => r.sold, 1, "sum"], ["Balance", r => r.balance, 1, "sum"],
  ["Entered by", r => spBy(r.by)], ["Updated by", r => spBy(r.upBy)]],
  list: () => stockDetail() };
