/* ===== Icons: one consistent line-icon set (24 px grid, drawn in the current text colour) =====
   Used for the page icons (menus, toolbar, window titles), the buttons, the menu actions and the logo.
   Buttons get their icon from their label (see ICON_RULES), so new buttons are covered automatically. */
const ICON_BODY = {
  plus:'<path d="M12 5v14M5 12h14"/>',
  x:'<path d="M18 6 6 18M6 6l12 12"/>',
  check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  save:'<path d="M5 3h11l3 3v13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M8 3v5h7V3M7 21v-7h10v7"/>',
  file:'<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/>',
  doc:'<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>',
  trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/>',
  printer:'<path d="M7 9V3h10v6"/><rect x="4" y="9" width="16" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
  sheet:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  list:'<path d="M9 6h12M9 12h12M9 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01"/>',
  calendar:'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 10h18M16 2v4M8 2v4"/>',
  wallet:'<path d="M19 7H5a2 2 0 0 1 0-4h12v4"/><rect x="3" y="7" width="18" height="14" rx="2"/><path d="M16 14h2"/>',
  approve:'<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
  reject:'<circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/>',
  bookmark:'<path d="M6 3h12v18l-6-4-6 4z"/>',
  book:'<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 21.5V19"/>',
  logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
  login:'<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5M15 12H3"/>',
  download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/>',
  upload:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5M12 3v12"/>',
  maximize:'<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
  external:'<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14 21 3"/>',
  cpu:'<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  send:'<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
  refresh:'<path d="M21 12a9 9 0 1 1-2.6-6.4L21 8"/><path d="M21 3v5h-5"/>',
  pencil:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  panel:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
  eraser:'<path d="m7 21-4.3-4.3a1 1 0 0 1 0-1.4l9.6-9.6a1 1 0 0 1 1.4 0l5.6 5.6a1 1 0 0 1 0 1.4L13 21"/><path d="M22 21H7"/>',
  spark:'<path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z"/><path d="M19 16l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
  chat:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  users:'<circle cx="9" cy="8" r="4"/><path d="M2 21v-1a6 6 0 0 1 6-6h2a6 6 0 0 1 6 6v1M16 4a4 4 0 0 1 0 8M22 21v-1a6 6 0 0 0-4-5.6"/>',
  group:'<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20v-1a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v1M15 15h1a4 4 0 0 1 4 4v1"/>',
  dash:'<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="5" rx="1.5"/><rect x="13" y="12" width="8" height="9" rx="1.5"/><rect x="3" y="15" width="8" height="6" rx="1.5"/>',
  history:'<path d="M3 12a9 9 0 1 0 2.6-6.4L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
  reports:'<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h8M8 9h2"/>',
  balance:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  tag:'<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
  briefcase:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18"/>',
  layers:'<path d="M12 3 2 8l10 5 10-5z"/><path d="m2 13 10 5 10-5"/>',
  truck:'<path d="M2 6h12v10H2zM14 10h4l4 4v2h-8"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
  bank:'<path d="M3 10 12 4l9 6M5 10v9M9 10v9M15 10v9M19 10v9M3 21h18"/>',
  card:'<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>',
  idcard:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="11" r="2.5"/><path d="M5.5 17a4 4 0 0 1 7 0M15 9h3M15 13h3"/>',
  coin:'<circle cx="12" cy="12" r="9"/><path d="M14.5 9.5h-3.8a1.2 1.2 0 0 0 0 2.4h2.6a1.2 1.2 0 0 1 0 2.4H9.5M12 7v10"/>',
  calcheck:'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 10h18M16 2v4M8 2v4M9 16l2 2 4-4"/>',
  star:'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 10h18M16 2v4M8 2v4M12 12.5l1.1 2.3 2.5.3-1.8 1.8.4 2.5-2.2-1.2-2.2 1.2.4-2.5-1.8-1.8 2.5-.3z"/>',
  paidcheck:'<rect x="2" y="6" width="20" height="12" rx="2"/><path d="m7 12 3 3 6-6"/>',
  receipt:'<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
  walletout:'<path d="M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7l12-4v4M17 14h2"/>',
  shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m9 12 2 2 4-4"/>',
  cart:'<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.7 12.3a2 2 0 0 0 2 1.7h8.6a2 2 0 0 0 2-1.6L22 7H6"/>',
  trend:'<path d="m3 17 6-6 4 4 8-8"/><path d="M14 7h7v7"/>',
  box:'<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
  table:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 4v16"/>',
  clip:'<path d="m21.4 11-8.5 8.5a5 5 0 0 1-7-7L14 4a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L15 8"/>',
  palette:'<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16" cy="10" r="1"/>',
  windows:'<rect x="3" y="4" width="13" height="11" rx="2"/><path d="M7 19h12a2 2 0 0 0 2-2V8"/>',
  key:'<circle cx="8" cy="15" r="4"/><path d="m10.8 12.2 9.2-9.2M16 7l3 3M13.5 9.5l2.5 2.5"/>',
  minus:'<path d="M5 12h14"/>',
  undo:'<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
};
/* One colour per icon (Tailwind 600 range: readable on light and dark themes) */
const ICON_HUE = {
  plus:"#16a34a", x:"#dc2626", check:"#16a34a", save:"#2563eb", file:"#0284c7", doc:"#dc2626", trash:"#e11d48",
  printer:"#7c3aed", sheet:"#16a34a", search:"#0891b2", list:"#4f46e5", calendar:"#d97706", wallet:"#059669",
  approve:"#16a34a", reject:"#dc2626", bookmark:"#db2777", book:"#7c3aed", logout:"#ea580c", login:"#2563eb",
  download:"#0891b2", upload:"#0891b2", maximize:"#4f46e5", external:"#0284c7", cpu:"#475569", send:"#2563eb",
  refresh:"#0891b2", pencil:"#d97706", eye:"#0891b2", panel:"#4f46e5", eraser:"#db2777", spark:"#c026d3",
  chat:"#0284c7", users:"#4f46e5", group:"#4f46e5", dash:"#2563eb", history:"#7c3aed", reports:"#0284c7",
  balance:"#16a34a", tag:"#d97706", briefcase:"#b45309", layers:"#0d9488", truck:"#ea580c", bank:"#1d4ed8",
  card:"#0369a1", idcard:"#4338ca", coin:"#ca8a04", calcheck:"#0891b2", star:"#f59e0b", paidcheck:"#16a34a",
  receipt:"#0f766e", walletout:"#dc2626", shield:"#0d9488", cart:"#7c3aed", trend:"#16a34a", box:"#b45309",
  table:"#475569", clip:"#475569", palette:"#db2777", windows:"#4f46e5", key:"#ca8a04", minus:"#64748b",
  undo:"#475569",
};
const SVG_ICON = (name, extra = "", auto = false) => {
  const c = ICON_HUE[name] || "#475569";
  const tile = name === "logo" ? "" : `<rect class="t" x="1.5" y="1.5" width="21" height="21" rx="6" fill="${c}" fill-opacity=".16" stroke="none"/>`;
  return `<svg class="ic ${extra}" stroke="${c}"${auto ? ' data-auto="1"' : ""} viewBox="0 0 24 24" aria-hidden="true" focusable="false">${tile}${ICON_BODY[name] || ICON_BODY.table}</svg>`;
};
const ICO = Object.fromEntries(Object.keys(ICON_BODY).map(k => [k, SVG_ICON(k, k === "logo" ? "logo" : "")]));

/* Button label -> icon. The first rule that matches the label wins. */
const ICON_RULES = [
  [/^\+/, "plus"], [/^new group|^create group|^start chat/i, "group"], [/^new chat$/i, "chat"], [/^new$/i, "file"],
  [/^yes\b/i, "check"], [/^no\b|go back|^cancel|^close$|^×$|^✕$|^✖$/i, "x"],
  [/^save|^update/i, "save"], [/delete|^remove|forget|discard/i, "trash"],
  [/^print/i, "printer"], [/excel/i, "sheet"], [/pdf/i, "doc"],
  [/show all|hide entries/i, "list"], [/holidays setup/i, "calendar"],
  [/pay all|finalize|send for approval|^pay\b/i, "wallet"],
  [/^approve|^accept/i, "approve"], [/^reject/i, "reject"],
  [/remember/i, "bookmark"], [/learned notes/i, "book"],
  [/^log ?out/i, "logout"], [/^sign in|^log ?in/i, "login"],
  [/backup/i, "download"], [/restore/i, "upload"], [/download/i, "download"],
  [/full screen/i, "maximize"], [/show icons|hide icons/i, "eye"], [/hide menu|show menu/i, "panel"],
  [/separate window|open data/i, "external"], [/^open$|^preview/i, "external"],
  [/offline|local agent/i, "cpu"], [/cloud ai/i, "spark"],
  [/^send|^ask/i, "send"], [/attach/i, "clip"], [/show balance|balance sheet/i, "balance"],
  [/undo/i, "undo"], [/cascade/i, "windows"], [/^tile/i, "panel"], [/minimi[sz]e all/i, "minus"], [/close all/i, "windows"],
  [/ai key/i, "key"], [/password/i, "key"], [/^search|^find/i, "search"],
  [/^paid/i, "paidcheck"], [/^edit/i, "pencil"], [/^theme/i, "palette"], [/refresh|^sync|^retry/i, "refresh"],
  [/^clear/i, "eraser"], [/^add/i, "plus"],
];
function iconNameFor(label) { for (const [re, name] of ICON_RULES) if (re.test(label)) return name; return null }

/* Adds the right icon to every button and menu action that has none yet (idempotent). */
function decorateButtons() {
  document.querySelectorAll("button.btn, button.lb, .dd a[data-ac]").forEach(b => {
    const label = b.textContent.replace(/\s+/g, " ").trim();
    if (b._icoLabel === label) return;
    b._icoLabel = label;
    const old = b.querySelector(":scope > svg.ic[data-auto]");
    if (old) old.remove();
    const name = iconNameFor(label);
    if (name && !b.querySelector("input")) b.insertAdjacentHTML("afterbegin", SVG_ICON(name, "", true));
  });
}
let _icoQueued = false;
function queueDecorate() {
  if (_icoQueued) return;
  _icoQueued = true;
  requestAnimationFrame(() => { _icoQueued = false; decorateButtons(); fillLogos() });
}
new MutationObserver(queueDecorate).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
/* Company logo (item 3): the file ims-web/assets/logo.* is embedded by build.py as window.IMS_LOGO.
   It is shown on the login page and on the main menu bar. Nothing is shown until a logo is supplied. */
function fillLogos() {
  const key = window.IMS_LOGO ? "y" : "n";
  document.querySelectorAll("[data-logo]").forEach(el => {
    if (el._lg === key) return;
    el._lg = key;
    el.innerHTML = window.IMS_LOGO ? `<img class="logo-img" src="${window.IMS_LOGO}" alt="Logo">` : "";
  });
}
document.addEventListener("DOMContentLoaded", () => {
  // the theme chosen last time (saved in this browser), before anything is shown
  try { const th = localStorage.getItem("ims-theme"); if (th) document.documentElement.dataset.theme = th; } catch (e) {}
  decorateButtons(); fillLogos() });
