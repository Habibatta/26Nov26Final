/* Chat, menus, start-up and login */
/* ===== chat (shared through the database): names, online status, read receipts, delete ===== */
function chatUI(root){let curId=null,arm=null;
 root.innerHTML=`<h1>Chat</h1><div class="chat"><div class="sd"><div class="rms"></div><div style="padding:8px;display:grid;gap:6px"><select class="inp ps"></select><button class="btn nc">Start chat</button><button class="btn ng">New group</button><div class="gf" style="display:none;gap:6px"><input class="inp gn" placeholder="Group name"><div class="gm"></div><button class="btn p gc">Create group</button><span class="ge" style="color:var(--bad)"></span></div></div></div><div class="mn"><div class="hd"><span class="ht">Select or start a conversation</span><small class="hs"></small><div class="hm" style="margin-top:4px"></div></div><div class="log"></div><div class="btns"><label class="btn" title="Attach a file or picture">${ICO.clip}<input type="file" hidden></label><input class="inp cmsg" style="flex:1" placeholder="Type a message"><button class="btn p sd2">Send</button></div><div class="fn" style="color:var(--muted);font-size:11px"></div></div></div>`;
 const log=$(".log",root),fi=$("input[type=file]",root),ti=$("input.cmsg",root),names=()=>Object.keys(db.users).filter(u=>u!==me);
 const cur=()=>visRooms().find(r=>r.id==curId),peer=r=>r.p.find(p=>p!==me)||"",dot=u=>onlineU(u)?"🟢":"⚪",st=u=>onlineU(u)?"online":"offline";
 const last=r=>db.msgs.filter(m=>m.room==r.id&&m.id>cutOf(r)).slice(-1)[0],unread=r=>unreadMsgs().filter(m=>m.room==r.id).length;
 const canManage=r=>r.g&&(U().su||r.owner===me);
 const active=()=>wins.chat&&actK==="chat"&&!wins.chat.el.classList.contains("min");
 const esc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;");
 const nodes=new Map();
 const rl=()=>{const box=$(".rms",root),list=visRooms().sort((a,b)=>((last(b)||b).id)-((last(a)||a).id)),keep=new Set();
  list.forEach((r,i)=>{let d=nodes.get(r.id);if(!d){d=document.createElement("div");d.onclick=()=>{curId=r.id;arm=null;root._hs="";rl();ml()};nodes.set(r.id,d)}keep.add(r.id);
   const u=unread(r),l=last(r),pr=peer(r),cls="rm"+(r.id==curId?" on":"")+(u&&r.id!=curId?" blink":""),prev=l?(l.gone?"Message unsent":(l.t||"📎 file")).slice(0,34):"No messages yet";
   const html=`<b>${r.g?"👥 "+esc(r.t):dot(pr)+" "+esc(nameOf(pr))}${u?`<span class="ub">${u}</span>`:""}</b><small style="display:block;color:var(--muted)">${r.g?r.p.length+" members · "+r.p.filter(onlineU).length+" online":"@"+esc(pr)+" · "+st(pr)}</small><small style="display:block;color:var(--muted)"></small>`;
   if(d.className!==cls)d.className=cls;const sig=html+"|"+prev;if(d._sig!==sig){d.innerHTML=html;d.lastChild.textContent=prev;d._sig=sig}
   if(box.children[i]!==d)box.insertBefore(d,box.children[i]||null)});
  nodes.forEach((d,k)=>{if(!keep.has(k)){d.remove();nodes.delete(k)}})};
 const ml=()=>{const r=cur();
  if(!r){if(root._hs!==""){log.innerHTML="";$(".ht",root).textContent="Select or start a conversation";$(".hs",root).textContent="";$(".hm",root).innerHTML="";root._hs="";root._ls=""}return}
  const pr=peer(r),hs=[r.id,r.g?r.t:"",r.p.join(","),r.p.map(nameOf).join(","),r.p.map(u=>onlineU(u)?1:0).join(""),arm,canManage(r)?1:0].join("|");
  if(root._hs!==hs){root._hs=hs;
   $(".ht",root).textContent=r.g?"👥 Group: "+r.t:"💬 Chatting with "+nameOf(pr);ti.placeholder="Message "+(r.g?r.t:nameOf(pr));
   $(".hs",root).textContent=r.g?"Members: "+r.p.length+" ("+r.p.filter(onlineU).length+" online)":"@"+pr+" · "+dot(pr)+" "+st(pr);
   const hm=$(".hm",root);hm.innerHTML="";
   if(r.g)r.p.forEach(u=>{const c=document.createElement("span");c.className="chip";c.style.marginRight="4px";c.textContent=`${dot(u)} ${nameOf(u)} (@${u})${u===me?" - you":""}`;if(canManage(r)&&u!==me){const x=document.createElement("button");x.textContent="✕";x.title="Remove "+nameOf(u)+" from this group";x.style.cssText="border:0;background:none;color:var(--bad);cursor:pointer";x.onclick=()=>{const rr=db.rooms.find(y=>y.id==r.id)||r;rr.p=rr.p.filter(y=>y!==u);persist("rooms",rr);logH("Removed","Chat",nameOf(u)+" from "+r.t);rl();ml()};c.appendChild(x)}hm.appendChild(c)});
   const mk=(t,k)=>{const b=document.createElement("button");b.className="btn d";b.style.marginLeft="6px";b.textContent=arm===k?"Click again to confirm":t;b.onclick=()=>{if(arm!==k){arm=k;ml();return}arm=null;doDel(k,r)};hm.appendChild(b)};
   if(r.g){mk("Leave group","leave");if(canManage(r))mk("Delete group","delgrp")}else mk("Delete chat & history","delchat")}
  if(active()){const un=db.msgs.filter(m=>m.room==r.id&&m.id>cutOf(r)&&m.f!==me&&!m.gone&&!(m.readBy||[]).includes(me));un.forEach(m=>{(m.readBy=m.readBy||[]).push(me);persist("msgs",m)});if(un.length){rl();badge()}}
  const msgs=db.msgs.filter(m=>m.room==r.id&&m.id>cutOf(r)),ls=r.id+"|"+r.p.length+"|"+r.p.map(nameOf).join(",")+"|"+msgs.map(m=>[m.id,m.gone?1:0,(m.readBy||[]).join(","),m.u?1:0,m.t].join(":")).join(";");
  if(root._ls===ls)return;root._ls=ls;
  const near=log.scrollHeight-log.scrollTop-log.clientHeight<60||log.children.length===0;log.innerHTML="";
  msgs.forEach(m=>{const b=document.createElement("div");b.className="bub"+(m.f===me?" me":"")+(m.gone?" gone":"");
   if(m.gone)b.textContent=m.f===me?"You unsent this message":"This message was unsent";
   else{if(m.f!==me){const w=document.createElement("b");w.style.cssText="font-size:11px;color:var(--acc);display:block";w.textContent=nameOf(m.f);b.appendChild(w)}
    if(m.t){const t=document.createElement("div");t.style.whiteSpace="pre-wrap";t.textContent=m.t;b.appendChild(t)}
    if(m.u){const a=document.createElement("a");a.href="#";a.title="Click to download";a.onclick=ev=>{ev.preventDefault();downloadFile({u:m.u,n:m.n||"file"})};if(m.img){const i=document.createElement("img");i.src=m.u;a.appendChild(i)}else a.textContent="📎 "+(m.n||"file")+" (download)";b.appendChild(a)}
    if(m.f===me){const u=document.createElement("button");u.className="btn u";u.textContent="↩ Undo";u.onclick=()=>{const mm=db.msgs.find(y=>y.id==m.id)||m;mm.gone=true;mm.t="";mm.u=null;persist("msgs",mm);root._ls="";ml();rl()};b.appendChild(u)}
    const tm=new Date(Math.floor(m.id/1000)),hh=tm.toTimeString().slice(0,5),others=r.p.filter(x=>x!==me),seen=others.filter(x=>(m.readBy||[]).includes(x)),rc=document.createElement("div");rc.className="rcpt"+(m.f===me&&others.length&&seen.length===others.length?" all":"");
    rc.textContent=hh+(m.f===me?"  "+(seen.length?"✓✓ ":"✓ ")+(seen.length?(r.g?"Seen by "+seen.map(nameOf).join(", "):"Seen"):"Sent"):"");b.appendChild(rc)}
   log.appendChild(b)});if(near)log.scrollTop=log.scrollHeight};
 function doDel(k,r){r=db.rooms.find(y=>y.id==r.id)||r;if(k==="delchat"){r.clr={...(r.clr||{}),[me]:nid()};r.del=[...new Set([...(r.del||[]),me])];persist("rooms",r);logH("Deleted","Chat","with "+nameOf(peer(r))+" (history cleared)");if(r.p.every(u=>r.del.includes(u))){db.msgs.filter(m=>m.room==r.id).forEach(m=>unpersist("msgs",m));db.msgs=db.msgs.filter(m=>m.room!=r.id);unpersist("rooms",r);db.rooms=db.rooms.filter(x=>x.id!=r.id)}}
  if(k==="leave"){r.p=r.p.filter(x=>x!==me);persist("rooms",r);logH("Left","Chat",r.t)}
  if(k==="delgrp"){db.msgs.filter(m=>m.room==r.id).forEach(m=>unpersist("msgs",m));db.msgs=db.msgs.filter(m=>m.room!=r.id);unpersist("rooms",r);db.rooms=db.rooms.filter(x=>x.id!=r.id);logH("Deleted","Chat","group "+r.t)}
  curId=null;root._hs="";root._ls="";rl();ml();badge()}
 const fill=()=>{const fs=names().map(n=>n+"="+nameOf(n)).join("|");if(root._fs===fs)return;root._fs=fs;const sel=$(".ps",root),v=sel.value;sel.innerHTML=`<option value="">Choose a user...</option>`+names().map(n=>`<option value="${esc(n)}">${esc(nameOf(n))} (@${esc(n)})</option>`).join("");sel.value=v;$(".gm",root).innerHTML=names().map(n=>`<label style="display:block;font-weight:400"><input type="checkbox" value="${esc(n)}"> ${esc(nameOf(n))} (@${esc(n)})</label>`).join("")||"<span style='color:var(--muted)'>No other users yet.</span>"};
 $(".nc",root).onclick=()=>{const p=$(".ps",root).value;if(!p)return;let r=db.rooms.find(r=>!r.g&&r.p.includes(me)&&r.p.includes(p));if(r&&(r.del||[]).includes(me)){r.del=r.del.filter(x=>x!==me);persist("rooms",r)}if(!r){r={id:nid(),g:false,t:"",p:[me,p],del:[]};db.rooms.push(r);persist("rooms",r)}curId=r.id;arm=null;rl();ml()};
 $(".ng",root).onclick=()=>{const g=$(".gf",root);g.style.display=g.style.display==="none"?"grid":"none"};
 $(".gc",root).onclick=()=>{const n=$(".gn",root).value.trim(),m=[...root.querySelectorAll(".gm input:checked")].map(x=>x.value),er=$(".ge",root);if(!n)return er.textContent="Enter a group name.";if(!m.length)return er.textContent="Pick at least one member.";er.textContent="";const r={id:nid(),g:true,t:n,p:[me,...m],owner:me,del:[]};db.rooms.push(r);persist("rooms",r);$(".gn",root).value="";$(".gf",root).style.display="none";curId=r.id;rl();ml()};
 fi.onchange=()=>{$(".fn",root).textContent=fi.files[0]?.name||""};
 const send=async()=>{const r=cur();if(!r)return;const t=ti.value.trim(),f=fi.files[0];if(!t&&!f)return;ti.value="";fi.value="";$(".fn",root).textContent="";let u=null,n=null;if(f){const up=await uploadFile(f);u=up.u;n=up.n}
  const m={id:nid(),room:r.id,f:me,t,u,n,img:!!(f&&f.type.startsWith("image/")),gone:false,readBy:[me]};db.msgs.push(m);persist("msgs",m);if((r.del||[]).length){r.del=[];persist("rooms",r)}ml();rl()};
 $(".sd2",root).onclick=send;ti.onkeydown=e=>{if(e.key==="Enter")send()};root._tick=()=>{fill();rl();ml()};root._cur=()=>curId;
 const iv=setInterval(()=>{if(!root.isConnected){clearInterval(iv);return}rl();ml()},30000);
 fill();const f0=visRooms()[0];if(f0)curId=f0.id;rl();ml()}

function boot(){const pg=PAGES.filter(p=>p[0]==="users"?U().su:can(p[0]));
 $("#mb").innerHTML=`<div class="menu"><span>File</span><div class="dd"><a data-ac="closeall">Close all windows</a><a data-ac="sync">Server &amp; sync…</a>${window.IMS_LOCAL&&U().su?`<a data-ac="backup">Backup data…</a><a data-ac="restore">Restore data…</a><a data-ac="pgbackup">Save one page's data…</a><a data-ac="pgremove">Remove one page's data…</a><a data-ac="pgrestore">Restore removed page data…</a><a data-ac="aiprovider">AI provider…</a><a data-ac="aikey">AI key…</a>`:""}</div></div>`+["Masters","Accounts","Payroll","Tools","Admin"].filter(g=>pg.some(p=>p[3]===g)).map(g=>`<div class="menu"><span>${g}</span><div class="dd">${pg.filter(p=>p[3]===g).map(p=>`<a data-w="${p[0]}">${p[2]}&nbsp; ${p[1]}</a>`).join("")}</div></div>`).join("")+`<div class="menu"><span>Window</span><div class="dd"><a data-ac="th">Tile horizontally</a><a data-ac="tv">Tile vertically</a><a data-ac="tg">Tile as grid</a><a data-ac="cas">Cascade</a><a data-ac="mn">Minimise all</a></div></div><div class="menu"><span>Theme</span><div class="dd">${["classic","dark","blue","green"].map(t=>`<a data-th="${t}">${t[0].toUpperCase()+t.slice(1)}</a>`).join("")}</div></div><div class="sp"></div><button class="lb" data-ac="fs" title="Hide the menus, toolbar and taskbar to see more of the screen">Full screen view</button><button class="lb" data-ac="ic" title="Show or hide the icon buttons row">${document.documentElement.classList.contains("icons")?"Hide icons":"Show icons"}</button><button class="lb" data-ac="mb" title="Show or hide the menu bar">Hide menu</button><span class="mebadge" title="Signed in as ${spEsc(me)}">${avatarOf(me)}<b>${spEsc(nameOf(me))}</b></span><button class="lb" data-ac="out">Log out (${me})</button>`;
 $("#tbar").innerHTML=pg.map(p=>`<button class="tb" data-w="${p[0]}"><i>${p[2]}</i>${p[1]}</button>`).join("")+`<span style="width:1px;background:var(--bd);margin:2px 6px"></span>`;
 $("#who").innerHTML=`${avatarOf(me)}<span>User: <b>${spEsc(me)}</b>${U().su?" (super user)":""}</span>`;}
function setIcons(on){document.documentElement.classList.toggle("icons",on);const b=document.querySelector("[data-ac=ic]");if(b)b.textContent=on?"Hide icons":"Show icons";try{localStorage.setItem("ims-icons",on?"on":"off")}catch(e){}}
try{setIcons(localStorage.getItem("ims-icons")==="on")}catch(e){}
function setLayout(m){const r=document.documentElement;r.classList.toggle("nomenu",m!=="normal");r.classList.toggle("fullscr",m==="full");const b=document.querySelector("[data-ac=mb]");if(b)b.textContent=m=="normal"?"Hide menu":"Show menu";const f=document.getElementById("fsx");if(f)f.textContent=m=="full"?"Exit full screen":"Show menu";try{localStorage.setItem("ims-layout",m)}catch(e){}}
try{setLayout(localStorage.getItem("ims-layout")||"normal")}catch(e){}
document.addEventListener("click",e=>{const a=e.target.closest("[data-w],[data-ac],[data-th]");if(!a||!me)return;
 if(a.dataset.w)openW(a.dataset.w);else if(a.dataset.th){document.documentElement.dataset.theme=a.dataset.th;try{localStorage.setItem("ims-theme",a.dataset.th)}catch(e){}}else{const c=a.dataset.ac;
  if(c==="th")tile("h");if(c==="tv")tile("v");if(c==="tg")tile("g");if(c==="cas")cascade();if(c==="sync")IMS_LOCAL.serverSettings();if(U().su&&c==="backup")IMS_LOCAL.backup();if(U().su&&c==="restore")IMS_LOCAL.restore();if(U().su&&c==="pgbackup")IMS_LOCAL.pageBackup();if(U().su&&c==="pgremove")IMS_LOCAL.pageRemove();if(U().su&&c==="pgrestore")IMS_LOCAL.pageRestoreRemoved();if(U().su&&c==="aikey")IMS_LOCAL.aikey();if(U().su&&c==="aiprovider")IMS_LOCAL.aiprovider();if(c==="mn")Object.keys(wins).forEach(mini);if(c==="fs")setLayout("full");if(c==="mb")setLayout(document.documentElement.classList.contains("nomenu")?"normal":"nomenu");if(c==="fsx")setLayout("normal");if(c==="ic")setIcons(!document.documentElement.classList.contains("icons"));if(c==="closeall")Object.keys(wins).forEach(closeW);
  if(c==="out"){logH("Logout","Sign out");stopPresence();notifyReady=false;Object.keys(wins).forEach(closeW);me=null;$("#app").style.display="none";$("#login").style.display="flex"}}});
$("#lf").onsubmit=async e=>{e.preventDefault();const er=$("#lerr");try{const raw=$("#lu").value.trim(),u=Object.keys(db.users).find(k=>k.toLowerCase()===raw.toLowerCase())||raw,x=db.users[u],pw=$("#lp").value;let ok=false;
 if(x&&x.active!==false)ok=x.pw===await H(pw)||(pw!==pw.trim()&&x.pw===await H(pw.trim()));
 if(!ok){er.textContent=!raw?"Enter your username.":!x?"No user named “"+raw+"”. (The first user is admin.)":x.active===false?"This account is disabled.":!x.pw?"This account has no password set. Ask the admin to set one.":"Wrong password.";er.style.display="block";return}
 me=u;window.IMS_LOCAL&&IMS_LOCAL.signedIn&&IMS_LOCAL.signedIn(u,pw);logH("Login","Sign in");er.style.display="none";$("#lp").value="";$("#login").style.display="none";$("#app").style.display="flex";boot();noteDefault();startPresence();notifyInit();badge()}catch(err){er.textContent="Login error: "+(err&&err.message||err);er.style.display="block"}};
document.addEventListener("click",e=>{const s=e.target.closest&&e.target.closest(".menu>span");const menus=document.querySelectorAll(".menu.open");
 if(s){const m=s.parentElement,was=m.classList.contains("open");menus.forEach(x=>x.classList.remove("open"));if(!was)m.classList.add("open");e.stopPropagation();return}
 menus.forEach(x=>x.classList.remove("open"))},true);
init();
setInterval(()=>{$("#clock").textContent=new Date().toLocaleString([],{dateStyle:"medium",timeStyle:"short"})},1000);
