/* Approvals, files, presence, notifications, employment window helpers */
/* ===== approvals, files, presence helpers ===== */
const isApprover=()=>!!(U().su||U().approver);
const expStatus=()=>isApprover()?{status:"Approved",reqBy:me,apprBy:me,apprAt:T,reason:""}:{status:"Pending",reqBy:me,apprBy:"",apprAt:"",reason:""};
const stTxt=r=>{const s=r.status||"Approved";return s==="Rejected"?"Rejected"+(r.reason?": "+r.reason:""):s==="Pending"?"Pending approval":"Approved"};
const postedExp=()=>db.exp.filter(e=>(e.status||"Approved")==="Approved");
const okFile=f=>/\.(pdf|jpe?g|png)$/i.test(f.name||"");
async function downloadFile(f){try{if(!DL){window.open(f.u,"_blank");return}const r=await fetch(f.u);if(!r.ok)throw new Error("HTTP "+r.status);await DL.save({filename:f.n||"file",data:await r.arrayBuffer()})}catch(e){if(!e||e.code!=="declined")toast("Could not download the file: "+(e&&(e.message||e.code)||e))}}
document.addEventListener("click",e=>{const a=e.target.closest&&e.target.closest(".fdl");if(!a)return;e.preventDefault();e.stopPropagation();const r=CF[a.dataset.k].list().find(x=>x.id==a.dataset.id),f=r&&r[a.dataset.f];if(f)downloadFile(f)},true);
let hbT=null;
const onlineU=u=>{if(u===me)return true;const p=db.presence.find(x=>x.id===u);return !!p&&Date.now()-p.at<35000};
function startPresence(){const beat=()=>persist("presence",{id:me,at:Date.now()});beat();clearInterval(hbT);hbT=setInterval(()=>{if(me)beat()},12000)}
function stopPresence(){clearInterval(hbT);if(me)persist("presence",{id:me,at:0})}
window.addEventListener("beforeunload",()=>{try{if(me&&STORE)STORE.collection("presence").doc(me).set({id:me,at:0})}catch(e){}});
function notice(text,key){let box=document.getElementById("toasts");if(!box){box=document.createElement("div");box.id="toasts";document.body.appendChild(box)}
 while(box.children.length>=4)box.firstChild.remove();const t=document.createElement("div");t.className="toastn";const m=document.createElement("div");m.style.flex="1";m.textContent=text;t.appendChild(m);
 if(key&&can(key)){const b=document.createElement("button");b.className="btn p";b.textContent="Open";b.onclick=()=>{openW(key);t.remove()};t.appendChild(b)}
 const x=document.createElement("button");x.className="btn";x.innerHTML=ICO.x;x.onclick=()=>t.remove();t.appendChild(x);box.appendChild(t);setTimeout(()=>t.remove(),15000)}
const seenSt=new Map(),seenMsgs=new Set();let notifyReady=false;
function notifyInit(){seenSt.clear();seenMsgs.clear();db.exp.forEach(e=>seenSt.set("e"+e.id,e.status||"Approved"));db.appr.forEach(a=>seenSt.set("p"+a.id,a.status));db.msgs.forEach(m=>seenMsgs.add(m.id));notifyReady=true}
function notifyChanges(){if(!me||!notifyReady||!U())return;
 db.exp.forEach(e=>{const k="e"+e.id,st=e.status||"Approved",pv=seenSt.get(k);if(pv===st)return;seenSt.set(k,st);
  if(pv===undefined&&st==="Pending"&&isApprover()&&e.reqBy!==me)notice(`🛎️ New expense waiting for your approval: ${e.rno} · Rs ${fm(e.total)} from ${nameOf(e.reqBy)}`,"appr");
  else if(pv==="Pending"&&e.reqBy===me&&st!=="Pending")notice(`${st==="Approved"?"✅":"❌"} Your expense ${e.rno} (Rs ${fm(e.total)}) was ${st.toLowerCase()} by ${nameOf(e.apprBy)}${e.reason?": "+e.reason:""}`,"exp")});
 db.appr.forEach(a=>{const k="p"+a.id,pv=seenSt.get(k);if(pv===a.status)return;seenSt.set(k,a.status);
  if(pv===undefined&&a.status==="Pending"&&isApprover()&&a.reqBy!==me)notice(`🛎️ Payroll for ${monthName(a.month)} is waiting for your approval (${a.lines.length} employees, Rs ${fm(a.total)}) from ${nameOf(a.reqBy)}`,"appr");
  else if(pv==="Pending"&&a.reqBy===me&&a.status!=="Pending")notice(`${a.status==="Approved"?"✅":"❌"} Payroll for ${monthName(a.month)} was ${a.status.toLowerCase()} by ${nameOf(a.decidedBy)}${a.reason?": "+a.reason:""}`,"att")});
 db.msgs.forEach(m=>{if(seenMsgs.has(m.id))return;seenMsgs.add(m.id);if(m.f===me||m.gone||!can("chat"))return;const r=db.rooms.find(x=>x.id==m.room);if(!r||!(r.p||[]).includes(me)||(r.del||[]).includes(me)||m.id<=cutOf(r))return;
  const wb=wins.chat&&wins.chat.el.querySelector(".wb"),open=wins.chat&&actK==="chat"&&!wins.chat.el.classList.contains("min")&&wb&&wb._cur&&wb._cur()===r.id;
  if(!open)notice(`💬 ${nameOf(m.f)}${r.g?" in "+r.t:""}: ${m.t?String(m.t).slice(0,80):"📎 "+(m.n||"file")}`,"chat")})}
const nameOf=u=>{const x=db.users[u],e=x&&x.emp?(db.emp.find(e=>e.id==x.emp)||goneIn(db.emp,x.emp)):null;return e?fullName(e):u};
const visRooms=()=>db.rooms.filter(r=>(r.p||[]).includes(me)&&!(r.del||[]).includes(me));
const cutOf=r=>((r.clr||{})[me]||0);
const unreadMsgs=()=>{const cut=new Map(visRooms().map(r=>[r.id,cutOf(r)]));return db.msgs.filter(m=>m.f!==me&&!m.gone&&cut.has(m.room)&&m.id>cut.get(m.room)&&!(m.readBy||[]).includes(me))};
function setBadge(key,label,n,blink){const b=document.querySelector(`.toolbar .tb[data-w="${key}"]`);if(b){b.childNodes[1].textContent=label+(n?` (${n})`:"");b.classList.toggle("blink",!!blink)}if(wins[key])wins[key].btn.classList.toggle("blink",!!blink)}
function badge(){if(!me||!U())return;
 if(can("chat")){const n=unreadMsgs().length,open=wins.chat&&actK==="chat"&&!wins.chat.el.classList.contains("min");setBadge("chat","Chat",n,n>0&&!open)}
 if(can("appr")){const n=db.exp.filter(e=>(e.status||"Approved")==="Pending"&&(isApprover()||e.reqBy===me)).length+db.appr.filter(a=>a.status==="Pending"&&(isApprover()||a.reqBy===me)).length;setBadge("appr","Approvals",n,isApprover()&&n>0)}}
setInterval(badge,2500);
function purgeUserChat(u){db.rooms.filter(r=>(r.p||[]).includes(u)).forEach(r=>{if(!r.g){db.msgs.filter(m=>m.room==r.id).forEach(m=>unpersist("msgs",m));db.msgs=db.msgs.filter(m=>m.room!=r.id);unpersist("rooms",r);db.rooms=db.rooms.filter(x=>x.id!=r.id)}else{r.p=r.p.filter(x=>x!==u);persist("rooms",r)}});
 db.msgs.filter(m=>m.f===u).forEach(m=>unpersist("msgs",m));db.msgs=db.msgs.filter(m=>m.f!==u);if(STORE)unpersist("presence",{id:u});logH("Deleted","Chat","all chats and history of "+u)}
function renameUserChat(a,b){db.rooms.filter(r=>(r.p||[]).includes(a)).forEach(r=>{r.p=r.p.map(x=>x===a?b:x);if(r.owner===a)r.owner=b;persist("rooms",r)});db.msgs.filter(m=>m.f===a||(m.readBy||[]).includes(a)).forEach(m=>{if(m.f===a)m.f=b;m.readBy=(m.readBy||[]).map(x=>x===a?b:x);persist("msgs",m)})}
function tickChat(){if(PD){setTimeout(tickChat,200);return}Object.values(wins).forEach(w=>{const b=w.el.querySelector(".chat");if(b){const wb=w.el.querySelector(".wb");try{wb._tick&&wb._tick()}catch(e){}}});badge()}
/* ===== employment window (DOJ / End Date) ===== */
const empWin=e=>({s:e.doj||e.date||"0000-00-00",e:e.dol||(e.status==="Inactive"?"0000-00-00":"9999-12-31")});
const dimOf=m=>{const[y,mo]=m.split("-").map(Number);return new Date(y,mo,0).getDate()};
const outsideDay=(e,m,d)=>{const w=empWin(e),x=m+"-"+String(d).padStart(2,"0");return x<w.s||x>w.e};
const employedInMonth=(e,m)=>{for(let d=1;d<=dimOf(m);d++)if(!outsideDay(e,m,d))return true;return false};
/* ----- working days: Saturdays, Sundays and holidays (Holidays setup page) are never deducted ----- */
const dowOf=(m,d)=>{const[y,mo]=m.split("-").map(Number);return new Date(y,mo-1,d).getDay()};
const isWeekend=(m,d)=>{const w=dowOf(m,d);return w===0||w===6};
const holName=(m,d)=>{const x=(db.hol||[]).find(h=>h.date===m+"-"+String(d).padStart(2,"0"));return x?(x.name||"Holiday"):""};
const nonWork=(m,d)=>isWeekend(m,d)||!!holName(m,d);
const workDaysIn=m=>{let c=0;for(let d=1;d<=dimOf(m);d++)if(!nonWork(m,d))c++;return c};
const payLine=(e,s,m,a)=>{const n=workDaysIn(m)||1,lv=((a&&a.leaves)||[]).filter(d=>!outsideDay(e,m,d)&&!nonWork(m,d)),out=Array.from({length:dimOf(m)},(_,i)=>i+1).filter(d=>outsideDay(e,m,d)&&!nonWork(m,d)).length,g=s?s.gross:0,per=g/n,ded=Math.round(per*(lv.length+out)*100)/100;
 return{emp:e.id,eno:e.eno,name:fullName(e),desig:e.desig,basic:s?s.basic:0,rent:s?s.rent:0,util:s?s.util:0,benefits:s?(s.benefits||[]):[],gross:g,workDays:n,perDay:Math.round(per*100)/100,leaves:lv.length,leaveDays:lv,outside:out,deduction:ded,net:Math.round((g-ded)*100)/100}};
function approvePayroll(a){const made=[];a.lines.forEach(l=>{if(db.paid.some(p=>p.emp==l.emp&&p.month===a.month))return;const p={id:nid(),date:T,month:a.month,...l,reqId:a.id,by:a.reqBy};db.paid.push(p);persist("paid",p);made.push(p)});a.status="Approved";a.decidedBy=me;a.decidedAt=T;a.reason="";persist("appr",a);logH("Approved","Payroll",`${monthName(a.month)}: ${made.length} employees, Rs ${fm(a.total)}`);return made.length}
function rejectPayroll(a,reason){a.status="Rejected";a.decidedBy=me;a.decidedAt=T;a.reason=reason||"";persist("appr",a);logH("Rejected","Payroll",`${monthName(a.month)}${reason?": "+reason:""}`)}
const nm=(a,id)=>(a.find(x=>x.id==id)||goneIn(a,id)||{}).name||"";

/* ===== confirmation before any save (every Save button) ===== */
function askSave(what){return new Promise(res=>{const old=document.getElementById("cfm");if(old)old.remove();
 const box=document.createElement("div");box.id="cfm";
 box.innerHTML=`<div class="cfm-card" role="dialog" aria-modal="true" aria-labelledby="cfm-t"><div class="cfm-t" id="cfm-t">Please confirm</div><div class="cfm-b"></div><div class="btns"><button type="button" class="btn p" data-y>Yes, save</button><button type="button" class="btn" data-n>No, go back</button></div></div>`;
 box.querySelector(".cfm-b").textContent=what;document.body.appendChild(box);
 const done=v=>{box.remove();document.removeEventListener("keydown",kd,true);res(v)};
 const kd=e=>{if(e.key==="Escape"){e.preventDefault();done(false)}else if(e.key==="Enter"){e.preventDefault();done(true)}};
 document.addEventListener("keydown",kd,true);
 box.addEventListener("pointerdown",e=>{if(e.target===box)done(false)});
 box.querySelector("[data-y]").onclick=()=>done(true);box.querySelector("[data-n]").onclick=()=>done(false);
 box.querySelector("[data-n]").focus()})}

/* ===== pictures and default avatars ===== */
const okImg=f=>/\.(jpe?g|png|gif|webp)$/i.test((f&&f.name)||"");
function imgData(f){return new Promise((res,rej)=>{const r=new FileReader();r.onerror=()=>rej(new Error("the file could not be read"));
 r.onload=()=>{const im=new Image();im.onerror=()=>rej(new Error("the file is not a picture"));
  im.onload=()=>{const m=256,s=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement("canvas");c.width=Math.max(1,Math.round(im.width*s));c.height=Math.max(1,Math.round(im.height*s));c.getContext("2d").drawImage(im,0,0,c.width,c.height);res(c.toDataURL("image/jpeg",0.85))};
  im.src=r.result};r.readAsDataURL(f)})}
/* Male or female default avatar, used when no picture was uploaded in Employee Registration */
function avatarSVG(g){const fem=g==="Female";const bg=fem?"#f8d7e4":"#d6e6fb",sk="#f2c9a5",hair=fem?"#6b3e2e":"#3b3b3b",body=fem?"#c95b8a":"#2f5d8a";
 const back=fem?`<ellipse cx="32" cy="29" rx="15" ry="17" fill="${hair}"/>`:"";
 const cap=fem?`<path d="M19 26c2-8 7-11 13-11s11 3 13 11c-4-2-8-3-13-3s-9 1-13 3z" fill="${hair}"/>`:`<path d="M21 25c0-7 4-11 11-11s11 4 11 11c-3-2-6-3-11-3s-8 1-11 3z" fill="${hair}"/>`;
 return `<svg class="avsvg" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${fem?"Female":"Male"} avatar"><rect width="64" height="64" rx="32" fill="${bg}"/>${back}<circle cx="32" cy="28" r="10" fill="${sk}"/>${cap}<path d="M12 64c1-12 9-19 20-19s19 7 20 19z" fill="${body}"/></svg>`}
/* Picture of a user: the employee's uploaded picture, else the male or female avatar */
function avatarOf(u){const x=db.users[u],e=x&&x.emp?db.emp.find(y=>y.id==x.emp):null;
 if(e&&e.photo)return `<img class="pic" src="${e.photo}" alt="">`;return avatarSVG(e&&e.gender==="Female"?"Female":"Male")}

/* ===== salary benefits editor: each row is a benefit chosen from a list (or typed under "Other");
   the rows are saved with the salary and their total is added to gross salary ===== */
const BEN_TYPES=["Medical","Fuel / Transport","Conveyance","House allowance","Mobile / Phone","Food / Lunch","Bonus","Overtime","Education","Special allowance"];
const BEN_OTHER="__other";
function benEditor(box,hid,onch){
 const attr=v=>String(v??"").replace(/&/g,"&amp;").replace(/"/g,"&quot;");
 const opts=`<option value="">Choose a benefit</option>`+BEN_TYPES.map(t=>`<option value="${attr(t)}">${t}</option>`).join("")+`<option value="${BEN_OTHER}">Other (type the name)</option>`;
 box.innerHTML=`<div class="ben-list"></div><div class="ben-foot"><button type="button" class="btn" data-badd>Add benefit</button><span class="ben-tot"></span></div>`;
 const list=box.querySelector(".ben-list"),tot=box.querySelector(".ben-tot");
 const showOther=r=>{const o=r.querySelector("[data-bo]");o.style.display=r.querySelector("[data-bt]").value===BEN_OTHER?"":"none"};
 const read=()=>[...list.querySelectorAll(".ben-row")].map(r=>{const v=r.querySelector("[data-bt]").value;
   return{name:v===BEN_OTHER?r.querySelector("[data-bo]").value.trim():v,amount:r.querySelector("[data-ba]").value}});
 const sync=()=>{const L=read();hid.value=JSON.stringify(L);tot.textContent=`Total benefits: Rs ${fm(benTotal(L))}`;onch&&onch()};
 const add=(name="",amt="")=>{const d=document.createElement("div");d.className="ben-row";
   const known=BEN_TYPES.includes(name);
   d.innerHTML=`<select class="inp" data-bt aria-label="Benefit">${opts}</select><input class="inp" data-bo placeholder="Type the benefit name" value="${attr(known?"":name)}" style="display:none"><input class="inp" type="number" min="0" step="0.01" data-ba placeholder="Amount" value="${attr(amt)}"><button type="button" class="btn d" data-br aria-label="Remove benefit">${ICO.x}</button>`;
   d.querySelector("[data-bt]").value=known?name:(name?BEN_OTHER:"");
   list.appendChild(d);showOther(d)};
 box.onclick=e=>{if(e.target.closest("[data-badd]")){add();sync();return}const rm=e.target.closest("[data-br]");if(rm){rm.closest(".ben-row").remove();sync()}};
 box.addEventListener("change",e=>{const r=e.target.closest&&e.target.closest(".ben-row");if(!r)return;if(e.target.matches("[data-bt]"))showOther(r);sync()});
 box.addEventListener("input",e=>{if(e.target.closest&&e.target.closest(".ben-row"))sync()});
 hid.value="[]";tot.textContent="Total benefits: Rs 0.00";
 return{total:()=>benTotal(read()),load:arr=>{list.innerHTML="";(arr||[]).forEach(x=>add(x.name,x.amount));sync()}};
}
