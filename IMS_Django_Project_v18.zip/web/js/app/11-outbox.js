/* ===== Offline outbox =====
   Enter Purchases / Enter Sales entries are queued in this browser and sent to the server (/api/sync/)
   when it can be reached. Nothing leaves the queue until the server answers.
   - ok / duplicate: applied on the server. Purchase batch numbers are replaced by the server's numbers
     here and in any queued sale that uses them.
   - conflict / discarded: the server keeps it for review (Sync conflicts page); it leaves this outbox.
   - no answer (server down, network error, 5xx): kept and retried later.
   Set the server address with OUTBOX.setServer("http://host:port"). Empty = offline only, nothing is sent.
   Edits made after an entry was sent are kept in this browser only; they are not sent again. */
const OUTBOX = (() => {
  const K_Q = "ims-outbox", K_SENT = "ims-outbox-sent", K_DEV = "ims-device", K_URL = "ims-sync-url", K_MAP = "ims-batch-map";
  const get = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v) } catch (e) { return d } };
  const put = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)) } catch (e) {} };
  let busy = false;

  const device = () => { let d = get(K_DEV, ""); if (!d) { d = "dev-" + Math.random().toString(36).slice(2, 10); put(K_DEV, d) } return d };
  const vendName = id => { const v = (db.vend || []).find(x => x.id == id); return v ? v.name : "" };
  const csrf = () => { const m = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/); return m ? decodeURIComponent(m[1]) : "" };
  const queue = () => get(K_Q, []);
  const setQueue = q => put(K_Q, q);
  const sentKeys = () => get(K_SENT, []);
  const markSent = key => { const s = sentKeys(); if (!s.includes(key)) { s.push(key); put(K_SENT, s) } };

  /* One cash payment, sent after its invoice has reached the server. */
  function paymentEntry(kind, rec, pay) {
    return { key: "pay:" + pay.id, kind: "payment", localId: String(pay.id),
             client_id: device() + ":pay:" + pay.id,
             data: { invoice_client_id: device() + ":" + (kind === "purch" ? "purchase" : "sale") + ":" + rec.id,
                     date: pay.date, amount: pay.amount } };
  }

  function entryFor(kind, rec) {
    const lines = (rec.lines || []).map(l => ({ batch: l.batch, item: l.item, unit: l.unit, qty: l.qty, price: l.price }));
    const data = kind === "purch"
      ? { vendor_name: vendName(rec.vend), invoice_no: rec.no || "", discount: rec.disc || 0, paid: rec.paid || 0, comments: rec.comments || "", lines }
      : { customer_name: vendName(rec.vend), discount: rec.disc || 0, paid: rec.paid || 0, comments: rec.comments || "",
          lines: lines.map(l => ({ batch: l.batch, qty: l.qty, price: l.price })) };
    return { key: kind + ":" + rec.id, kind: kind === "purch" ? "purchase" : "sale", localId: String(rec.id),
             client_id: device() + ":" + kind + ":" + rec.id, data };
  }

  /* Queue (or refresh, while not yet sent) one Purchase or Sale record. */
  function add(kind, rec) {
    const e = entryFor(kind, rec);
    if (sentKeys().includes(e.key)) return false;
    const q = queue();
    const i = q.findIndex(x => x.key === e.key);
    if (i >= 0) q[i] = e; else q.push(e);
    setQueue(q);
    return true;
  }

  /* Queue one cash payment; it is sent after its invoice (the flush order keeps invoices first). */
  function addPayment(kind, rec, pay) {
    const e = paymentEntry(kind, rec, pay);
    if (sentKeys().includes(e.key)) return false;
    const q = queue();
    q.push(e);
    setQueue(q);
    return true;
  }

  async function post(url, entries) {
    const res = await fetch(url.replace(/\/$/, "") + "/api/sync/", {
      method: "POST", credentials: "include",
      headers: { "Content-Type": "application/json", "X-CSRFToken": csrf() },
      body: JSON.stringify({ device: device(), changes: entries.map(e => ({ kind: e.kind, client_id: e.client_id, data: e.data })) })
    });
    if (!res.ok) throw Object.assign(new Error("Server answered " + res.status), { status: res.status });
    return (await res.json()).results || [];
  }

  /* Apply the server's answers. Returns the entries that still need sending. */
  function settle(entries, results) {
    const byId = new Map(results.map(r => [r.client_id, r]));
    const left = [];
    for (const e of entries) {
      const r = byId.get(e.client_id);
      if (!r) { left.push(e); continue }
      if (r.status === "ok" || r.status === "duplicate") {
        markSent(e.key);
        const map = r.batch_map || {};
        const mapped = get(K_MAP, {});
        Object.keys(map).forEach(k => { mapped[k] = map[k] });
        put(K_MAP, mapped);
        const rec = (db.purch || []).find(x => String(x.id) === e.localId);
        if (rec && Object.keys(map).length) {
          rec.lines = (rec.lines || []).map(l => ({ ...l, batch: map[l.batch] || l.batch }));
          if (typeof persist === "function") persist("purch", rec);
        }
      } else if (r.status === "conflict" || r.status === "discarded") {
        markSent(e.key);            // the server holds it for review; it does not go out again
      } else {
        left.push(e);
      }
    }
    return left;
  }

  /* Send in order: purchases (they create the server batch numbers), then sales with those numbers,
     then cash payments (each one only after its invoice exists on the server). */
  async function flush() {
    const url = get(K_URL, "");
    if (!url || busy) return { skipped: true };
    busy = true;
    try {
      const finished = new Set();
      const groups = [
        e => e.kind === "purchase",
        e => e.kind === "sale",
        e => e.kind === "payment",
      ];
      for (const pick of groups) {
        const batch = queue().filter(pick);
        if (!batch.length) continue;
        const map = get(K_MAP, {});
        const prepared = batch.map(e => e.kind !== "sale" ? e : { ...e, data: { ...e.data,
          lines: e.data.lines.map(l => ({ ...l, batch: map[l.batch] || l.batch })) } });
        const left = settle(prepared, await post(url, prepared));
        batch.forEach(e => { if (!left.some(x => x.key === e.key)) finished.add(e.key) });
        setQueue(queue().filter(e => !finished.has(e.key)));
      }
      return { pending: queue().length };
    } catch (err) {
      return { pending: queue().length, offline: true, reason: err.message };
    } finally {
      busy = false;
    }
  }

  function start() {
    if (typeof window === "undefined") return;
    window.addEventListener("online", () => { flush() });
    setInterval(() => { flush() }, 15000);
  }

  return {
    add, addPayment, flush, start,
    pending: () => queue().length,
    setServer: u => put(K_URL, String(u || "").trim()),
    server: () => get(K_URL, ""),
    _queue: queue
  };
})();

OUTBOX.start();
