/* ===== Offline-first storage and sync =====
   The app keeps a full copy of its data in this browser (IndexedDB), so it keeps working with no connection.
   Every change is saved here at once and queued for the server. When the server can be reached and the person
   is signed in, the queue is sent and the server's changes are received. Latest change wins: the change that
   reaches the server last is kept, and the replaced one is noted in History on the server.
   The server address is set with File -> Server & sync. Leave it empty to work only on this computer. */
(function(){
const DBN="ims-offline";
const mem=new Map(), subs=new Map(), queue=new Map();
let revs={}, token="", tokenUser="", lastVersion=null, syncing=false, online=true, switching=false;
const stored=localStorage.getItem("ims-server-url");
let serverUrl=stored!==null?stored:(location.protocol.startsWith("http")?location.origin:"");
const enc=k=>k.split("/").map(encodeURIComponent).join("/");
const base=()=>serverUrl.replace(/\/$/,"");
const aiBase=()=>{if(!serverUrl)throw new Error("Ollama is reached through the IMS server. Set the server address in File -> Server & sync.");return base()};
const auth=()=>token?{Authorization:"Bearer "+token}:{};
const timeout=ms=>new Promise(r=>setTimeout(r,ms));

/* IndexedDB: three small stores kept in this browser */
let dbp=null;
function DB(){return dbp||(dbp=new Promise((res,rej)=>{const r=indexedDB.open(DBN,1);
 r.onupgradeneeded=()=>{const d=r.result;["kv","queue","meta"].forEach(n=>{if(!d.objectStoreNames.contains(n))d.createObjectStore(n)})};
 r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}))}
function write(store,key,value){return DB().then(d=>new Promise((res,rej)=>{const t=d.transaction(store,"readwrite");
 if(value===undefined)t.objectStore(store).delete(key);else t.objectStore(store).put(value,key);
 t.oncomplete=()=>res();t.onerror=()=>rej(t.error)})).catch(()=>{})}
function readAll(store){return DB().then(d=>new Promise((res,rej)=>{const out={};const t=d.transaction(store,"readonly");
 const r=t.objectStore(store).openCursor();r.onsuccess=()=>{const c=r.result;if(c){out[c.key]=c.value;c.continue()}};
 t.oncomplete=()=>res(out);t.onerror=()=>rej(t.error)}))}

function clearStore(store){return DB().then(d=>new Promise(res=>{const t=d.transaction(store,"readwrite");t.objectStore(store).clear();t.oncomplete=()=>res()})).catch(()=>{})}
const docsOf=c=>[...mem].filter(([k])=>k.startsWith(c+"/")).map(([k,v])=>({id:k.slice(c.length+1),data:()=>JSON.parse(JSON.stringify(v))}));
let memVer=0, trashIdx=null, trashVer=-1;
const notify=c=>{memVer++;(subs.get(c)||[]).forEach(cb=>cb({docs:docsOf(c)}))};
/* records that were removed from their page are kept in the Trash: saved records still show their names */
function trashIndex(){if(trashIdx&&trashVer===memVer)return trashIdx;const idx={};mem.forEach((v,k)=>{if(k.startsWith("trash/")&&v&&v.records)Object.assign(idx,v.records)});trashIdx=idx;trashVer=memVer;return trashIdx}
window.goneIn=(list,id)=>{const c=Object.keys(db).find(k=>db[k]===list);return c?(trashIndex()[c+"/"+id]||null):null};
/* the app's list of one kind of record: its own find() also looks at the removed records of that kind (for names) */
window.withTrash=(c,rows)=>{Object.defineProperty(rows,"find",{configurable:true,enumerable:false,value:function(fn){const r=Array.prototype.find.call(this,fn);if(r!==undefined)return r;const idx=trashIndex();const gone=Object.keys(idx).filter(k=>k.startsWith(c+"/")).map(k=>idx[k]);return Array.prototype.find.call(gone,fn)}});return rows};

/* the app's own save: keep it here at once, and queue it for the server */
function enqueue(k,del,value){const prev=queue.get(k);
 const entry={key:k,del:!!del,value:del?undefined:value,base:prev?prev.base:(revs[k]||0)};
 queue.set(k,entry);const saved=write("queue",k,{key:k,del:entry.del,value:entry.value,base:entry.base});kick();return saved}
function setItem(k,v){const copy=JSON.parse(JSON.stringify(v));mem.set(k,copy);const saved=Promise.all([write("kv",k,copy),enqueue(k,false,copy)]);notify(k.split("/")[0]);return saved}
function delItem(k){mem.delete(k);const saved=Promise.all([write("kv",k,undefined),enqueue(k,true)]);notify(k.split("/")[0]);return saved}
const store={collection:c=>({doc:id=>({
  set:async d=>{setItem(c+"/"+id,d)},
  delete:async()=>{delItem(c+"/"+id)}}),
 onSnapshot:cb=>{const a=subs.get(c)||[];a.push(cb);subs.set(c,a);setTimeout(()=>cb({docs:docsOf(c)}),0);return()=>{}}})};

/* ----- status line ----- */
function note(text,color){const n=document.getElementById("note");if(!n)return;n.style.color=color||"";n.textContent=text}
function defaultNote(){if(typeof noteDefault==="function")noteDefault()}
const plural=n=>n+(n===1?" change":" changes");
function offline(){online=false;if(queue.size)note("Offline: "+plural(queue.size)+" saved on this computer, waiting to sync. You can keep working.","#b45309");else defaultNote()}
function needSignIn(){online=true;note("Sign in to the server to sync"+(queue.size?" ("+plural(queue.size)+" saved on this computer)":"")+". Use File -> Server & sync.","#b45309")}
function kick(){if(serverUrl&&token)setTimeout(syncNow,30)}

/* ----- receiving the server's changes ----- */
async function pull(){
 const r=await fetch(base()+"/api/kv",{cache:"no-store",headers:auth()});if(!r.ok)return;
 const o=await r.json();const changed=new Set();const serverRevs=o.revs||{};
 Object.entries(o.items).forEach(([k,v])=>{if(queue.has(k))return;const rv=serverRevs[k]||0;
  if(rv!==(revs[k]||0)||JSON.stringify(mem.get(k))!==JSON.stringify(v)){mem.set(k,v);revs[k]=rv;write("kv",k,v);changed.add(k.split("/")[0])}});
 [...mem.keys()].forEach(k=>{if(!Object.prototype.hasOwnProperty.call(o.items,k)&&!queue.has(k)){mem.delete(k);delete revs[k];write("kv",k,undefined);changed.add(k.split("/")[0])}});
 lastVersion=o.version;write("meta","revs",revs);changed.forEach(notify);
}
/* ----- sending the queue, then receiving ----- */
async function syncNow(){
 if(!serverUrl)return;
 if(!token){if(queue.size)note(plural(queue.size)+" saved on this computer. They will sync after you sign in to the server.","#b45309");return}
 if(syncing)return;syncing=true;
 try{
  let r;try{r=await fetch(base()+"/api/version",{cache:"no-store",headers:auth()})}catch(e){return offline()}
  if(r.status===401)return needSignIn();
  if(!r.ok)return offline();
  online=true;
  const sent=queue.size;
  if(sent)note("Syncing "+plural(sent)+"...","#1d4ed8");
  for(const [k,op] of [...queue]){
   const init={method:op.del?"DELETE":"PUT",headers:Object.assign({"X-Base-Rev":String(op.base||0),"content-type":"application/json"},auth())};
   if(!op.del)init.body=JSON.stringify(op.value);
   let rr;try{rr=await fetch(base()+"/api/kv/"+enc(k),init)}catch(e){return offline()}
   if(rr.status===401)return needSignIn();
   if(!rr.ok){const b=await rr.json().catch(()=>({}));return note("The server did not save "+k+" ("+(b.error||rr.status)+"). It stays on this computer.","#b91c1c")}
   const b=await rr.json();
   if(op.del)delete revs[k];else revs[k]=b.rev||0;
   const cur=queue.get(k);
   if(cur===op){queue.delete(k);write("queue",k,undefined)}
   else if(cur){cur.base=b.rev||0;write("queue",k,{key:k,del:cur.del,value:cur.value,base:cur.base})}
  }
  write("meta","revs",revs);
  await pull();
  if(sent){note("Back online: "+plural(sent)+" synced.","#15803d");setTimeout(()=>{if(!queue.size&&online)defaultNote()},6000)}
 }catch(e){offline()}finally{syncing=false}
}
/* other computers changed the data: look every 1.5 s, and send any queued change */
setInterval(async()=>{
 if(!serverUrl||!token||syncing)return;   // nothing is asked of the server until someone has signed in
 if(queue.size||!online){await syncNow();return}
 try{const r=await fetch(base()+"/api/version",{cache:"no-store",headers:auth()});
  if(r.status===401)return needSignIn();
  const v=(await r.json()).version;if(v!==lastVersion)await syncNow()}catch(e){offline()}
},1500);

/* ----- signing in to the server (the same password as in the app) ----- */
/* ----- combining this computer's records with the server (used when the server address is set) -----
   Records that exist only on this computer are sent to the server. Records that exist on both keep the
   server's version (this computer's copy is in the backup file). Nothing is deleted on either side. */
async function mergeWithServer(){
 const r=await fetch(base()+"/api/kv",{cache:"no-store",headers:auth()});
 if(!r.ok){note("Could not read the server's records. Try File -> Server & sync again.","#b91c1c");return}
 const o=await r.json();let added=0;
 mem.forEach((v,k)=>{if(!Object.prototype.hasOwnProperty.call(o.items,k)){const e={key:k,del:false,value:v,base:0};queue.set(k,e);write("queue",k,e);added++}});
 await syncNow();
 note("Combined with the server: "+plural(added)+" sent. This computer and the server now hold the same records.","#15803d");
 setTimeout(()=>{if(!queue.size&&online)defaultNote()},8000);
}
function signInPrompt(){
 const u=prompt("Username to sign in to the server (the same as in the app):","admin");
 if(!u||!u.trim()){note("Not signed in to the server. Changes stay on this computer until you sign in (File -> Server & sync).","#b45309");return}
 const p=prompt("Password for "+u.trim()+":");
 if(p===null){note("Not signed in to the server. Changes stay on this computer until you sign in (File -> Server & sync).","#b45309");return}
 signIn(u.trim(),p).then(r=>{if(!r.ok)alert("Could not sign in: "+r.error+"\nUse File -> Server & sync to try again.")});
}
async function signIn(username,pw){
 const hash=await H(pw);
 let r;try{r=await fetch(base()+"/api/login",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({username:username,pw:hash})})}
 catch(e){return{ok:false,error:"The server cannot be reached."}}
 const b=await r.json().catch(()=>({}));
 if(!r.ok)return{ok:false,error:b.error||"Could not sign in."};
 token=b.token;tokenUser=b.user;write("meta","token",token);write("meta","tokenUser",tokenUser);
 if(switching){switching=false;await mergeWithServer()}else await syncNow();
 return{ok:true,user:b.user};
}

/* ----- one page's data: save it to a file, or remove it (users and History are never removed) ----- */
const PAGE_DATA={cat:["cat"],proj:["proj"],etype:["etype"],vend:["vend"],bank:["bank"],emp:["emp"],led:["led"],
 exp:["exp"],appr:["appr"],sal:["sal"],att:["att"],hol:["hol"],paid:["paid"],purch:["purch"],sales:["sales"],
 asset:["asset"],chat:["rooms","msgs"]};
function pageList(){return Object.keys(PAGE_DATA).map(k=>[k,((typeof PAGES!=="undefined"&&PAGES.find(p=>p[0]===k))||[k,k])[1]])}
function pageKeys(pageKey){const cols=PAGE_DATA[pageKey]||[];return [...mem.keys()].filter(k=>cols.includes(k.split("/")[0]))}
/* which saved records point to this page's records (an expense points to its category, project, vendor, bank, cheque...) */
const REF_FIELDS={cat:["cat"],etype:["etype"],proj:["proj"],vend:["vend"],bank:["acct"],led:["cheque"],emp:["emp"]};
const NOT_REF=["trash","hist","presence"];
function refersTo(o,field,id){if(o===null||typeof o!=="object")return false;if(Array.isArray(o))return o.some(x=>refersTo(x,field,id));
 return Object.keys(o).some(k=>(k===field&&o[k]!==""&&o[k]!=null&&String(o[k])===String(id))||(o[k]!==null&&typeof o[k]==="object"&&refersTo(o[k],field,id)))}
function usedBy(pageKey){const fields=REF_FIELDS[pageKey];if(!fields)return{n:0,where:{}};
 const ids=pageKeys(pageKey).map(k=>mem.get(k).id).filter(x=>x!=null);const where={};
 [...mem].forEach(([k,rec])=>{const c=k.split("/")[0];if(c===pageKey||NOT_REF.includes(c))return;
  if(ids.some(id=>fields.some(f=>refersTo(rec,f,id))))where[c]=(where[c]||0)+1});
 return{n:Object.values(where).reduce((a,b)=>a+b,0),where}}
const pageLabel=c=>{const p=(typeof PAGES!=="undefined"&&PAGES.find(x=>x[0]===c))||null;return p?p[1]:c};

/* ----- start-up: the local copy first, so the app opens even with no connection ----- */
const ready=(async()=>{
 try{const [kv,q,m]=await Promise.all([readAll("kv"),readAll("queue"),readAll("meta")]);
  Object.entries(kv).forEach(([k,v])=>mem.set(k,v));Object.entries(q).forEach(([k,v])=>queue.set(k,v));
  revs=m.revs||{};token=m.token||"";tokenUser=m.tokenUser||"";}catch(e){}
 if(serverUrl&&token)await Promise.race([syncNow(),timeout(3000)]);
})();

window.IMS_LOCAL={
 noStore:false,
 backup(){const o={};mem.forEach((v,k)=>{o[k]=v});downloads.save({filename:"IMS_backup_"+new Date().toISOString().slice(0,10)+".json",data:JSON.stringify(o)})},
 restore(){const i=document.createElement("input");i.type="file";i.accept=".json";i.onchange=async()=>{try{const o=JSON.parse(await i.files[0].text());
   if(!confirm("Restore this backup? Records with the same ID are overwritten."))return;
   await Promise.all(Object.entries(o).map(([k,v])=>setItem(k,v)));alert("Backup restored. The page will reload.");location.reload()}catch(e){alert("That file is not a valid backup.")}};i.click()},
 serverSettings(){const cur=serverUrl||location.origin||"";
  const v=prompt("Server address for syncing. Leave it empty to work only on this computer.\nOffice server: http://192.168.1.20:8000     Internet server: https://ims.yourdomain.com",cur);
  if(v===null)return;const t=v.trim().replace(/\/$/,"");
  if(t===(serverUrl||"")){if(!t)return;if(!token)signInPrompt();else syncNow();return}
  if(!t){localStorage.setItem("ims-server-url","");serverUrl="";token="";tokenUser="";queue.clear();clearStore("queue");write("meta","token",undefined);note("Working only on this computer. Changes are not synced.","#b45309");return}
  if(!confirm("Share the records of this computer with the server at "+t+"?\n\nRecords that exist only here are sent to the server. Records that exist on both keep the server's version. A backup of this computer's records is downloaded first.")) return;
  window.IMS_LOCAL.backup();
  localStorage.setItem("ims-server-url",t);serverUrl=t;
  token="";tokenUser="";revs={};queue.clear();clearStore("queue");write("meta","token",undefined);write("meta","tokenUser",undefined);write("meta","revs",{});
  switching=true;signInPrompt()},
 pageBackup(){const list=pageList();
  const n=prompt("Save the data of which page? Type its number:\n"+list.map((p,i)=>(i+1)+"  "+p[1]).join("\n"));
  if(n===null)return;const pick=list[parseInt(n,10)-1];if(!pick){alert("Please type a number from the list.");return}
  const o={};pageKeys(pick[0]).forEach(k=>{o[k]=mem.get(k)});
  if(!Object.keys(o).length){alert(pick[1]+" has no data to save yet.");return}
  downloads.save({filename:"IMS_page_"+pick[0]+"_"+new Date().toISOString().slice(0,10)+".json",data:JSON.stringify(o)})},
 async pageRemove(){const list=pageList();
  const n=prompt("Remove the data of which page? Type its number:\n"+list.map((p,i)=>(i+1)+"  "+p[1]).join("\n"));
  if(n===null)return;const pick=list[parseInt(n,10)-1];if(!pick){alert("Please type a number from the list.");return}
  const keys=pageKeys(pick[0]);if(!keys.length){alert(pick[1]+" has no data to remove.");return}
  const use=usedBy(pick[0]);
  const warn=use.n?"\n\n"+use.n+" saved record(s) use "+pick[1]+": "+Object.entries(use.where).map(([c,n])=>pageLabel(c)+" ("+n+")").join(", ")+". They keep all their data, and they will show the name from the Trash until it is restored.":"";
  const typed=prompt("This removes all "+keys.length+" records of "+pick[1]+" from this page on every computer that shares this data.\nThe records are moved to the Trash, so they can be restored (File -> Restore removed page data)."+warn+"\n\nTo confirm, type REMOVE in capitals:");
  if(typed!=="REMOVE"){alert("Nothing was removed.");return}
  const id=Date.now(), records={};keys.forEach(k=>{records[k]=mem.get(k)});
  await setItem("trash/"+id,{id:id,page:pick[0],label:pick[1],at:new Date().toISOString(),records:records});
  await Promise.all(keys.map(k=>delItem(k)));
  if(typeof logH==="function")logH("Removed page data",pick[0],keys.length+" records of "+pick[1]+" moved to the Trash");
  alert(keys.length+" records of "+pick[1]+" were moved to the Trash. Restore them from File -> Restore removed page data.")},
 async pageRestoreRemoved(){
  const entries=[...mem].filter(([k])=>k.startsWith("trash/")).map(([k,v])=>[k,v]).sort((a,b)=>String(a[1].at).localeCompare(String(b[1].at)));
  if(!entries.length){alert("The Trash is empty.");return}
  const n=prompt("Restore which removed page data? Type its number:\n"+entries.map((e,i)=>(i+1)+"  "+e[1].label+"  removed "+new Date(e[1].at).toLocaleString()+"  ("+Object.keys(e[1].records).length+" records)").join("\n"));
  if(n===null)return;const pick=entries[parseInt(n,10)-1];if(!pick){alert("Please type a number from the list.");return}
  const recs=pick[1].records;
  await Promise.all(Object.entries(recs).map(([k,v])=>setItem(k,v)));
  await delItem(pick[0]);
  if(typeof logH==="function")logH("Restored removed page data",pick[1].page,Object.keys(recs).length+" records of "+pick[1].label+" restored from the Trash");
  alert(Object.keys(recs).length+" records of "+pick[1].label+" were restored.")},
 signedIn(u,pw){if(!serverUrl)return;
  // this computer already syncs with a sign-in: other people use it, so there is no second sign-in to make
  if(token&&tokenUser&&tokenUser!==u)return;
  signIn(u,pw).then(r=>{if(!r.ok)note("Server sign-in failed ("+r.error+"). The app keeps working; changes sync after you sign in.","#b45309")})},
aiprovider(){const cur=localStorage.getItem("ims-ai-provider")||"anthropic";const p=prompt("AI provider: type ollama to use a model on this computer (through Ollama), or anthropic to use Claude with your AI key.",cur);if(p===null)return;const v=p.trim().toLowerCase();if(v!=="ollama"&&v!=="anthropic"){alert("Please type ollama or anthropic.");return}localStorage.setItem("ims-ai-provider",v);if(v==="ollama"){const m=prompt("Ollama model name (it must support tools), for example qwen2.5:7b or llama3.1:",localStorage.getItem("ims-ollama-model")||"qwen2.5:7b");if(m&&m.trim())localStorage.setItem("ims-ollama-model",m.trim())}location.reload()},
 aikey(){const k=prompt("Paste your Anthropic API key to turn on the full AI agent (stored only in this browser).\nLeave empty and press OK to remove it.",localStorage.getItem("ims-ai-key")||"");if(k===null)return;if(k.trim())localStorage.setItem("ims-ai-key",k.trim());else localStorage.removeItem("ims-ai-key");location.reload()}};
window.addEventListener("error",e=>{const h=document.getElementById("lh");if(h&&/Loading/.test(h.textContent))h.textContent="Start-up error: "+(e.message||"unknown")});
window.claude={use:async n=>{await ready;if(n==="db")return store;if(n==="assets")return assets;if(n==="downloads")return downloads;
 if(n==="user")return{can:()=>true};if(n==="sample")return(providerIsOllama()||localStorage.getItem("ims-ai-key"))?sample:null;return null}};
const toData=f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>rej(r.error);r.readAsDataURL(f)});
const assets={upload:async f=>{if(f.size>8*1024*1024)throw new Error("File is larger than 8 MB");return{id:String(Date.now()),url:await toData(f)}}};
const MIME={pdf:"application/pdf",xlsx:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",csv:"text/csv",json:"application/json"};
const downloads={save:async({filename,data})=>{if(window.pywebview&&pywebview.api&&pywebview.api.save_file){const bl=new Blob([data],{type:"application/octet-stream"});const b64=await new Promise(res=>{const fr=new FileReader();fr.onload=()=>res(String(fr.result).split(",")[1]);fr.readAsDataURL(bl)});await pywebview.api.save_file(filename,b64);return}if(window.showSaveFilePicker){try{const ext0=filename.split(".").pop().toLowerCase(),type0=MIME[ext0]||"application/octet-stream";const h=await window.showSaveFilePicker({suggestedName:filename,types:[{description:ext0.toUpperCase()+" file",accept:{[type0]:["."+ext0]}}]});const w=await h.createWritable();await w.write(new Blob([data],{type:type0}));await w.close();return}catch(e){if(e&&e.name==="AbortError")return}}const ext=filename.split(".").pop(),b=new Blob([data],{type:MIME[ext]||"application/octet-stream"}),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=filename;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1500)}};
const providerIsOllama=()=>localStorage.getItem("ims-ai-provider")==="ollama";
/* the agent's conversation (Anthropic format) -> Ollama chat messages */
function toOllama(msgs){const out=[],names={};
 msgs.forEach(m=>{
  if(typeof m.content==="string"){out.push({role:m.role,content:m.content});return}
  if(m.role==="assistant"){const text=m.content.filter(b=>b.type==="text").map(b=>b.text).join("");const calls=m.content.filter(b=>b.type==="tool_use");
   calls.forEach(b=>{names[b.id]=b.name});const msg={role:"assistant",content:text};
   if(calls.length)msg.tool_calls=calls.map(b=>({function:{name:b.name,arguments:b.input||{}}}));out.push(msg);return}
  m.content.filter(b=>b.type==="tool_result").forEach(b=>out.push({role:"tool",tool_name:names[b.tool_use_id]||"tool",content:String(b.content)}));
  const text=m.content.filter(b=>b.type==="text").map(b=>b.text).join("");if(text)out.push({role:"user",content:text})});
 return out}
/* an Ollama reply -> the same shape the agent reads from Anthropic */
function fromOllama(j){const msg=j.message||{};const content=[];if(msg.content)content.push({type:"text",text:msg.content});
 const calls=msg.tool_calls||[];
 calls.forEach((c,i)=>{const a=c.function.arguments;content.push({type:"tool_use",id:"call_"+Date.now()+"_"+i,name:c.function.name,input:typeof a==="string"?JSON.parse(a||"{}"):(a||{})})});
 return{content,stop_reason:calls.length?"tool_use":"end_turn"}}
async function sample(msgs,opts){const ollama=providerIsOllama();const key=localStorage.getItem("ims-ai-key");
 const tools=[...(opts.tools||[]).map(t=>({name:t.name,description:t.description,input_schema:t.inputSchema||{type:"object",properties:{}}})),...(opts.serverTools||[])];
 const ollamaTools=(opts.tools||[]).map(t=>({type:"function",function:{name:t.name,description:t.description,parameters:t.inputSchema||{type:"object",properties:{}}}}));
 const messages=msgs.map(m=>({role:m.role,content:m.content}));let text="",web=false;
 for(let i=0;i<12;i++){
  let j;
  if(ollama){
   // Ollama runs on this computer; the Python server passes the request on (no internet key needed)
   const r=await fetch(aiBase()+"/api/ai/ollama",{method:"POST",headers:Object.assign({"content-type":"application/json"},auth()),body:JSON.stringify({model:localStorage.getItem("ims-ollama-model")||"qwen2.5:7b",messages:toOllama(messages),tools:ollamaTools})});
   const data=await r.json().catch(()=>({}));
   if(!r.ok)throw new Error(data.error||("Ollama error "+r.status));
   j=fromOllama(data);
  }else{
   const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"content-type":"application/json","x-api-key":key,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify({model:localStorage.getItem("ims-ai-model")||"claude-sonnet-4-6",max_tokens:2000,tools,messages})});
   if(!r.ok){const t=await r.text();throw new Error(r.status===401?"The AI key was rejected. Use File → AI key to enter it again.":"AI service error "+r.status+": "+t.slice(0,150))}
   j=await r.json();
  }
  messages.push({role:"assistant",content:j.content});if(j.content.some(b=>b.type==="server_tool_use"||b.type==="web_search_tool_result"))web=true;
  const part=j.content.filter(b=>b.type==="text").map(b=>b.text).join("");if(part){text=part;opts.onText&&opts.onText({text})}
  if(j.stop_reason==="pause_turn")continue;if(j.stop_reason!=="tool_use")break;
  const results=[];
  for(const b of j.content.filter(b=>b.type==="tool_use")){let out,bad=false;try{const t=(opts.tools||[]).find(x=>x.name===b.name);out=await t.execute(b.input||{});if(typeof out!=="string")out=JSON.stringify(out)}catch(e){bad=true;out="Error: "+(e&&e.message||e)}results.push({type:"tool_result",tool_use_id:b.id,content:out,is_error:bad})}
  messages.push({role:"user",content:results})}
 return{text,web}}
window.__sha256=function(s){const m=new TextEncoder().encode(s),K=[],H=[1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225];let p=2,n=0;
 while(n<64){let c=true;for(let i=2;i*i<=p;i++)if(p%i==0){c=false;break}if(c){K[n]=(Math.pow(p,1/3)%1*4294967296)|0;n++}p++}
 const l=m.length,w=new Uint32Array(((l+9+63)>>6)<<4);m.forEach((b,i)=>w[i>>2]|=b<<(24-(i&3)*8));w[l>>2]|=128<<(24-(l&3)*8);w[w.length-1]=l*8;
 const rr=(x,y)=>(x>>>y)|(x<<(32-y));
 for(let o=0;o<w.length;o+=16){const a=new Uint32Array(64);for(let i=0;i<16;i++)a[i]=w[o+i];for(let i=16;i<64;i++){const s0=rr(a[i-15],7)^rr(a[i-15],18)^(a[i-15]>>>3),s1=rr(a[i-2],17)^rr(a[i-2],19)^(a[i-2]>>>10);a[i]=(a[i-16]+s0+a[i-7]+s1)|0}
  let [A,B,C,D,E,F,G,Hh]=H;for(let i=0;i<64;i++){const S1=rr(E,6)^rr(E,11)^rr(E,25),ch=(E&F)^(~E&G),t1=(Hh+S1+ch+K[i]+a[i])|0,S0=rr(A,2)^rr(A,13)^rr(A,22),mj=(A&B)^(A&C)^(B&C),t2=(S0+mj)|0;Hh=G;G=F;F=E;E=(D+t1)|0;D=C;C=B;B=A;A=(t1+t2)|0}
  H[0]=(H[0]+A)|0;H[1]=(H[1]+B)|0;H[2]=(H[2]+C)|0;H[3]=(H[3]+D)|0;H[4]=(H[4]+E)|0;H[5]=(H[5]+F)|0;H[6]=(H[6]+G)|0;H[7]=(H[7]+Hh)|0}
 return H.map(x=>(x>>>0).toString(16).padStart(8,"0")).join("")};
})();
