# IMS – Inventory & Sales Management System (Django version)

This is the same application as **IMS-Big-Base-white-logo.html**, run with Django.
Django serves the application pages and keeps all the data in a database:
**SQLite** (a file, `db.sqlite3`, the default) or **MySQL / MariaDB** (see below).

## Requirements
* Python 3.10 or newer (on Windows, tick **Add Python to PATH** when installing)
* Visual Studio Code (optional), with the Python extension
* For the AI agent with Ollama (optional): Ollama from https://ollama.com

## Run it in VS Code
1. Open this folder in VS Code (**File → Open Folder**).
2. Open a terminal (**Terminal → New Terminal**).
3. Install Django once: `pip install -r requirements.txt`
4. Start the server: `python manage.py runserver`
5. Open **http://127.0.0.1:8000** in Chrome or Edge. Sign in as **admin / admin123**, then change the password in **Users & Rights**.

Stop the server with **Ctrl+C**. On Windows you can also double-click **run.bat**; on Mac or Linux, run `./run.sh`.

## Where the data is
* **SQLite (default):** the file `db.sqlite3` in this folder. Each saved item is a row in the table `store_record` (`key` such as `emp/3` or `users/ali`, and `value` with its data). The table `store_revision` counts changes.
* **MySQL / MariaDB:** the database named in `database.ini`. The same two tables are created there.
* To back up SQLite, stop the server and copy `db.sqlite3`. You can also use **File → Backup data** in the application, which saves everything as a `.json` file.
* To start empty, stop the server, delete `db.sqlite3` (SQLite only), and run `python manage.py migrate`.

## Switch from SQLite to MySQL
1. **Install MySQL or MariaDB** and start it. (MariaDB is free and works the same way.)
2. **Create the database and a user** (for example in the MySQL command line or MySQL Workbench). Use UTF-8 so Urdu and other languages are stored correctly:
   ```sql
   CREATE DATABASE ims CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'ims_user'@'localhost' IDENTIFIED BY 'a-strong-password';
   GRANT ALL PRIVILEGES ON ims.* TO 'ims_user'@'localhost';
   ```
   Django also needs rights to create a `test_ims` database when you run the tests.
3. **Keep your current data (optional):** stop the server, then run `python manage.py dumpdata store --indent 2 > ims_backup.json` while `database.ini` still says `engine = sqlite`. In Windows, run this in the Command Prompt (`cmd`) so the file is saved as plain UTF-8.
4. **Install the MySQL driver:** `pip install -r requirements-mysql.txt`
5. **Edit `database.ini`:** set `engine = mysql`, and fill in `name`, `user`, `password`, `host` and `port`. (`database.ini.example` shows the layout.)
6. **Create the tables:** `python manage.py migrate`
7. **Load your data (if you saved it in step 3):** `python manage.py loaddata ims_backup.json`
8. Start the server as before. The application now saves to MySQL.

You can also set the same values with environment variables (`IMS_DB_ENGINE=mysql`, `IMS_MYSQL_NAME`, `IMS_MYSQL_USER`, `IMS_MYSQL_PASSWORD`, `IMS_MYSQL_HOST`, `IMS_MYSQL_PORT`). They override `database.ini`.

Checked here: the same tables, the same data after the copy, the Django tests, and the application's smoke test run on MariaDB 10.11. Records with Urdu text and emoji survive a restart.

## AI Agent: Claude (Anthropic) or Ollama (on this computer)
The agent can use either:
* **Claude:** File → **AI key…** (paste your Anthropic key). It answers from the database and uses web search when needed.
* **Ollama:** runs a model on this computer, with no key and no internet needed for the answer. Set it up once:
  1. Install Ollama from https://ollama.com and start it.
  2. Download a model that supports tools, for example: `ollama pull qwen2.5:7b` (other options: `llama3.1`, `mistral-nemo`).
  3. In the application: File → **AI provider…** → type `ollama`, then the model name (for example `qwen2.5:7b`). The page reloads.
  4. Ask the agent a question in its window.

The Django server passes the agent's requests to Ollama, so the browser never talks to Ollama directly. The Ollama address and default model are in `database.ini` under `[ai]` (`ollama_url = http://127.0.0.1:11434`, `ollama_model = qwen2.5:7b`).

Limits with Ollama: it answers from the database only (web search is available with Claude), its speed depends on your computer, and answers are only as good as the model. If the model does not support tools, Ollama reports it and the agent shows the message.

Checked here: the agent through a stand-in server that uses Ollama's request and reply format, including the tool call, the tool result, an unknown model, and Ollama being stopped. A real model was not run in this test, so please try it with your own model.

## Features
The application is the same as the standalone file.

* **Masters:** Expense Category, Project Name, Expense Type (each type belongs to a category), Vendor Registration, Bank Registration, Employee Registration (name, gender, picture, login), Holidays setup.
* **Accounts:** Bank Account (ledger with description), Expenses (several items per expense, with approval), Approvals, Purchase, Sales (batch stock), Stock.
* **Assets Registration:** purchase date, project (from Project Name), automatic Asset No (AST-2026-00001, numbered per year), vendor (optional), asset name, unit, qty and price (whole numbers) and total. The Balance Sheet's Fixed assets is the total of the assets bought on or before the as-at date.
* **Assets Registration:** purchase date (you choose), Asset No (automatic, for example AST-2026-00001, numbered again each year), vendor (optional), asset name (required), unit (Pcs, KG, Mtr, Gz, Pack, Others), qty and price (whole numbers), and total (qty x price, automatic). The **Balance Sheet** shows Fixed assets as the total of the assets bought on or before the as-at date. If you paid cash for an asset, also record that payment in Bank Account, or the balance sheet will show the difference.
* **Payroll:** Salary (basic, house rent, utility and any number of benefits, all added to gross), Attendance (Saturdays, Sundays and holidays are not working days), Paid Salaries, Salary Slip.
* **Tools:** Dashboard, History, Reports, Balance Sheet, AI Agent, Chat.
* **Admin:** Users & Rights.

Rules built in: every Save asks for confirmation; a user without approval rights sends an expense for approval; the Expense Type list shows only the types linked to the chosen category; pictures appear in the top bar; the page works on phones.

## Offline and sync
* **The app works without a connection.** It keeps a full copy of its data in the browser (IndexedDB). With the internet or the server off, you can keep working, and every change is saved on the computer and queued.
* **Sync when the server is reachable.** When you are signed in, queued changes are sent to the server, and changes made on other computers arrive. This is checked about every 1.5 seconds. The status line shows "Offline: N changes saved on this computer, waiting to sync", "Syncing…", or "Back online: N changes synced."
* **Server address:** **File → Server & sync…**. Office server: `http://192.168.1.20:8000` (this computer's network address, with this server running). Internet server: `https://ims.yourdomain.com` (use HTTPS). Leave it empty to work only on this computer.
* **Sign-in:** the first person who signs in to an empty server becomes the owner. After that, signing in to the app also signs in to the server with the same password. The server gives the computer a token that lasts 30 days.
* **Latest change wins.** Each record counts its changes. If two computers change the same record while offline, the change that reaches the server last is kept. The replaced change is written to **History** as "Overwritten", so nothing disappears without a trace. If the content is identical, nothing is noted.
* **A computer syncs with the sign-in of the first person who signs in on it.** Other people who use the same computer work on the same data, and their changes sync under that sign-in.
* **New accounts made offline:** a new user can only sign in to the server after an account for them has reached it. A signed-in person syncing from any computer sends it.

## Files
* `manage.py` – the Django command line (runserver, migrate, test, dumpdata, loaddata).
* `ims/` – project settings (`settings.py`), the database switch and the web addresses (`urls.py`).
* `store/` – the data: `models.py` (the tables: records with revisions, sign-in tokens), `views.py` (the pages, the data API, sign-in and the Ollama proxy), `tests.py` (tests), `migrations/` (database setup).
* `ims/middleware.py` – lets the standalone file and other computers call the data API.
* `web/` – the application pages (HTML, CSS, JavaScript and the logo).
* `web/js/offline-runtime.js` – the local copy, the offline queue, sync with the server, and the AI agent's connection to Claude or Ollama.
* `database.ini` – choose SQLite or MySQL, and the Ollama address. `database.ini.example` shows the MySQL layout.
* `db.sqlite3` – the SQLite database (used when `engine = sqlite`).
* `requirements.txt` – Django. `requirements-mysql.txt` – the MySQL driver (only for MySQL).

## Security
* **The data API needs a sign-in.** Each computer gets a token when its person signs in. Without a token the server refuses data (401), except during first-time setup when the server has no accounts yet.
* **Use HTTPS beyond a trusted network.** The sign-in sends the password hash the application uses. Over plain HTTP on an office network, anyone who can see that traffic can reuse it. For the internet, put the server behind HTTPS (for example a reverse proxy with a certificate).
* **Per-person rights (Users & Rights) are enforced by the application, not the server.** Someone who can reach the server and has a valid sign-in could call the data API directly. Keep the server on a network you trust, and only give server access to people you trust.
* **Cross-origin access:** the data API accepts requests from any origin, so the standalone file can sync. This is safe because it uses tokens, not cookies.
* **The AI (Ollama) proxy needs a sign-in too.**
* Keep this folder, `database.ini` (it can hold the MySQL password) and the database on a computer you control.

## Tests
* Data API, sign-in, revisions and conflicts: `python manage.py test store` (16 tests, including the Ollama proxy)
* Browser suites (the application, against this server): smoke, core, payroll, confirmation, Users & Rights, balance sheet, agent, Ollama, and the sync test, which uses two browsers as two computers, takes one offline, and checks the conflict rule. These are kept with the development files, not in this download.

## Desktop app (its own window, no browser)
The same program can run as a desktop application. It starts the built-in server on this computer and shows the application in its own window.

* **Run it from the project folder (Windows):** double-click **run_desktop.bat**. The first time, it installs what it needs.
* **Build a program file (Windows):** double-click **build_desktop.bat**. When it finishes, copy the whole `dist\IMS` folder to any Windows computer and double-click **IMS.exe** inside it. No Python is needed on that computer.
* **Where the data is:** `%APPDATA%\IMS`. The database is `ims.sqlite3` there, and the page's local copy is in the `browser` folder. Use **File → Backup data** to save a copy.
* **Port:** the built-in server uses this computer only, starting at port 8765 (or the next free port).
* **Needs:** Windows 10 or 11 with the WebView2 runtime (it comes with Microsoft Edge, and Windows 11 has it built in).
* **Sync:** by default the desktop app keeps its data on its own computer. To share data with other computers, open **File → Server & sync…** and enter the office server address.
* **Database:** the desktop app always uses SQLite. MySQL and SQL Server are for the server version.

What was checked here: the desktop server (smoke test, all 24 windows, and the two-computer sync test), the window itself on a virtual screen (the sign-in page appears with the logo), and a packaged test build (the same server, smoke test, and data folder). Not checked here: a Windows build, WebView2 on Windows, printing, and file pickers for pictures and receipts inside the window. Please test those on Windows.

## Save or remove one page's data (administrators)
File menu → **Save one page's data…** asks for the page (by number) and saves only that page's records to a file. The file has the same format as **Backup data**, so **Restore data** brings those records back.

Saved records keep all their data. For example, if an expense category is removed, its expenses stay exactly as they were and still show the category's name, taken from the Trash. This holds on every page, including the Expenses data window, where removed categories and expense types keep their names. The message lists which pages use the removed item. Restore the item from the Trash to make it available again.

File menu → **Remove one page's data…** moves all records of the chosen page to the **Trash** after you type `REMOVE` to confirm. Nothing is lost: the Trash keeps the records until you restore them, and it is shared like the rest of the data. The removal is written to History.

File menu → **Restore removed page data…** lists what is in the Trash, by page and date. Choose one to bring its records back. Earlier backup files are never changed by a removal or a restore.

These pages can be saved and removed: Expense Category, Project Name, Expense Type, Vendor, Bank Registration, Employee, Bank Account, Expenses, Approvals, Salary, Attendance, Holidays, Paid Salaries, Purchase, Sales, Assets Registration, and Chat. Users & Rights and History are never removed this way.

## Share one set of records between the web app and the desktop app
The web app and the desktop app keep their own records until you connect them. Connect each desktop computer once:

1. **Start the office server** on the computer that holds the main records.
   * Same computer only: `python manage.py runserver` (run.bat does this). Address: `http://127.0.0.1:8000`.
   * Other computers on the office network: in `database.ini`, under `[server]`, set `allowed_hosts = 127.0.0.1,localhost,<this computer's address>` (for example `192.168.1.20`). Then run `python manage.py runserver 0.0.0.0:8000`. The other computers use `http://<this computer's address>:8000`. Allow port 8000 through the Windows Firewall on the office network.
2. **In the desktop app:** **File → Server & sync…**, enter the server address, and confirm. A backup of the desktop's records is downloaded first. Sign in with the same username and password as in the app.
3. **Done.** Records that exist only on the desktop are sent to the server, and the desktop receives the server's records. Both apps then show the same records, and a change in one appears in the other within a few seconds.

Notes:
* If a record exists on both sides with different content, the server's version is kept. The desktop's version is in the backup file, so nothing is lost.
* The desktop app still works without a connection. Its changes wait on the computer and are sent when the server can be reached.
* The AI agent with Ollama on a shared server uses the Ollama that runs on the server computer.
* Connect each computer once. The setting is kept after that.

## Automatic backup of the database to another drive
The backup copies the database file (`db.sqlite3` for the web app server) to a folder on another drive, on a schedule. It is safe while the server is running, checks each copy, and keeps only the newest copies.

1. **Choose the folder and how many copies to keep** in `database.ini`, under `[backup]`:
   ```
   [backup]
   folder = E:\IMS_Backups
   keep = 30
   ```
   Use a drive other than the one with Windows. The folder is created the first time.
2. **Test it:** double-click **run_backup.bat**. A file `ims-YYYYMMDD-HHMMSS.sqlite3` appears in the folder, and the result is written to `backup.log` there.
3. **Schedule it:** double-click **setup_backup_task.bat**. It asks you to choose the backup folder (type a path, or press Enter to keep the current one). Your choice is saved in `backup_folder.txt` and used by both the scheduled and the manual backup. It finds Python and checks that Django is installed (run run.bat once first). It stops with a message if the task was not created. Choose every day at a time, or every few hours. This creates the Windows task "IMS Backup" in Task Scheduler. Python must be installed and the computer must be on and logged in at the scheduled time.

Notes:
* The scheduled backup uses the web app server's database. For the desktop app's own database (`%APPDATA%\IMS\ims.sqlite3`), run: `python backup_db.py --database "%APPDATA%\IMS\ims.sqlite3" --folder E:\IMS_Backups`.
* To restore, stop the server and copy a backup file over `db.sqlite3` (or over `%APPDATA%\IMS\ims.sqlite3` for the desktop app), then start the server again.
* If the drive is not connected, the run fails and `backup.log` says so. Nothing old is deleted in that case.
* For MySQL, use `mysqldump` instead of this script.
* If the setup says Python was not found: open a NEW Command Prompt and type `python --version`. If that does not show a version, reinstall Python from python.org and tick "Add python.exe to PATH".
* **Backup data in the browser** (File → Backup data): in Chrome or Edge, a Save dialog lets you choose the folder and file name. On a page opened over a plain network address (for example http://192.168.1.20:8000), the browser may not offer the dialog; the file is then saved to the Downloads folder.
* To change the backup folder later, double-click setup_backup_task.bat again and type the new folder.
* To check the task: open Task Scheduler, find "IMS Backup", and look at its History tab. The backup folder's `backup.log` shows each run.
