@echo off
cd /d "%~dp0"
python -c "import sys" >nul 2>&1
if not errorlevel 1 (
  python backup_db.py
  goto end
)
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  py -3 backup_db.py
  goto end
)
echo Python was not found. Run setup_backup_task.bat for help.
:end
