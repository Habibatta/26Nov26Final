@echo off
setlocal
cd /d "%~dp0"
set "SCHTASKS=%SystemRoot%\System32\schtasks.exe"
if not exist "%SCHTASKS%" (
  echo Windows Task Scheduler was not found at %SCHTASKS%.
  pause
  exit /b 1
)
set "PY="
python -c "import sys" >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
  py -3 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
  echo Python was not found by this computer.
  echo Open a NEW Command Prompt and type: python --version
  echo If that does not show a version, reinstall Python from python.org and tick "Add python.exe to PATH".
  pause
  exit /b 1
)
set "EXE="
for /f "delims=" %%P in ('%PY% -c "import sys;print(sys.executable)" 2^>nul') do set "EXE=%%P"
"%PY%" -c "import django" >nul 2>&1
if errorlevel 1 (
  echo Django is not installed for this Python. Double-click run.bat once, then run this again.
  pause
  exit /b 1
)
set "CURRENT=D:\IMS_Backups"
if exist backup_folder.txt set /p CURRENT=<backup_folder.txt
echo.
echo Where should the backup copies go?
echo   Current choice: %CURRENT%
echo   Type a folder and press Enter, for example E:\IMS_Backups
echo   or just press Enter to keep the current choice.
set "FOLDER="
set /p FOLDER=Backup folder: 
if "%FOLDER%"=="" set "FOLDER=%CURRENT%"
echo %FOLDER%>backup_folder.txt
set "RUN=%PY% \"%~dp0backup_db.py\""
if defined EXE set "RUN=\"%EXE%\" \"%~dp0backup_db.py\""
echo.
echo Automatic backup of the IMS database to %FOLDER%
echo   1 = every day at a time you choose
echo   2 = every few hours
set "CHOICE="
set /p CHOICE=Type 1 or 2 and press Enter: 
if "%CHOICE%"=="2" goto hours
set "TIME="
set /p TIME=Time of day in 24-hour format, for example 23:30: 
"%SCHTASKS%" /create /tn "IMS Backup" /sc daily /st %TIME% /tr "%RUN%" /f
goto check
:hours
set "HOURS="
set /p HOURS=Every how many hours, for example 4: 
"%SCHTASKS%" /create /tn "IMS Backup" /sc hourly /mo %HOURS% /tr "%RUN%" /f
:check
if errorlevel 1 (
  echo.
  echo The task was NOT created. Check the time or hours you typed, then run this again.
  pause
  exit /b 1
)
echo.
echo Done. The task "IMS Backup" will save copies to %FOLDER%
echo To test now, double-click run_backup.bat. Results are written to backup.log in that folder.
pause
