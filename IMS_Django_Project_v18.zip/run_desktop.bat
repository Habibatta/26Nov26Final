@echo off
cd /d "%~dp0"
python -c "import webview" >nul 2>&1 || python -m pip install -r requirements.txt -r requirements-desktop.txt
python desktop_app.py
