@echo off
cd /d "%~dp0"
python -c "import django" >nul 2>&1 || python -m pip install -r requirements.txt
python manage.py migrate --noinput
echo.
echo Open http://127.0.0.1:8000 in Chrome or Edge. Press Ctrl+C here to stop.
python manage.py runserver 127.0.0.1:8000
pause
